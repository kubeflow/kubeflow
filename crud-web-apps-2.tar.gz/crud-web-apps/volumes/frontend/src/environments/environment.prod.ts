export const environment = {
  production: true,
  viewerUrl: '',
  resource: 'pvcviewers',
  ui: 'default',
};
