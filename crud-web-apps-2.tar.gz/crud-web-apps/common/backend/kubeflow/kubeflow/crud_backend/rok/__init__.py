from .routes import bp  # noqa E402, F401
