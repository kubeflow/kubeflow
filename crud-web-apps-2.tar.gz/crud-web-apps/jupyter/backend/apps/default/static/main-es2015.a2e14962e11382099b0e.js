(self["webpackChunkfrontend"] = self["webpackChunkfrontend"] || []).push([["main"],{

/***/ 8255:
/*!*******************************************************!*\
  !*** ./$_lazy_route_resources/ lazy namespace object ***!
  \*******************************************************/
/***/ (function(module) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = 8255;
module.exports = webpackEmptyAsyncContext;

/***/ }),

/***/ 158:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRoutingModule": function() { return /* binding */ AppRoutingModule; }
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _pages_index_index_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pages/index/index.component */ 7479);
/* harmony import */ var _pages_form_form_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pages/form/form.component */ 5804);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);





const routes = [
    { path: '', component: _pages_index_index_component__WEBPACK_IMPORTED_MODULE_0__.IndexComponent },
    { path: 'new', component: _pages_form_form_component__WEBPACK_IMPORTED_MODULE_1__.FormComponent },
];
class AppRoutingModule {
}
AppRoutingModule.ɵfac = function AppRoutingModule_Factory(t) { return new (t || AppRoutingModule)(); };
AppRoutingModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: AppRoutingModule });
AppRoutingModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forRoot(routes, { relativeLinkResolution: 'legacy' })], _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](AppRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule] }); })();


/***/ }),

/***/ 5041:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppComponent": function() { return /* binding */ AppComponent; }
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 9895);


class AppComponent {
    constructor() {
        this.title = 'frontend';
    }
}
AppComponent.ɵfac = function AppComponent_Factory(t) { return new (t || AppComponent)(); };
AppComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: AppComponent, selectors: [["app-root"]], decls: 1, vars: 0, template: function AppComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "router-outlet");
    } }, directives: [_angular_router__WEBPACK_IMPORTED_MODULE_1__.RouterOutlet], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhcHAuY29tcG9uZW50LnNjc3MifQ== */"] });


/***/ }),

/***/ 6747:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppModule": function() { return /* binding */ AppModule; }
/* harmony export */ });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/platform-browser */ 9075);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app-routing.module */ 158);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.component */ 5041);
/* harmony import */ var _pages_index_index_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pages/index/index.module */ 1023);
/* harmony import */ var _pages_form_form_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pages/form/form.module */ 9552);
/* harmony import */ var kubeflow__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! kubeflow */ 872);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/form-field */ 8295);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);










class AppModule {
}
AppModule.ɵfac = function AppModule_Factory(t) { return new (t || AppModule)(); };
AppModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineNgModule"]({ type: AppModule, bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_1__.AppComponent] });
AppModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjector"]({ providers: [], imports: [[
            _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpClientModule,
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__.BrowserModule,
            _app_routing_module__WEBPACK_IMPORTED_MODULE_0__.AppRoutingModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule,
            kubeflow__WEBPACK_IMPORTED_MODULE_8__.KubeflowModule,
            _pages_index_index_module__WEBPACK_IMPORTED_MODULE_2__.IndexModule,
            _pages_form_form_module__WEBPACK_IMPORTED_MODULE_3__.FormModule,
            _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__.MatFormFieldModule
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsetNgModuleScope"](AppModule, { declarations: [_app_component__WEBPACK_IMPORTED_MODULE_1__.AppComponent], imports: [_angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpClientModule,
        _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__.BrowserModule,
        _app_routing_module__WEBPACK_IMPORTED_MODULE_0__.AppRoutingModule,
        _angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule,
        kubeflow__WEBPACK_IMPORTED_MODULE_8__.KubeflowModule,
        _pages_index_index_module__WEBPACK_IMPORTED_MODULE_2__.IndexModule,
        _pages_form_form_module__WEBPACK_IMPORTED_MODULE_3__.FormModule,
        _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__.MatFormFieldModule] }); })();


/***/ }),

/***/ 5905:
/*!**************************************************************************************************!*\
  !*** ./src/app/pages/form/form-default/form-advanced-options/form-advanced-options.component.ts ***!
  \**************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormAdvancedOptionsComponent": function() { return /* binding */ FormAdvancedOptionsComponent; }
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var kubeflow__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! kubeflow */ 872);
/* harmony import */ var _angular_material_slide_toggle__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material/slide-toggle */ 5396);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 3679);




class FormAdvancedOptionsComponent {
    constructor() { }
    ngOnInit() { }
}
FormAdvancedOptionsComponent.ɵfac = function FormAdvancedOptionsComponent_Factory(t) { return new (t || FormAdvancedOptionsComponent)(); };
FormAdvancedOptionsComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: FormAdvancedOptionsComponent, selectors: [["app-form-advanced-options"]], inputs: { parentForm: "parentForm" }, decls: 3, vars: 1, consts: function () { let i18n_0; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_3590993217621889922$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_ADVANCED_OPTIONS_FORM_ADVANCED_OPTIONS_COMPONENT_TS_1 = goog.getMsg("Miscellaneous Settings");
        i18n_0 = MSG_EXTERNAL_3590993217621889922$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_ADVANCED_OPTIONS_FORM_ADVANCED_OPTIONS_COMPONENT_TS_1;
    }
    else {
        i18n_0 = $localize `:␟ac184ad5119488375c501e04e46b79dbb6079cc7␟3590993217621889922:Miscellaneous Settings`;
    } let i18n_2; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_4678403269921893493$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_ADVANCED_OPTIONS_FORM_ADVANCED_OPTIONS_COMPONENT_TS_3 = goog.getMsg(" Enable Shared Memory ");
        i18n_2 = MSG_EXTERNAL_4678403269921893493$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_ADVANCED_OPTIONS_FORM_ADVANCED_OPTIONS_COMPONENT_TS_3;
    }
    else {
        i18n_2 = $localize `:␟4f9350429574d4118ef3709016039f34a0785466␟4678403269921893493: Enable Shared Memory `;
    } return [["title", i18n_0], [3, "formControl"], i18n_2]; }, template: function FormAdvancedOptionsComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "lib-form-section", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-slide-toggle", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵi18n"](2, 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("formControl", ctx.parentForm.get("shm"));
    } }, directives: [kubeflow__WEBPACK_IMPORTED_MODULE_1__.FormSectionComponent, _angular_material_slide_toggle__WEBPACK_IMPORTED_MODULE_2__.MatSlideToggle, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControlDirective], styles: ["mat-slide-toggle[_ngcontent-%COMP%] {\n  margin-bottom: 0.6rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZvcm0tYWR2YW5jZWQtb3B0aW9ucy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHFCQUFBO0FBQ0YiLCJmaWxlIjoiZm9ybS1hZHZhbmNlZC1vcHRpb25zLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsibWF0LXNsaWRlLXRvZ2dsZSB7XG4gIG1hcmdpbi1ib3R0b206IDAuNnJlbTtcbn1cbiJdfQ== */"] });


/***/ }),

/***/ 6440:
/*!**********************************************************************************************************!*\
  !*** ./src/app/pages/form/form-default/form-affinity-tolerations/form-affinity-tolerations.component.ts ***!
  \**********************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormAffinityTolerationsComponent": function() { return /* binding */ FormAffinityTolerationsComponent; }
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var kubeflow__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! kubeflow */ 872);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material/form-field */ 8295);
/* harmony import */ var _angular_material_select__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/select */ 7441);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/core */ 7817);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 8583);







function FormAffinityTolerationsComponent_mat_option_8_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-option", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const affinityConfig_r2 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", affinityConfig_r2.configKey);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", affinityConfig_r2.displayName, " ");
} }
function FormAffinityTolerationsComponent_mat_option_15_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-option", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const tolerationGroup_r3 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("value", tolerationGroup_r3.groupKey);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", tolerationGroup_r3.displayName, " ");
} }
class FormAffinityTolerationsComponent {
    constructor() { }
    ngOnInit() { }
}
FormAffinityTolerationsComponent.ɵfac = function FormAffinityTolerationsComponent_Factory(t) { return new (t || FormAffinityTolerationsComponent)(); };
FormAffinityTolerationsComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: FormAffinityTolerationsComponent, selectors: [["app-form-affinity-tolerations"]], inputs: { parentForm: "parentForm", tolerationGroups: "tolerationGroups", affinityConfigs: "affinityConfigs" }, decls: 16, vars: 4, consts: function () { let i18n_0; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_8653055932362710932$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_AFFINITY_TOLERATIONS_FORM_AFFINITY_TOLERATIONS_COMPONENT_TS_1 = goog.getMsg("Affinity / Tolerations");
        i18n_0 = MSG_EXTERNAL_8653055932362710932$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_AFFINITY_TOLERATIONS_FORM_AFFINITY_TOLERATIONS_COMPONENT_TS_1;
    }
    else {
        i18n_0 = $localize `:␟e0a31a4739749d022f9c0265ef0db1779daf3bad␟8653055932362710932:Affinity / Tolerations`;
    } let i18n_2; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_6515390795205468481$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_AFFINITY_TOLERATIONS_FORM_AFFINITY_TOLERATIONS_COMPONENT_TS_3 = goog.getMsg(" Affinity Config ");
        i18n_2 = MSG_EXTERNAL_6515390795205468481$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_AFFINITY_TOLERATIONS_FORM_AFFINITY_TOLERATIONS_COMPONENT_TS_3;
    }
    else {
        i18n_2 = $localize `:␟633ab3500af3e54a7519377f4b6e5bc100737123␟6515390795205468481: Affinity Config `;
    } let i18n_4; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        /**
         * @desc option None
         */
        const MSG_EXTERNAL_6252070156626006029$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_AFFINITY_TOLERATIONS_FORM_AFFINITY_TOLERATIONS_COMPONENT_TS_5 = goog.getMsg("None");
        i18n_4 = MSG_EXTERNAL_6252070156626006029$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_AFFINITY_TOLERATIONS_FORM_AFFINITY_TOLERATIONS_COMPONENT_TS_5;
    }
    else {
        i18n_4 = $localize `:option None␟a2f14a73f7a6e94479f67423cc51102da8d6f524␟6252070156626006029:None`;
    } let i18n_6; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_1171476011848522716$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_AFFINITY_TOLERATIONS_FORM_AFFINITY_TOLERATIONS_COMPONENT_TS_7 = goog.getMsg(" Tolerations Group ");
        i18n_6 = MSG_EXTERNAL_1171476011848522716$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_AFFINITY_TOLERATIONS_FORM_AFFINITY_TOLERATIONS_COMPONENT_TS_7;
    }
    else {
        i18n_6 = $localize `:␟26316693d7df543784a554fb79d00771f79a2865␟1171476011848522716: Tolerations Group `;
    } let i18n_8; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        /**
         * @desc option None
         */
        const MSG_EXTERNAL_6252070156626006029$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_AFFINITY_TOLERATIONS_FORM_AFFINITY_TOLERATIONS_COMPONENT_TS_9 = goog.getMsg("None");
        i18n_8 = MSG_EXTERNAL_6252070156626006029$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_AFFINITY_TOLERATIONS_FORM_AFFINITY_TOLERATIONS_COMPONENT_TS_9;
    }
    else {
        i18n_8 = $localize `:option None␟a2f14a73f7a6e94479f67423cc51102da8d6f524␟6252070156626006029:None`;
    } return [["title", i18n_0], [1, "row"], ["appearance", "outline", 1, "wide", "column"], i18n_2, [3, "formControl"], ["value", ""], i18n_4, [3, "value", 4, "ngFor", "ngForOf"], i18n_6, i18n_8, [3, "value"]]; }, template: function FormAffinityTolerationsComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "lib-form-section", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "mat-form-field", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵi18n"](4, 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "mat-select", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "mat-option", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵi18n"](7, 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](8, FormAffinityTolerationsComponent_mat_option_8_Template, 2, 2, "mat-option", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "mat-form-field", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵi18n"](11, 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "mat-select", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "mat-option", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵi18n"](14, 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](15, FormAffinityTolerationsComponent_mat_option_15_Template, 2, 2, "mat-option", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("formControl", ctx.parentForm.get("affinityConfig"));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.affinityConfigs);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("formControl", ctx.parentForm.get("tolerationGroup"));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.tolerationGroups);
    } }, directives: [kubeflow__WEBPACK_IMPORTED_MODULE_1__.FormSectionComponent, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_2__.MatFormField, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_2__.MatLabel, _angular_material_select__WEBPACK_IMPORTED_MODULE_3__.MatSelect, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControlDirective, _angular_material_core__WEBPACK_IMPORTED_MODULE_5__.MatOption, _angular_common__WEBPACK_IMPORTED_MODULE_6__.NgForOf], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJmb3JtLWFmZmluaXR5LXRvbGVyYXRpb25zLmNvbXBvbmVudC5zY3NzIn0= */"] });


/***/ }),

/***/ 4999:
/*!**********************************************************************************************!*\
  !*** ./src/app/pages/form/form-default/form-configurations/form-configurations.component.ts ***!
  \**********************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormConfigurationsComponent": function() { return /* binding */ FormConfigurationsComponent; }
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 826);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var kubeflow__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! kubeflow */ 872);
/* harmony import */ var src_app_services_backend_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/services/backend.service */ 600);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/form-field */ 8295);
/* harmony import */ var _angular_material_select__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/select */ 7441);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/core */ 7817);









function FormConfigurationsComponent_mat_option_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-option", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const config_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("value", config_r1.label);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", config_r1.desc, " ");
} }
class FormConfigurationsComponent {
    constructor(ns, backend) {
        this.ns = ns;
        this.backend = backend;
        this.subscriptions = new rxjs__WEBPACK_IMPORTED_MODULE_2__.Subscription();
    }
    ngOnInit() {
        // Keep track of the selected namespace
        const nsSub = this.ns.getSelectedNamespace().subscribe(namespace => {
            // Get the PodDefaults of the new Namespace
            this.backend.getPodDefaults(namespace).subscribe(pds => {
                this.podDefaults = pds;
            });
        });
        this.subscriptions.add(nsSub);
    }
    ngOnDestroy() {
        this.subscriptions.unsubscribe();
    }
}
FormConfigurationsComponent.ɵfac = function FormConfigurationsComponent_Factory(t) { return new (t || FormConfigurationsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](kubeflow__WEBPACK_IMPORTED_MODULE_3__.NamespaceService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_services_backend_service__WEBPACK_IMPORTED_MODULE_0__.JWABackendService)); };
FormConfigurationsComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: FormConfigurationsComponent, selectors: [["app-form-configurations"]], inputs: { parentForm: "parentForm" }, decls: 6, vars: 2, consts: function () { let i18n_0; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_9147549536677777412$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_CONFIGURATIONS_FORM_CONFIGURATIONS_COMPONENT_TS_1 = goog.getMsg("Configurations");
        i18n_0 = MSG_EXTERNAL_9147549536677777412$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_CONFIGURATIONS_FORM_CONFIGURATIONS_COMPONENT_TS_1;
    }
    else {
        i18n_0 = $localize `:␟edd04e579025543c017d80558217d1e2788708df␟9147549536677777412:Configurations`;
    } let i18n_2; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_5115994784318532749$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_CONFIGURATIONS_FORM_CONFIGURATIONS_COMPONENT_TS_3 = goog.getMsg(" Configurations ");
        i18n_2 = MSG_EXTERNAL_5115994784318532749$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_CONFIGURATIONS_FORM_CONFIGURATIONS_COMPONENT_TS_3;
    }
    else {
        i18n_2 = $localize `:␟a76f7ebd6eb4f4afd7109e574dc617f858cd2d80␟5115994784318532749: Configurations `;
    } return [["title", i18n_0], ["appearance", "outline", 1, "wide"], i18n_2, ["multiple", "", 3, "formControl"], [3, "value", 4, "ngFor", "ngForOf"], [3, "value"]]; }, template: function FormConfigurationsComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "lib-form-section", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "mat-form-field", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵi18n"](3, 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "mat-select", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](5, FormConfigurationsComponent_mat_option_5_Template, 2, 2, "mat-option", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formControl", ctx.parentForm.get("configurations"));
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx.podDefaults);
    } }, directives: [kubeflow__WEBPACK_IMPORTED_MODULE_3__.FormSectionComponent, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_4__.MatFormField, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_4__.MatLabel, _angular_material_select__WEBPACK_IMPORTED_MODULE_5__.MatSelect, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControlDirective, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgForOf, _angular_material_core__WEBPACK_IMPORTED_MODULE_8__.MatOption], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJmb3JtLWNvbmZpZ3VyYXRpb25zLmNvbXBvbmVudC5zY3NzIn0= */"] });


/***/ }),

/***/ 9492:
/*!********************************************************************************!*\
  !*** ./src/app/pages/form/form-default/form-cpu-ram/form-cpu-ram.component.ts ***!
  \********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormCpuRamComponent": function() { return /* binding */ FormCpuRamComponent; }
/* harmony export */ });
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils */ 3261);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var kubeflow__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! kubeflow */ 872);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/form-field */ 8295);
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/input */ 3166);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);






class FormCpuRamComponent {
    constructor() { }
    ngOnInit() {
        this.parentForm.get('cpu').valueChanges.subscribe(val => {
            // set cpu limit when value of the cpu request changes
            if (this.parentForm.get('cpuLimit').dirty) {
                return;
            }
            const cpu = this.parentForm.get('cpu').value;
            this.parentForm
                .get('cpuLimit')
                .setValue((0,_utils__WEBPACK_IMPORTED_MODULE_0__.calculateLimits)(cpu, this.cpuLimitFactor));
        });
        this.parentForm.get('memory').valueChanges.subscribe(val => {
            // set memory limit when value of the memory request changes
            if (this.parentForm.get('memoryLimit').dirty) {
                return;
            }
            const memory = this.parentForm.get('memory').value;
            this.parentForm
                .get('memoryLimit')
                .setValue((0,_utils__WEBPACK_IMPORTED_MODULE_0__.calculateLimits)(memory, this.memoryLimitFactor));
        });
    }
    getCPUError() { }
    getRAMError() { }
}
FormCpuRamComponent.ɵfac = function FormCpuRamComponent_Factory(t) { return new (t || FormCpuRamComponent)(); };
FormCpuRamComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: FormCpuRamComponent, selectors: [["app-form-cpu-ram"]], inputs: { parentForm: "parentForm", readonlyCPU: "readonlyCPU", readonlyMemory: "readonlyMemory", cpuLimitFactor: "cpuLimitFactor", memoryLimitFactor: "memoryLimitFactor" }, decls: 16, vars: 4, consts: function () { let i18n_0; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        /**
         * @desc Title for the CPU/RAM form section
         */
        const MSG_EXTERNAL_456502051508651798$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_CPU_RAM_FORM_CPU_RAM_COMPONENT_TS_1 = goog.getMsg("CPU / RAM");
        i18n_0 = MSG_EXTERNAL_456502051508651798$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_CPU_RAM_FORM_CPU_RAM_COMPONENT_TS_1;
    }
    else {
        i18n_0 = $localize `:Title for the CPU/RAM form section␟f22f0cf2e9846ef910c72864e8d5b62b36b81c86␟456502051508651798:CPU / RAM`;
    } let i18n_2; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_4944039245822888012$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_CPU_RAM_FORM_CPU_RAM_COMPONENT_TS_3 = goog.getMsg("Requested CPUs");
        i18n_2 = MSG_EXTERNAL_4944039245822888012$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_CPU_RAM_FORM_CPU_RAM_COMPONENT_TS_3;
    }
    else {
        i18n_2 = $localize `:␟01817bd08ce56cd2966da83498f862a5c3984cc8␟4944039245822888012:Requested CPUs`;
    } let i18n_4; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_6062130950224244266$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_CPU_RAM_FORM_CPU_RAM_COMPONENT_TS_5 = goog.getMsg("Requested memory in Gi");
        i18n_4 = MSG_EXTERNAL_6062130950224244266$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_CPU_RAM_FORM_CPU_RAM_COMPONENT_TS_5;
    }
    else {
        i18n_4 = $localize `:␟c35a751936ff43637e90b7a97c69939364e32a2f␟6062130950224244266:Requested memory in Gi`;
    } let i18n_6; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_1642621628416517504$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_CPU_RAM_FORM_CPU_RAM_COMPONENT_TS_7 = goog.getMsg("CPU limit");
        i18n_6 = MSG_EXTERNAL_1642621628416517504$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_CPU_RAM_FORM_CPU_RAM_COMPONENT_TS_7;
    }
    else {
        i18n_6 = $localize `:␟b236d0d38ab7c46409b041002e008f28ade48e54␟1642621628416517504:CPU limit`;
    } let i18n_8; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_5340799198017063091$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_CPU_RAM_FORM_CPU_RAM_COMPONENT_TS_9 = goog.getMsg(" Memory limit in Gi ");
        i18n_8 = MSG_EXTERNAL_5340799198017063091$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_CPU_RAM_FORM_CPU_RAM_COMPONENT_TS_9;
    }
    else {
        i18n_8 = $localize `:␟393e204f9358a7b2bb54c23a1dd6fda2d3a20fe0␟5340799198017063091: Memory limit in Gi `;
    } return [["title", i18n_0], [1, "row"], ["min", "0", "step", "0.1", "label", i18n_2, 1, "column", 3, "sizeControl"], ["min", "0", "step", "0.1", "label", i18n_4, 1, "column", 3, "sizeControl"], [1, "column"], ["appearance", "outline", 1, "wide"], i18n_6, ["matInput", "", "type", "number", "min", "0.1", "step", "0.1", 3, "formControl"], i18n_8]; }, template: function FormCpuRamComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "lib-form-section", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](2, "lib-positive-number-input", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](3, "lib-positive-number-input", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "lib-advanced-options");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "mat-form-field", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](8, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵi18n"](9, 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](10, "input", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](11, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "mat-form-field", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](13, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵi18n"](14, 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](15, "input", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("sizeControl", ctx.parentForm.get("cpu"));
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("sizeControl", ctx.parentForm.get("memory"));
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formControl", ctx.parentForm.get("cpuLimit"));
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formControl", ctx.parentForm.get("memoryLimit"));
    } }, directives: [kubeflow__WEBPACK_IMPORTED_MODULE_2__.FormSectionComponent, kubeflow__WEBPACK_IMPORTED_MODULE_2__.PositiveNumberInputComponent, kubeflow__WEBPACK_IMPORTED_MODULE_2__.AdvancedOptionsComponent, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_3__.MatFormField, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_3__.MatLabel, _angular_material_input__WEBPACK_IMPORTED_MODULE_4__.MatInput, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.MinValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControlDirective], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJmb3JtLWNwdS1yYW0uY29tcG9uZW50LnNjc3MifQ== */"] });


/***/ }),

/***/ 5524:
/*!******************************************************************************************!*\
  !*** ./src/app/pages/form/form-default/form-data-volumes/form-data-volumes.component.ts ***!
  \******************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormDataVolumesComponent": function() { return /* binding */ FormDataVolumesComponent; }
/* harmony export */ });
/* harmony import */ var src_app_shared_utils_volumes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/shared/utils/volumes */ 562);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var kubeflow__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! kubeflow */ 872);
/* harmony import */ var _angular_material_expansion__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/expansion */ 2976);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/button */ 1095);
/* harmony import */ var _volume_mount_mount_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../volume/mount/mount.component */ 8758);
/* harmony import */ var _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/tooltip */ 1436);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/icon */ 6627);
/* harmony import */ var _volume_existing_existing_volume_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../volume/existing/existing-volume.component */ 9335);
/* harmony import */ var _volume_new_new_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../volume/new/new.component */ 4129);











function FormDataVolumesComponent_mat_expansion_panel_2_ng_container_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const volGroup_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().$implicit;
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("matTooltip", ctx_r3.getVolumeName(volGroup_r1.value));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", ctx_r3.getVolumeName(volGroup_r1.value), ", ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"]("", ctx_r3.getNewVolumeType(volGroup_r1.value), ",");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx_r3.getNewVolumeSize(volGroup_r1.value));
} }
function FormDataVolumesComponent_mat_expansion_panel_2_ng_container_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const volGroup_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().$implicit;
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("matTooltip", ctx_r4.getVolumeName(volGroup_r1.value));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", ctx_r4.getVolumeName(volGroup_r1.value), " ");
} }
function FormDataVolumesComponent_mat_expansion_panel_2_mat_icon_8_Template(rf, ctx) { if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "mat-icon", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function FormDataVolumesComponent_mat_expansion_panel_2_mat_icon_8_Template_mat_icon_click_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r14); const i_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().index; const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return ctx_r12.onDelete(i_r2, $event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " delete ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function FormDataVolumesComponent_mat_expansion_panel_2_mat_icon_9_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "mat-icon", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " expand_more ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function FormDataVolumesComponent_mat_expansion_panel_2_mat_icon_10_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "mat-icon", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " expand_less ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function FormDataVolumesComponent_mat_expansion_panel_2_app_existing_volume_12_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "app-existing-volume", 14);
} if (rf & 2) {
    const volGroup_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("volGroup", volGroup_r1);
} }
function FormDataVolumesComponent_mat_expansion_panel_2_app_new_volume_13_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "app-new-volume", 21);
} if (rf & 2) {
    const volGroup_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().$implicit;
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("volGroup", volGroup_r1)("externalName", ctx_r9.externalName);
} }
function FormDataVolumesComponent_mat_expansion_panel_2_Template(rf, ctx) { if (rf & 1) {
    const _r18 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "mat-expansion-panel", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("opened", function FormDataVolumesComponent_mat_expansion_panel_2_Template_mat_expansion_panel_opened_0_listener() { const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r18); const i_r2 = restoredCtx.index; const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return ctx_r17.openPanel.add(i_r2); })("closed", function FormDataVolumesComponent_mat_expansion_panel_2_Template_mat_expansion_panel_closed_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r18); const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return ctx_r19.openPanel.clear(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "mat-expansion-panel-header");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "mat-panel-title");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "mat-panel-description");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](5, FormDataVolumesComponent_mat_expansion_panel_2_ng_container_5_Template, 7, 4, "ng-container", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](6, FormDataVolumesComponent_mat_expansion_panel_2_ng_container_6_Template, 3, 2, "ng-container", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](8, FormDataVolumesComponent_mat_expansion_panel_2_mat_icon_8_Template, 2, 0, "mat-icon", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](9, FormDataVolumesComponent_mat_expansion_panel_2_mat_icon_9_Template, 2, 0, "mat-icon", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](10, FormDataVolumesComponent_mat_expansion_panel_2_mat_icon_10_Template, 2, 0, "mat-icon", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](12, FormDataVolumesComponent_mat_expansion_panel_2_app_existing_volume_12_Template, 1, 1, "app-existing-volume", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](13, FormDataVolumesComponent_mat_expansion_panel_2_app_new_volume_13_Template, 1, 2, "app-new-volume", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](14, "app-volume-mount", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const volGroup_r1 = ctx.$implicit;
    const i_r2 = ctx.index;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", ctx_r0.getVolumeTitle(volGroup_r1.value), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", volGroup_r1.get("newPvc"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", volGroup_r1.get("existingSource"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !ctx_r0.readonly);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !ctx_r0.openPanel.has(i_r2));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r0.openPanel.has(i_r2));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵclassProp"]("readonly", ctx_r0.readonly);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", volGroup_r1.get("existingSource"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", volGroup_r1.get("newPvc"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("volGroup", volGroup_r1);
} }
class FormDataVolumesComponent {
    constructor() {
        this.openPanel = new Set();
        this.getVolumeTitle = src_app_shared_utils_volumes__WEBPACK_IMPORTED_MODULE_0__.getVolumeTitle;
        this.getVolumeName = src_app_shared_utils_volumes__WEBPACK_IMPORTED_MODULE_0__.getVolumeName;
        this.getNewVolumeSize = src_app_shared_utils_volumes__WEBPACK_IMPORTED_MODULE_0__.getNewVolumeSize;
        this.getNewVolumeType = src_app_shared_utils_volumes__WEBPACK_IMPORTED_MODULE_0__.getNewVolumeType;
    }
    ngOnInit() { }
    onDelete(id, event) {
        event.stopPropagation();
        this.volsArray.removeAt(id);
        this.openPanel.clear();
    }
    addNewVolume() {
        const volId = this.volsArray.length + 1;
        const volGroup = (0,src_app_shared_utils_volumes__WEBPACK_IMPORTED_MODULE_0__.createNewPvcVolumeFormGroup)(`{notebook-name}-datavol-${volId}`);
        this.volsArray.push(volGroup);
        volGroup.get('mount').setValue(`/home/jovyan/vol-${this.volsArray.length}`);
    }
    attachExistingVolume() {
        const volGroup = (0,src_app_shared_utils_volumes__WEBPACK_IMPORTED_MODULE_0__.createExistingVolumeFormGroup)();
        this.volsArray.push(volGroup);
        volGroup.get('mount').setValue(`/home/jovyan/vol-${this.volsArray.length}`);
    }
}
FormDataVolumesComponent.ɵfac = function FormDataVolumesComponent_Factory(t) { return new (t || FormDataVolumesComponent)(); };
FormDataVolumesComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({ type: FormDataVolumesComponent, selectors: [["app-form-data-volumes"]], inputs: { volsArray: "volsArray", readonly: "readonly", externalName: "externalName" }, decls: 8, vars: 3, consts: function () { let i18n_0; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_8559099691597110875$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_DATA_VOLUMES_FORM_DATA_VOLUMES_COMPONENT_TS_1 = goog.getMsg("Data Volumes");
        i18n_0 = MSG_EXTERNAL_8559099691597110875$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_DATA_VOLUMES_FORM_DATA_VOLUMES_COMPONENT_TS_1;
    }
    else {
        i18n_0 = $localize `:␟cbe5b11222992396a96e6d3d8ba3e9af4cbbdd92␟8559099691597110875:Data Volumes`;
    } let i18n_2; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_1210629459016879016$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_DATA_VOLUMES_FORM_DATA_VOLUMES_COMPONENT_TS_3 = goog.getMsg("Additional volumes that will be mounted in your Notebook");
        i18n_2 = MSG_EXTERNAL_1210629459016879016$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_DATA_VOLUMES_FORM_DATA_VOLUMES_COMPONENT_TS_3;
    }
    else {
        i18n_2 = $localize `:␟c17ee0002fcee6f1a26b77fbc92ef62ff0d5381d␟1210629459016879016:Additional volumes that will be mounted in your Notebook`;
    } let i18n_4; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_1142047506147649422$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_DATA_VOLUMES_FORM_DATA_VOLUMES_COMPONENT_TS_5 = goog.getMsg(" + Add new volume ");
        i18n_4 = MSG_EXTERNAL_1142047506147649422$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_DATA_VOLUMES_FORM_DATA_VOLUMES_COMPONENT_TS_5;
    }
    else {
        i18n_4 = $localize `:␟912571feb5980547173477e4818f758118e83ca1␟1142047506147649422: + Add new volume `;
    } let i18n_6; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_1161391785498397314$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_DATA_VOLUMES_FORM_DATA_VOLUMES_COMPONENT_TS_7 = goog.getMsg(" + Attach existing volume ");
        i18n_6 = MSG_EXTERNAL_1161391785498397314$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_DATA_VOLUMES_FORM_DATA_VOLUMES_COMPONENT_TS_7;
    }
    else {
        i18n_6 = $localize `:␟1b0c6c93b58dac1a8719f5ec525193b2357e5e24␟1161391785498397314: + Attach existing volume `;
    } let i18n_8; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_7200856845698679324$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_DATA_VOLUMES_FORM_DATA_VOLUMES_COMPONENT_TS__9 = goog.getMsg("Delete volume");
        i18n_8 = MSG_EXTERNAL_7200856845698679324$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_DATA_VOLUMES_FORM_DATA_VOLUMES_COMPONENT_TS__9;
    }
    else {
        i18n_8 = $localize `:␟e295c323cbcd6575dd493a8f2da7dd85d8d9706e␟7200856845698679324:Delete volume`;
    } let i18n_10; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_1568125515243307887$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_DATA_VOLUMES_FORM_DATA_VOLUMES_COMPONENT_TS__11 = goog.getMsg("Show volume details");
        i18n_10 = MSG_EXTERNAL_1568125515243307887$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_DATA_VOLUMES_FORM_DATA_VOLUMES_COMPONENT_TS__11;
    }
    else {
        i18n_10 = $localize `:␟66b97ad4367fde1abbcb9fb8a4910c3f03b6af89␟1568125515243307887:Show volume details`;
    } let i18n_12; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_3475484794929439395$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_DATA_VOLUMES_FORM_DATA_VOLUMES_COMPONENT_TS__13 = goog.getMsg("Hide volume details");
        i18n_12 = MSG_EXTERNAL_3475484794929439395$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_DATA_VOLUMES_FORM_DATA_VOLUMES_COMPONENT_TS__13;
    }
    else {
        i18n_12 = $localize `:␟80793a3166e187779e7a5fa2f80b043083bca4a5␟3475484794929439395:Hide volume details`;
    } return [["title", i18n_0, "text", i18n_2], ["hideToggle", "", 3, "opened", "closed", 4, "ngFor", "ngForOf"], [1, "volume-buttons"], ["type", "button", "color", "primary", "mat-stroked-button", "", 3, "disabled", "click"], i18n_4, i18n_6, ["hideToggle", "", 3, "opened", "closed"], [4, "ngIf"], [1, "icons"], ["matTooltip", i18n_8, "class", "delete-icon", 3, "click", 4, "ngIf"], ["matTooltip", i18n_10, 4, "ngIf"], ["matTooltip", i18n_12, 4, "ngIf"], [3, "volGroup", 4, "ngIf"], [3, "volGroup", "externalName", 4, "ngIf"], [3, "volGroup"], [1, "pvc-name", "truncate", 3, "matTooltip"], [1, "pvc-type"], [1, "vol-name", "truncate", 3, "matTooltip"], ["matTooltip", i18n_8, 1, "delete-icon", 3, "click"], ["matTooltip", i18n_10], ["matTooltip", i18n_12], [3, "volGroup", "externalName"]]; }, template: function FormDataVolumesComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "lib-form-section", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "mat-accordion");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](2, FormDataVolumesComponent_mat_expansion_panel_2_Template, 15, 11, "mat-expansion-panel", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "button", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function FormDataVolumesComponent_Template_button_click_4_listener() { return ctx.addNewVolume(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵi18n"](5, 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "button", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function FormDataVolumesComponent_Template_button_click_6_listener() { return ctx.attachExistingVolume(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵi18n"](7, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx.volsArray.controls);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("disabled", ctx.readonly);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("disabled", ctx.readonly);
    } }, directives: [kubeflow__WEBPACK_IMPORTED_MODULE_5__.FormSectionComponent, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_6__.MatAccordion, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgForOf, _angular_material_button__WEBPACK_IMPORTED_MODULE_8__.MatButton, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_6__.MatExpansionPanel, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_6__.MatExpansionPanelHeader, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_6__.MatExpansionPanelTitle, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_6__.MatExpansionPanelDescription, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgIf, _volume_mount_mount_component__WEBPACK_IMPORTED_MODULE_1__.VolumeMountComponent, _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_9__.MatTooltip, _angular_material_icon__WEBPACK_IMPORTED_MODULE_10__.MatIcon, _volume_existing_existing_volume_component__WEBPACK_IMPORTED_MODULE_2__.ExistingVolumeComponent, _volume_new_new_component__WEBPACK_IMPORTED_MODULE_3__.NewVolumeComponent], styles: ["[_nghost-%COMP%] {\n  display: block;\n}\n\n.readonly[_ngcontent-%COMP%] {\n  pointer-events: none;\n}\n\n.pvc-name[_ngcontent-%COMP%] {\n  max-width: 200px;\n  margin-right: 0.3rem;\n}\n\n.pvc-type[_ngcontent-%COMP%] {\n  margin-right: 0.3rem;\n}\n\n.vol-name[_ngcontent-%COMP%] {\n  max-width: 400px;\n  margin-right: 0.3rem;\n}\n\n.icons[_ngcontent-%COMP%] {\n  margin-left: auto;\n  min-width: 88px;\n}\n\n.icons[_ngcontent-%COMP%]   .mat-icon[_ngcontent-%COMP%]:hover {\n  color: rgba(0, 0, 0, 0.72);\n}\n\n.icons[_ngcontent-%COMP%]   .delete-icon[_ngcontent-%COMP%] {\n  margin-right: 24px;\n  padding-left: 16px;\n}\n\n.mat-expansion-panel-header-description[_ngcontent-%COMP%] {\n  margin-right: 0;\n  display: flex;\n  align-items: center;\n}\n\n.mat-expansion-panel-header-title[_ngcontent-%COMP%] {\n  align-items: center;\n}\n\n.volume-buttons[_ngcontent-%COMP%] {\n  display: flex;\n  margin-top: 1rem;\n  margin-bottom: 1.5rem;\n}\n\n.volume-buttons[_ngcontent-%COMP%]   .mat-stroked-button[_ngcontent-%COMP%]:first-child {\n  margin-right: 1rem;\n}\n\n.volume-buttons[_ngcontent-%COMP%]   .mat-stroked-button[_ngcontent-%COMP%] {\n  width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZvcm0tZGF0YS12b2x1bWVzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsY0FBQTtBQUNGOztBQUVBO0VBQ0Usb0JBQUE7QUFDRjs7QUFFQTtFQUNFLGdCQUFBO0VBQ0Esb0JBQUE7QUFDRjs7QUFFQTtFQUNFLG9CQUFBO0FBQ0Y7O0FBRUE7RUFDRSxnQkFBQTtFQUNBLG9CQUFBO0FBQ0Y7O0FBRUE7RUFDRSxpQkFBQTtFQUNBLGVBQUE7QUFDRjs7QUFDRTtFQUNFLDBCQUFBO0FBQ0o7O0FBRUU7RUFDRSxrQkFBQTtFQUNBLGtCQUFBO0FBQUo7O0FBR0E7RUFDRSxlQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0FBQUY7O0FBR0E7RUFDRSxtQkFBQTtBQUFGOztBQUdBO0VBQ0UsYUFBQTtFQUNBLGdCQUFBO0VBQ0EscUJBQUE7QUFBRjs7QUFFRTtFQUNFLGtCQUFBO0FBQUo7O0FBR0U7RUFDRSxXQUFBO0FBREoiLCJmaWxlIjoiZm9ybS1kYXRhLXZvbHVtZXMuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdCB7XG4gIGRpc3BsYXk6IGJsb2NrO1xufVxuXG4ucmVhZG9ubHkge1xuICBwb2ludGVyLWV2ZW50czogbm9uZTtcbn1cblxuLnB2Yy1uYW1lIHtcbiAgbWF4LXdpZHRoOiAyMDBweDtcbiAgbWFyZ2luLXJpZ2h0OiAwLjNyZW07XG59XG5cbi5wdmMtdHlwZSB7XG4gIG1hcmdpbi1yaWdodDogMC4zcmVtO1xufVxuXG4udm9sLW5hbWUge1xuICBtYXgtd2lkdGg6IDQwMHB4O1xuICBtYXJnaW4tcmlnaHQ6IDAuM3JlbTtcbn1cblxuLmljb25zIHtcbiAgbWFyZ2luLWxlZnQ6IGF1dG87XG4gIG1pbi13aWR0aDogODhweDtcblxuICAubWF0LWljb246aG92ZXIge1xuICAgIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuNzIpO1xuICB9XG5cbiAgLmRlbGV0ZS1pY29uIHtcbiAgICBtYXJnaW4tcmlnaHQ6IDI0cHg7XG4gICAgcGFkZGluZy1sZWZ0OiAxNnB4O1xuICB9XG59XG4ubWF0LWV4cGFuc2lvbi1wYW5lbC1oZWFkZXItZGVzY3JpcHRpb24ge1xuICBtYXJnaW4tcmlnaHQ6IDA7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG5cbi5tYXQtZXhwYW5zaW9uLXBhbmVsLWhlYWRlci10aXRsZSB7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG5cbi52b2x1bWUtYnV0dG9ucyB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIG1hcmdpbi10b3A6IDFyZW07XG4gIG1hcmdpbi1ib3R0b206IDEuNXJlbTtcblxuICAubWF0LXN0cm9rZWQtYnV0dG9uOmZpcnN0LWNoaWxkIHtcbiAgICBtYXJnaW4tcmlnaHQ6IDFyZW07XG4gIH1cblxuICAubWF0LXN0cm9rZWQtYnV0dG9uIHtcbiAgICB3aWR0aDogMTAwJTtcbiAgfVxufVxuIl19 */"] });


/***/ }),

/***/ 849:
/*!*******************************************************************!*\
  !*** ./src/app/pages/form/form-default/form-default.component.ts ***!
  \*******************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormDefaultComponent": function() { return /* binding */ FormDefaultComponent; }
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs */ 826);
/* harmony import */ var kubeflow__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! kubeflow */ 872);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils */ 3261);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var src_app_services_backend_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/backend.service */ 600);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _form_name_form_name_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./form-name/form-name.component */ 4249);
/* harmony import */ var _form_image_form_image_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./form-image/form-image.component */ 1330);
/* harmony import */ var _form_cpu_ram_form_cpu_ram_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./form-cpu-ram/form-cpu-ram.component */ 9492);
/* harmony import */ var _form_gpus_form_gpus_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./form-gpus/form-gpus.component */ 184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _form_data_volumes_form_data_volumes_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./form-data-volumes/form-data-volumes.component */ 5524);
/* harmony import */ var _form_configurations_form_configurations_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./form-configurations/form-configurations.component */ 4999);
/* harmony import */ var _form_affinity_tolerations_form_affinity_tolerations_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./form-affinity-tolerations/form-affinity-tolerations.component */ 6440);
/* harmony import */ var _form_advanced_options_form_advanced_options_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./form-advanced-options/form-advanced-options.component */ 5905);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/material/button */ 1095);
/* harmony import */ var _form_workspace_volume_form_workspace_volume_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./form-workspace-volume/form-workspace-volume.component */ 4537);



















function FormDefaultComponent_app_form_workspace_volume_8_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](0, "app-form-workspace-volume", 16);
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("readonly", ctx_r0.config == null ? null : ctx_r0.config.workspaceVolume == null ? null : ctx_r0.config.workspaceVolume.readOnly)("volGroup", ctx_r0.formCtrl.get("workspace"))("externalName", ctx_r0.formCtrl.get("name").value);
} }
class FormDefaultComponent {
    constructor(namespaceService, backend, router, popup) {
        this.namespaceService = namespaceService;
        this.backend = backend;
        this.router = router;
        this.popup = popup;
        this.currNamespace = '';
        this.ephemeral = false;
        this.defaultStorageclass = false;
        this.blockSubmit = false;
        this.formReady = false;
        this.existingNotebooks = new Set();
        this.subscriptions = new rxjs__WEBPACK_IMPORTED_MODULE_12__.Subscription();
    }
    ngOnInit() {
        // Initialize the form control
        this.formCtrl = this.getFormDefaults();
        // Update the form Values from the default ones
        this.backend.getConfig().subscribe(config => {
            if (Object.keys(config).length === 0) {
                // Don't fire on empty config
                return;
            }
            this.config = config;
            this.initFormControls(this.formCtrl, config);
        });
        // Keep track of the selected namespace
        this.subscriptions.add(this.namespaceService.getSelectedNamespace().subscribe(namespace => {
            this.currNamespace = namespace;
            this.formCtrl.controls.namespace.setValue(this.currNamespace);
        }));
        // Check if a default StorageClass is set
        this.backend.getDefaultStorageClass().subscribe(defaultClass => {
            if (defaultClass.length === 0) {
                this.defaultStorageclass = false;
                this.popup.open($localize `No default Storage Class is set. Can't create new Disks for the new Notebook. Please use an Existing Disk.`, kubeflow__WEBPACK_IMPORTED_MODULE_13__.SnackType.Warning, 0);
            }
            else {
                this.defaultStorageclass = true;
            }
        });
    }
    ngOnDestroy() {
        // Unsubscriptions
        this.subscriptions.unsubscribe();
    }
    // Functions for handling the Form Group of the entire Form
    getFormDefaults() {
        return (0,_utils__WEBPACK_IMPORTED_MODULE_0__.getFormDefaults)();
    }
    initFormControls(formCtrl, config) {
        (0,_utils__WEBPACK_IMPORTED_MODULE_0__.initFormControls)(formCtrl, config);
    }
    // Form Actions
    getSubmitNotebook() {
        const notebookCopy = this.formCtrl.value;
        const notebook = JSON.parse(JSON.stringify(notebookCopy));
        // Use the custom image instead
        if (notebook.customImageCheck) {
            notebook.image = notebook.customImage;
        }
        else if (notebook.serverType === 'group-one') {
            // Set notebook image from imageGroupOne
            notebook.image = notebook.imageGroupOne;
        }
        else if (notebook.serverType === 'group-two') {
            // Set notebook image from imageGroupTwo
            notebook.image = notebook.imageGroupTwo;
        }
        // Remove unnecessary images from the request sent to the backend
        delete notebook.imageGroupOne;
        delete notebook.imageGroupTwo;
        // Ensure CPU input is a string
        if (typeof notebook.cpu === 'number') {
            notebook.cpu = notebook.cpu.toString();
        }
        // Ensure GPU input is a string
        if (typeof notebook.gpus.num === 'number') {
            notebook.gpus.num = notebook.gpus.num.toString();
        }
        // Remove cpuLimit from request if null
        if (notebook.cpuLimit == null) {
            delete notebook.cpuLimit;
            // Ensure CPU Limit input is a string
        }
        else if (typeof notebook.cpuLimit === 'number') {
            notebook.cpuLimit = notebook.cpuLimit.toString();
        }
        // Remove memoryLimit from request if null
        if (notebook.memoryLimit == null) {
            delete notebook.memoryLimit;
            // Add Gi to memoryLimit
        }
        else if (notebook.memoryLimit) {
            notebook.memoryLimit = notebook.memoryLimit.toString() + 'Gi';
        }
        // Add Gi to all sizes
        if (notebook.memory) {
            notebook.memory = notebook.memory.toString() + 'Gi';
        }
        for (const vol of notebook.datavols) {
            if (vol.size) {
                vol.size = vol.size + 'Gi';
            }
        }
        return notebook;
    }
    onSubmit() {
        this.popup.open('Submitting new Notebook...', kubeflow__WEBPACK_IMPORTED_MODULE_13__.SnackType.Info, 3000);
        const notebook = this.getSubmitNotebook();
        this.backend.createNotebook(notebook).subscribe(() => {
            this.popup.close();
            this.popup.open('Notebook created successfully.', kubeflow__WEBPACK_IMPORTED_MODULE_13__.SnackType.Success, 3000);
            this.router.navigate(['/']);
        });
    }
    onCancel() {
        this.router.navigate(['/']);
    }
}
FormDefaultComponent.ɵfac = function FormDefaultComponent_Factory(t) { return new (t || FormDefaultComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](kubeflow__WEBPACK_IMPORTED_MODULE_13__.NamespaceService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](src_app_services_backend_service__WEBPACK_IMPORTED_MODULE_1__.JWABackendService), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_14__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](kubeflow__WEBPACK_IMPORTED_MODULE_13__.SnackBarService)); };
FormDefaultComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineComponent"]({ type: FormDefaultComponent, selectors: [["app-form-default"]], decls: 18, vars: 27, consts: function () { let i18n_0; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_8239470330825170191$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_DEFAULT_COMPONENT_TS_1 = goog.getMsg(" LAUNCH ");
        i18n_0 = MSG_EXTERNAL_8239470330825170191$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_DEFAULT_COMPONENT_TS_1;
    }
    else {
        i18n_0 = $localize `:␟426440b9cd9f72a1537050344630be55c8d96aa8␟8239470330825170191: LAUNCH `;
    } let i18n_2; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_9168358659421118429$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_DEFAULT_COMPONENT_TS_3 = goog.getMsg(" CANCEL ");
        i18n_2 = MSG_EXTERNAL_9168358659421118429$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_DEFAULT_COMPONENT_TS_3;
    }
    else {
        i18n_2 = $localize `:␟35d035552a3b9e0fb0d9be51e18575b2ed727678␟9168358659421118429: CANCEL `;
    } return [[1, "lib-content-wrapper"], ["title", "New notebook", 3, "backButton", "back"], [1, "page-padding", "lib-flex-grow", "lib-overflow-auto"], ["novalidate", "", 1, "form", 3, "formGroup", "ngSubmit"], [3, "parentForm"], [3, "parentForm", "images", "imagesGroupOne", "imagesGroupTwo", "allowCustomImage", "hideRegistry", "hideTag"], [3, "parentForm", "readonlyCPU", "readonlyMemory", "cpuLimitFactor", "memoryLimitFactor"], [3, "parentForm", "vendors"], [3, "readonly", "volGroup", "externalName", 4, "ngIf"], [3, "volsArray", "readonly", "externalName"], [3, "parentForm", "affinityConfigs", "tolerationGroups"], [1, "form-buttons"], ["mat-raised-button", "", "color", "primary", 3, "disabled", "click"], i18n_0, ["mat-raised-button", "", "type", "button", 3, "click"], i18n_2, [3, "readonly", "volGroup", "externalName"]]; }, template: function FormDefaultComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](1, "lib-title-actions-toolbar", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("back", function FormDefaultComponent_Template_lib_title_actions_toolbar_back_1_listener() { return ctx.onCancel(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](3, "form", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("ngSubmit", function FormDefaultComponent_Template_form_ngSubmit_3_listener() { return ctx.onSubmit(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](4, "app-form-name-namespace", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](5, "app-form-image", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](6, "app-form-cpu-ram", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](7, "app-form-gpus", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](8, FormDefaultComponent_app_form_workspace_volume_8_Template, 1, 3, "app-form-workspace-volume", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](9, "app-form-data-volumes", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](10, "app-form-configurations", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](11, "app-form-affinity-tolerations", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](12, "app-form-advanced-options", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](13, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](14, "button", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function FormDefaultComponent_Template_button_click_14_listener() { return ctx.onSubmit(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵi18n"](15, 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](16, "button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("click", function FormDefaultComponent_Template_button_click_16_listener() { return ctx.onCancel(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵi18n"](17, 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("backButton", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("formGroup", ctx.formCtrl);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("parentForm", ctx.formCtrl);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("parentForm", ctx.formCtrl)("images", ctx.config == null ? null : ctx.config.image == null ? null : ctx.config.image.options)("imagesGroupOne", ctx.config == null ? null : ctx.config.imageGroupOne == null ? null : ctx.config.imageGroupOne.options)("imagesGroupTwo", ctx.config == null ? null : ctx.config.imageGroupTwo == null ? null : ctx.config.imageGroupTwo.options)("allowCustomImage", ctx.config == null ? null : ctx.config.allowCustomImage)("hideRegistry", ctx.config == null ? null : ctx.config.hideRegistry)("hideTag", ctx.config == null ? null : ctx.config.hideTag);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("parentForm", ctx.formCtrl)("readonlyCPU", ctx.config == null ? null : ctx.config.cpu == null ? null : ctx.config.cpu.readOnly)("readonlyMemory", ctx.config == null ? null : ctx.config.memory == null ? null : ctx.config.memory.readOnly)("cpuLimitFactor", ctx.config == null ? null : ctx.config.cpu == null ? null : ctx.config.cpu.limitFactor)("memoryLimitFactor", ctx.config == null ? null : ctx.config.memory == null ? null : ctx.config.memory.limitFactor);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("parentForm", ctx.formCtrl)("vendors", ctx.config == null ? null : ctx.config.gpus == null ? null : ctx.config.gpus.value.vendors);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx.formCtrl.get("workspace"));
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("volsArray", ctx.formCtrl.get("datavols"))("readonly", ctx.config == null ? null : ctx.config.dataVolumes == null ? null : ctx.config.dataVolumes.readOnly)("externalName", ctx.formCtrl.get("name"));
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("parentForm", ctx.formCtrl);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("parentForm", ctx.formCtrl)("affinityConfigs", ctx.config == null ? null : ctx.config.affinityConfig == null ? null : ctx.config.affinityConfig.options)("tolerationGroups", ctx.config == null ? null : ctx.config.tolerationGroup == null ? null : ctx.config.tolerationGroup.options);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("parentForm", ctx.formCtrl);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("disabled", !ctx.formCtrl.valid || ctx.blockSubmit);
    } }, directives: [kubeflow__WEBPACK_IMPORTED_MODULE_13__.TitleActionsToolbarComponent, _angular_forms__WEBPACK_IMPORTED_MODULE_15__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_15__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_15__.FormGroupDirective, _form_name_form_name_component__WEBPACK_IMPORTED_MODULE_2__.FormNameComponent, _form_image_form_image_component__WEBPACK_IMPORTED_MODULE_3__.FormImageComponent, _form_cpu_ram_form_cpu_ram_component__WEBPACK_IMPORTED_MODULE_4__.FormCpuRamComponent, _form_gpus_form_gpus_component__WEBPACK_IMPORTED_MODULE_5__.FormGpusComponent, _angular_common__WEBPACK_IMPORTED_MODULE_16__.NgIf, _form_data_volumes_form_data_volumes_component__WEBPACK_IMPORTED_MODULE_6__.FormDataVolumesComponent, _form_configurations_form_configurations_component__WEBPACK_IMPORTED_MODULE_7__.FormConfigurationsComponent, _form_affinity_tolerations_form_affinity_tolerations_component__WEBPACK_IMPORTED_MODULE_8__.FormAffinityTolerationsComponent, _form_advanced_options_form_advanced_options_component__WEBPACK_IMPORTED_MODULE_9__.FormAdvancedOptionsComponent, _angular_material_button__WEBPACK_IMPORTED_MODULE_17__.MatButton, _form_workspace_volume_form_workspace_volume_component__WEBPACK_IMPORTED_MODULE_10__.FormWorkspaceVolumeComponent], styles: [".form[_ngcontent-%COMP%] {\n  margin-top: 1rem;\n  margin-left: 1rem;\n  max-width: 600px;\n}\n\n.form-buttons[_ngcontent-%COMP%] {\n  margin-bottom: 1rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZvcm0tZGVmYXVsdC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtBQUNGOztBQUVBO0VBQ0UsbUJBQUE7QUFDRiIsImZpbGUiOiJmb3JtLWRlZmF1bHQuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZm9ybSB7XG4gIG1hcmdpbi10b3A6IDFyZW07XG4gIG1hcmdpbi1sZWZ0OiAxcmVtO1xuICBtYXgtd2lkdGg6IDYwMHB4O1xufVxuXG4uZm9ybS1idXR0b25zIHtcbiAgbWFyZ2luLWJvdHRvbTogMXJlbTtcbn1cbiJdfQ== */"] });


/***/ }),

/***/ 5903:
/*!****************************************************************!*\
  !*** ./src/app/pages/form/form-default/form-default.module.ts ***!
  \****************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormDefaultModule": function() { return /* binding */ FormDefaultModule; }
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/material/checkbox */ 7539);
/* harmony import */ var _angular_material_slide_toggle__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/material/slide-toggle */ 5396);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/material/icon */ 6627);
/* harmony import */ var _angular_material_button_toggle__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/material/button-toggle */ 2542);
/* harmony import */ var _angular_material_expansion__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/material/expansion */ 2976);
/* harmony import */ var _form_default_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./form-default.component */ 849);
/* harmony import */ var _form_name_form_name_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./form-name/form-name.component */ 4249);
/* harmony import */ var _form_image_form_image_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./form-image/form-image.component */ 1330);
/* harmony import */ var _form_cpu_ram_form_cpu_ram_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./form-cpu-ram/form-cpu-ram.component */ 9492);
/* harmony import */ var _form_gpus_form_gpus_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./form-gpus/form-gpus.component */ 184);
/* harmony import */ var _form_advanced_options_form_advanced_options_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./form-advanced-options/form-advanced-options.component */ 5905);
/* harmony import */ var kubeflow__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! kubeflow */ 872);
/* harmony import */ var _form_workspace_volume_form_workspace_volume_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./form-workspace-volume/form-workspace-volume.component */ 4537);
/* harmony import */ var _form_data_volumes_form_data_volumes_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./form-data-volumes/form-data-volumes.component */ 5524);
/* harmony import */ var _form_configurations_form_configurations_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./form-configurations/form-configurations.component */ 4999);
/* harmony import */ var _form_affinity_tolerations_form_affinity_tolerations_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./form-affinity-tolerations/form-affinity-tolerations.component */ 6440);
/* harmony import */ var _volume_volume_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./volume/volume.module */ 5097);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 7716);



















class FormDefaultModule {
}
FormDefaultModule.ɵfac = function FormDefaultModule_Factory(t) { return new (t || FormDefaultModule)(); };
FormDefaultModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineNgModule"]({ type: FormDefaultModule });
FormDefaultModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_12__.CommonModule,
            kubeflow__WEBPACK_IMPORTED_MODULE_13__.FormModule,
            _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_14__.MatCheckboxModule,
            _angular_material_slide_toggle__WEBPACK_IMPORTED_MODULE_15__.MatSlideToggleModule,
            _angular_material_expansion__WEBPACK_IMPORTED_MODULE_16__.MatExpansionModule,
            _angular_material_icon__WEBPACK_IMPORTED_MODULE_17__.MatIconModule,
            _angular_material_button_toggle__WEBPACK_IMPORTED_MODULE_18__.MatButtonToggleModule,
            kubeflow__WEBPACK_IMPORTED_MODULE_13__.TitleActionsToolbarModule,
            _volume_volume_module__WEBPACK_IMPORTED_MODULE_10__.VolumeModule,
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵsetNgModuleScope"](FormDefaultModule, { declarations: [_form_default_component__WEBPACK_IMPORTED_MODULE_0__.FormDefaultComponent,
        _form_name_form_name_component__WEBPACK_IMPORTED_MODULE_1__.FormNameComponent,
        _form_image_form_image_component__WEBPACK_IMPORTED_MODULE_2__.FormImageComponent,
        _form_cpu_ram_form_cpu_ram_component__WEBPACK_IMPORTED_MODULE_3__.FormCpuRamComponent,
        _form_workspace_volume_form_workspace_volume_component__WEBPACK_IMPORTED_MODULE_6__.FormWorkspaceVolumeComponent,
        _form_data_volumes_form_data_volumes_component__WEBPACK_IMPORTED_MODULE_7__.FormDataVolumesComponent,
        _form_gpus_form_gpus_component__WEBPACK_IMPORTED_MODULE_4__.FormGpusComponent,
        _form_advanced_options_form_advanced_options_component__WEBPACK_IMPORTED_MODULE_5__.FormAdvancedOptionsComponent,
        _form_configurations_form_configurations_component__WEBPACK_IMPORTED_MODULE_8__.FormConfigurationsComponent,
        _form_affinity_tolerations_form_affinity_tolerations_component__WEBPACK_IMPORTED_MODULE_9__.FormAffinityTolerationsComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_12__.CommonModule,
        kubeflow__WEBPACK_IMPORTED_MODULE_13__.FormModule,
        _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_14__.MatCheckboxModule,
        _angular_material_slide_toggle__WEBPACK_IMPORTED_MODULE_15__.MatSlideToggleModule,
        _angular_material_expansion__WEBPACK_IMPORTED_MODULE_16__.MatExpansionModule,
        _angular_material_icon__WEBPACK_IMPORTED_MODULE_17__.MatIconModule,
        _angular_material_button_toggle__WEBPACK_IMPORTED_MODULE_18__.MatButtonToggleModule,
        kubeflow__WEBPACK_IMPORTED_MODULE_13__.TitleActionsToolbarModule,
        _volume_volume_module__WEBPACK_IMPORTED_MODULE_10__.VolumeModule], exports: [_form_default_component__WEBPACK_IMPORTED_MODULE_0__.FormDefaultComponent,
        _form_name_form_name_component__WEBPACK_IMPORTED_MODULE_1__.FormNameComponent,
        _form_image_form_image_component__WEBPACK_IMPORTED_MODULE_2__.FormImageComponent,
        _form_cpu_ram_form_cpu_ram_component__WEBPACK_IMPORTED_MODULE_3__.FormCpuRamComponent,
        _form_workspace_volume_form_workspace_volume_component__WEBPACK_IMPORTED_MODULE_6__.FormWorkspaceVolumeComponent,
        _form_data_volumes_form_data_volumes_component__WEBPACK_IMPORTED_MODULE_7__.FormDataVolumesComponent,
        _form_gpus_form_gpus_component__WEBPACK_IMPORTED_MODULE_4__.FormGpusComponent,
        _form_advanced_options_form_advanced_options_component__WEBPACK_IMPORTED_MODULE_5__.FormAdvancedOptionsComponent,
        _form_configurations_form_configurations_component__WEBPACK_IMPORTED_MODULE_8__.FormConfigurationsComponent,
        _form_affinity_tolerations_form_affinity_tolerations_component__WEBPACK_IMPORTED_MODULE_9__.FormAffinityTolerationsComponent] }); })();


/***/ }),

/***/ 184:
/*!**************************************************************************!*\
  !*** ./src/app/pages/form/form-default/form-gpus/form-gpus.component.ts ***!
  \**************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormGpusComponent": function() { return /* binding */ FormGpusComponent; }
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 826);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var src_app_services_backend_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/services/backend.service */ 600);
/* harmony import */ var kubeflow__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! kubeflow */ 872);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/form-field */ 8295);
/* harmony import */ var _angular_material_select__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/select */ 7441);
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/core */ 7817);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/tooltip */ 1436);










function FormGpusComponent_mat_option_8_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-option", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const v_r2 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("value", v_r2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", v_r2, " ");
} }
function FormGpusComponent_mat_option_13_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-option", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const v_r3 = ctx.$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("value", v_r3.limitsKey)("matTooltip", ctx_r1.vendorTooltip(v_r3));
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", v_r3.uiName, " ");
} }
class FormGpusComponent {
    constructor(backend) {
        this.backend = backend;
        this.vendors = [];
        this.installedVendors = new Set();
        this.subscriptions = new rxjs__WEBPACK_IMPORTED_MODULE_2__.Subscription();
        this.maxGPUs = 16;
        this.gpusCount = ['1', '2', '4', '8'];
    }
    ngOnInit() {
        this.gpuCtrl = this.parentForm.get('gpus');
        // Vendor should not be empty if the user selects GPUs num
        this.parentForm
            .get('gpus')
            .get('vendor')
            .setValidators([this.vendorWithNum()]);
        this.subscriptions.add(this.gpuCtrl.get('num').valueChanges.subscribe((n) => {
            if (n === 'none') {
                this.gpuCtrl.get('vendor').disable();
            }
            else {
                this.gpuCtrl.get('vendor').enable();
            }
        }));
        this.backend.getGPUVendors().subscribe(vendors => {
            this.installedVendors = new Set(vendors);
        });
    }
    // Vendor handling
    vendorTooltip(vendor) {
        return !this.installedVendors.has(vendor.limitsKey)
            ? $localize `There are currently no ${vendor.uiName} GPUs in your cluster.`
            : '';
    }
    // Custom Validation
    getVendorError() {
        const vendorCtrl = this.parentForm.get('gpus').get('vendor');
        if (vendorCtrl.hasError('vendorNullName')) {
            return $localize `You must also specify the GPU Vendor for the assigned GPUs`;
        }
    }
    vendorWithNum() {
        // Make sure that if the user has specified a number of GPUs
        // that they also specify the GPU vendor
        return (control) => {
            const num = this.parentForm.get('gpus').get('num').value;
            const vendor = this.parentForm.get('gpus').get('vendor').value;
            if (num !== 'none' && vendor === '') {
                return { vendorNullName: true };
            }
            else {
                return null;
            }
        };
    }
}
FormGpusComponent.ɵfac = function FormGpusComponent_Factory(t) { return new (t || FormGpusComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_services_backend_service__WEBPACK_IMPORTED_MODULE_0__.JWABackendService)); };
FormGpusComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: FormGpusComponent, selectors: [["app-form-gpus"]], inputs: { parentForm: "parentForm", vendors: "vendors" }, decls: 16, vars: 4, consts: function () { let i18n_0; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_3840111939816305457$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_GPUS_FORM_GPUS_COMPONENT_TS_1 = goog.getMsg("GPUs");
        i18n_0 = MSG_EXTERNAL_3840111939816305457$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_GPUS_FORM_GPUS_COMPONENT_TS_1;
    }
    else {
        i18n_0 = $localize `:␟126c1d5ce9129e10a0328764227f045806ab0e50␟3840111939816305457:GPUs`;
    } let i18n_2; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_2175421158486456021$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_GPUS_FORM_GPUS_COMPONENT_TS_3 = goog.getMsg("Number of GPUs");
        i18n_2 = MSG_EXTERNAL_2175421158486456021$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_GPUS_FORM_GPUS_COMPONENT_TS_3;
    }
    else {
        i18n_2 = $localize `:␟6bc1c2ef4d2045c6f6a152e10bb00365a381c804␟2175421158486456021:Number of GPUs`;
    } let i18n_4; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        /**
         * @desc option None
         */
        const MSG_EXTERNAL_6252070156626006029$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_GPUS_FORM_GPUS_COMPONENT_TS_5 = goog.getMsg("None");
        i18n_4 = MSG_EXTERNAL_6252070156626006029$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_GPUS_FORM_GPUS_COMPONENT_TS_5;
    }
    else {
        i18n_4 = $localize `:option None␟a2f14a73f7a6e94479f67423cc51102da8d6f524␟6252070156626006029:None`;
    } let i18n_6; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_4636121350345035366$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_GPUS_FORM_GPUS_COMPONENT_TS_7 = goog.getMsg("GPU Vendor");
        i18n_6 = MSG_EXTERNAL_4636121350345035366$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_GPUS_FORM_GPUS_COMPONENT_TS_7;
    }
    else {
        i18n_6 = $localize `:␟f49d3e9fe3286f0f5d07d5323db3cd6333331489␟4636121350345035366:GPU Vendor`;
    } return [["title", i18n_0], [1, "row", 3, "formGroup"], ["appearance", "outline", 1, "column"], i18n_2, ["matNativeControl", "", "formControlName", "num"], ["value", "none"], i18n_4, [3, "value", 4, "ngFor", "ngForOf"], i18n_6, ["matNativeControl", "", "formControlName", "vendor", "id", "gpu-vendor"], [3, "value", "matTooltip", 4, "ngFor", "ngForOf"], [3, "value"], [3, "value", "matTooltip"]]; }, template: function FormGpusComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "lib-form-section", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "mat-form-field", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵi18n"](4, 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "mat-select", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "mat-option", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵi18n"](7, 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](8, FormGpusComponent_mat_option_8_Template, 2, 2, "mat-option", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](9, "mat-form-field", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](10, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵi18n"](11, 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "mat-select", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](13, FormGpusComponent_mat_option_13_Template, 2, 3, "mat-option", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](14, "mat-error");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](15);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formGroup", ctx.parentForm.get("gpus"));
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx.gpusCount);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx.vendors);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](ctx.getVendorError());
    } }, directives: [kubeflow__WEBPACK_IMPORTED_MODULE_3__.FormSectionComponent, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormGroupDirective, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_5__.MatFormField, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_5__.MatLabel, _angular_material_select__WEBPACK_IMPORTED_MODULE_6__.MatSelect, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControlName, _angular_material_core__WEBPACK_IMPORTED_MODULE_7__.MatOption, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgForOf, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_5__.MatError, _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_9__.MatTooltip], styles: [".mat-slide-toggle[_ngcontent-%COMP%] {\n  margin-bottom: 0.6rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZvcm0tZ3B1cy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHFCQUFBO0FBQ0YiLCJmaWxlIjoiZm9ybS1ncHVzLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm1hdC1zbGlkZS10b2dnbGUge1xuICBtYXJnaW4tYm90dG9tOiAwLjZyZW07XG59XG4iXX0= */"] });


/***/ }),

/***/ 1330:
/*!****************************************************************************!*\
  !*** ./src/app/pages/form/form-default/form-image/form-image.component.ts ***!
  \****************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormImageComponent": function() { return /* binding */ FormImageComponent; }
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 826);
/* harmony import */ var _app_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @app/environment */ 2340);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/icon */ 6627);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/platform-browser */ 9075);
/* harmony import */ var kubeflow__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! kubeflow */ 872);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_material_button_toggle__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/button-toggle */ 2542);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/form-field */ 8295);
/* harmony import */ var _angular_material_select__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/select */ 7441);
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/material/core */ 7817);
/* harmony import */ var _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/material/checkbox */ 7539);
/* harmony import */ var _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/material/tooltip */ 1436);
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/material/input */ 3166);
















function FormImageComponent_mat_checkbox_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-checkbox", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵi18n"](1, 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formControl", ctx_r0.parentForm.get("customImageCheck"));
} }
function FormImageComponent_mat_button_toggle_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-button-toggle", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](1, "mat-icon", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} }
function FormImageComponent_mat_button_toggle_7_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-button-toggle", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](1, "mat-icon", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} }
function FormImageComponent_mat_form_field_8_mat_option_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-option", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const img_r8 = ctx.$implicit;
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("value", img_r8)("matTooltip", img_r8);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", ctx_r7.imageDisplayName(img_r8), " ");
} }
function FormImageComponent_mat_form_field_8_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-form-field", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵi18n"](2, 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "mat-select", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](4, FormImageComponent_mat_form_field_8_mat_option_4_Template, 2, 3, "mat-option", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "mat-error");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵi18n"](6, 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formControl", ctx_r3.parentForm.get("image"));
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx_r3.images);
} }
function FormImageComponent_mat_form_field_9_mat_option_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-option", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const img_r10 = ctx.$implicit;
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("value", img_r10)("matTooltip", img_r10);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", ctx_r9.imageDisplayName(img_r10), " ");
} }
function FormImageComponent_mat_form_field_9_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-form-field", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵi18n"](2, 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "mat-select", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](4, FormImageComponent_mat_form_field_9_mat_option_4_Template, 2, 3, "mat-option", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "mat-error");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵi18n"](6, 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formControl", ctx_r4.parentForm.get("imageGroupOne"));
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx_r4.imagesGroupOne);
} }
function FormImageComponent_mat_form_field_10_mat_option_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-option", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const img_r12 = ctx.$implicit;
    const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("value", img_r12)("matTooltip", img_r12);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", ctx_r11.imageDisplayName(img_r12), " ");
} }
function FormImageComponent_mat_form_field_10_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-form-field", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵi18n"](2, 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "mat-select", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](4, FormImageComponent_mat_form_field_10_mat_option_4_Template, 2, 3, "mat-option", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "mat-error");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵi18n"](6, 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formControl", ctx_r5.parentForm.get("imageGroupTwo"));
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx_r5.imagesGroupTwo);
} }
function FormImageComponent_mat_form_field_11_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-form-field", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵi18n"](2, 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](3, "input", 37, 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "mat-error");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵi18n"](6, 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formControl", ctx_r6.parentForm.get("customImage"));
} }
class FormImageComponent {
    constructor(iconRegistry, sanitizer) {
        this.subs = new rxjs__WEBPACK_IMPORTED_MODULE_2__.Subscription();
        iconRegistry.addSvgIcon('jupyterlab', sanitizer.bypassSecurityTrustResourceUrl(_app_environment__WEBPACK_IMPORTED_MODULE_0__.environment.jupyterlabLogo));
        iconRegistry.addSvgIcon('group-one', sanitizer.bypassSecurityTrustResourceUrl(_app_environment__WEBPACK_IMPORTED_MODULE_0__.environment.groupOneLogo));
        iconRegistry.addSvgIcon('group-two', sanitizer.bypassSecurityTrustResourceUrl(_app_environment__WEBPACK_IMPORTED_MODULE_0__.environment.groupTwoLogo));
    }
    ngOnInit() {
        this.subs.add(this.parentForm.get('customImageCheck').valueChanges.subscribe(check => {
            // Make sure that the use will insert and Image value
            if (check) {
                this.parentForm.get('customImage').setValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required);
                this.parentForm.get('image').setValidators([]);
                this.parentForm.get('imageGroupOne').setValidators([]);
                this.parentForm.get('imageGroupTwo').setValidators([]);
            }
            this.parentForm.get('serverType').valueChanges.subscribe(selection => {
                if (selection === 'jupyter') {
                    this.parentForm.get('customImage').setValidators([]);
                    this.parentForm.get('image').setValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required);
                    this.parentForm.get('imageGroupOne').setValidators([]);
                    this.parentForm.get('imageGroupTwo').setValidators([]);
                }
                else if (selection === 'group-one') {
                    this.parentForm.get('customImage').setValidators([]);
                    this.parentForm.get('image').setValidators([]);
                    this.parentForm
                        .get('imageGroupOne')
                        .setValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required);
                    this.parentForm.get('imageGroupTwo').setValidators([]);
                }
                else if (selection === 'group-two') {
                    this.parentForm.get('customImage').setValidators([]);
                    this.parentForm.get('image').setValidators([]);
                    this.parentForm.get('imageGroupOne').setValidators([]);
                    this.parentForm
                        .get('imageGroupTwo')
                        .setValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required);
                }
                this.parentForm.get('image').updateValueAndValidity();
                this.parentForm.get('imageGroupOne').updateValueAndValidity();
                this.parentForm.get('imageGroupTwo').updateValueAndValidity();
            });
            this.parentForm.get('customImage').updateValueAndValidity();
            this.parentForm.get('serverType').updateValueAndValidity();
        }));
    }
    ngOnDestroy() {
        this.subs.unsubscribe();
    }
    imageDisplayName(image) {
        const [name, tag = null] = image.split(':');
        let tokens = name.split('/');
        if (this.hideRegistry && tokens.length > 1 && tokens[0].includes('.')) {
            tokens.shift();
        }
        let displayName = tokens.join('/');
        if (!this.hideTag && tag !== null) {
            displayName = `${displayName}:${tag}`;
        }
        return displayName;
    }
}
FormImageComponent.ɵfac = function FormImageComponent_Factory(t) { return new (t || FormImageComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_material_icon__WEBPACK_IMPORTED_MODULE_4__.MatIconRegistry), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_5__.DomSanitizer)); };
FormImageComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: FormImageComponent, selectors: [["app-form-image"]], inputs: { parentForm: "parentForm", images: "images", imagesGroupOne: "imagesGroupOne", imagesGroupTwo: "imagesGroupTwo", allowCustomImage: "allowCustomImage", hideRegistry: "hideRegistry", hideTag: "hideTag" }, decls: 24, vars: 9, consts: function () { let i18n_0; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        /**
         * @desc Title for the Image section of the form
         */
        const MSG_EXTERNAL_5875415455432432790$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_IMAGE_FORM_IMAGE_COMPONENT_TS_1 = goog.getMsg("Docker Image");
        i18n_0 = MSG_EXTERNAL_5875415455432432790$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_IMAGE_FORM_IMAGE_COMPONENT_TS_1;
    }
    else {
        i18n_0 = $localize `:Title for the Image section of the form␟1f35754236a77f283c76f144f8ca55a2590b2897␟5875415455432432790:Docker Image`;
    } let i18n_2; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_939934962370125405$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_IMAGE_FORM_IMAGE_COMPONENT_TS_3 = goog.getMsg("Image pull policy");
        i18n_2 = MSG_EXTERNAL_939934962370125405$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_IMAGE_FORM_IMAGE_COMPONENT_TS_3;
    }
    else {
        i18n_2 = $localize `:␟d8aa5559daf4007f0eff2ea4e5ea28d1ac49e105␟939934962370125405:Image pull policy`;
    } let i18n_4; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        /**
         * @desc ImagePullPolicy: Always
         */
        const MSG_EXTERNAL_4040404765739455767$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_IMAGE_FORM_IMAGE_COMPONENT_TS_5 = goog.getMsg(" Always ");
        i18n_4 = MSG_EXTERNAL_4040404765739455767$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_IMAGE_FORM_IMAGE_COMPONENT_TS_5;
    }
    else {
        i18n_4 = $localize `:ImagePullPolicy\: Always␟6408a210e22cb458fc925aad796666f5a1198662␟4040404765739455767: Always `;
    } let i18n_6; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        /**
         * @desc ImagePullPolicy: IfNotPresent
         */
        const MSG_EXTERNAL_419294875390109671$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_IMAGE_FORM_IMAGE_COMPONENT_TS_7 = goog.getMsg(" IfNotPresent ");
        i18n_6 = MSG_EXTERNAL_419294875390109671$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_IMAGE_FORM_IMAGE_COMPONENT_TS_7;
    }
    else {
        i18n_6 = $localize `:ImagePullPolicy\: IfNotPresent␟7a084ea40b1b4313d812cfc6c7f41333f5021c45␟419294875390109671: IfNotPresent `;
    } let i18n_8; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        /**
         * @desc ImagePullPolicy: Never
         */
        const MSG_EXTERNAL_1115993704646362951$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_IMAGE_FORM_IMAGE_COMPONENT_TS_9 = goog.getMsg(" Never ");
        i18n_8 = MSG_EXTERNAL_1115993704646362951$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_IMAGE_FORM_IMAGE_COMPONENT_TS_9;
    }
    else {
        i18n_8 = $localize `:ImagePullPolicy\: Never␟414e175f751673aebbcac9ac0ee64fb16c508e8d␟1115993704646362951: Never `;
    } let i18n_10; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_6395134205563672303$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_IMAGE_FORM_IMAGE_COMPONENT_TS__11 = goog.getMsg(" Custom Image ");
        i18n_10 = MSG_EXTERNAL_6395134205563672303$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_IMAGE_FORM_IMAGE_COMPONENT_TS__11;
    }
    else {
        i18n_10 = $localize `:␟059242c0f52aaeff3ed373739d818de15acc9751␟6395134205563672303: Custom Image `;
    } let i18n_12; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_3012906865384504293$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_IMAGE_FORM_IMAGE_COMPONENT_TS__13 = goog.getMsg("Image");
        i18n_12 = MSG_EXTERNAL_3012906865384504293$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_IMAGE_FORM_IMAGE_COMPONENT_TS__13;
    }
    else {
        i18n_12 = $localize `:␟a5f9ba9bb9faa8284bcadb1cdbc6aaf969e9c4bb␟3012906865384504293:Image`;
    } let i18n_14; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_5875415455432432790$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_IMAGE_FORM_IMAGE_COMPONENT_TS__15 = goog.getMsg("Docker Image");
        i18n_14 = MSG_EXTERNAL_5875415455432432790$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_IMAGE_FORM_IMAGE_COMPONENT_TS__15;
    }
    else {
        i18n_14 = $localize `:␟1f35754236a77f283c76f144f8ca55a2590b2897␟5875415455432432790:Docker Image`;
    } let i18n_16; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_3095176897800627036$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_IMAGE_FORM_IMAGE_COMPONENT_TS__17 = goog.getMsg("Please provide an Image to use");
        i18n_16 = MSG_EXTERNAL_3095176897800627036$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_IMAGE_FORM_IMAGE_COMPONENT_TS__17;
    }
    else {
        i18n_16 = $localize `:␟817830b30c16a82f008858d8f7a6d64e7826a2b2␟3095176897800627036:Please provide an Image to use`;
    } let i18n_18; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_3012906865384504293$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_IMAGE_FORM_IMAGE_COMPONENT_TS__19 = goog.getMsg("Image");
        i18n_18 = MSG_EXTERNAL_3012906865384504293$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_IMAGE_FORM_IMAGE_COMPONENT_TS__19;
    }
    else {
        i18n_18 = $localize `:␟a5f9ba9bb9faa8284bcadb1cdbc6aaf969e9c4bb␟3012906865384504293:Image`;
    } let i18n_20; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_5875415455432432790$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_IMAGE_FORM_IMAGE_COMPONENT_TS__21 = goog.getMsg("Docker Image");
        i18n_20 = MSG_EXTERNAL_5875415455432432790$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_IMAGE_FORM_IMAGE_COMPONENT_TS__21;
    }
    else {
        i18n_20 = $localize `:␟1f35754236a77f283c76f144f8ca55a2590b2897␟5875415455432432790:Docker Image`;
    } let i18n_22; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_3095176897800627036$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_IMAGE_FORM_IMAGE_COMPONENT_TS__23 = goog.getMsg("Please provide an Image to use");
        i18n_22 = MSG_EXTERNAL_3095176897800627036$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_IMAGE_FORM_IMAGE_COMPONENT_TS__23;
    }
    else {
        i18n_22 = $localize `:␟817830b30c16a82f008858d8f7a6d64e7826a2b2␟3095176897800627036:Please provide an Image to use`;
    } let i18n_24; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_3012906865384504293$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_IMAGE_FORM_IMAGE_COMPONENT_TS__25 = goog.getMsg("Image");
        i18n_24 = MSG_EXTERNAL_3012906865384504293$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_IMAGE_FORM_IMAGE_COMPONENT_TS__25;
    }
    else {
        i18n_24 = $localize `:␟a5f9ba9bb9faa8284bcadb1cdbc6aaf969e9c4bb␟3012906865384504293:Image`;
    } let i18n_26; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_5875415455432432790$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_IMAGE_FORM_IMAGE_COMPONENT_TS__27 = goog.getMsg("Docker Image");
        i18n_26 = MSG_EXTERNAL_5875415455432432790$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_IMAGE_FORM_IMAGE_COMPONENT_TS__27;
    }
    else {
        i18n_26 = $localize `:␟1f35754236a77f283c76f144f8ca55a2590b2897␟5875415455432432790:Docker Image`;
    } let i18n_28; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_3095176897800627036$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_IMAGE_FORM_IMAGE_COMPONENT_TS__29 = goog.getMsg("Please provide an Image to use");
        i18n_28 = MSG_EXTERNAL_3095176897800627036$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_IMAGE_FORM_IMAGE_COMPONENT_TS__29;
    }
    else {
        i18n_28 = $localize `:␟817830b30c16a82f008858d8f7a6d64e7826a2b2␟3095176897800627036:Please provide an Image to use`;
    } let i18n_30; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_6572562220695316082$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_IMAGE_FORM_IMAGE_COMPONENT_TS__31 = goog.getMsg("Custom Image");
        i18n_30 = MSG_EXTERNAL_6572562220695316082$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_IMAGE_FORM_IMAGE_COMPONENT_TS__31;
    }
    else {
        i18n_30 = $localize `:␟2f0e016d5caf4e42f1b6f60dc9fe80e2b98f5287␟6572562220695316082:Custom Image`;
    } let i18n_32; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_3095176897800627036$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_IMAGE_FORM_IMAGE_COMPONENT_TS__33 = goog.getMsg("Please provide an Image to use");
        i18n_32 = MSG_EXTERNAL_3095176897800627036$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_IMAGE_FORM_IMAGE_COMPONENT_TS__33;
    }
    else {
        i18n_32 = $localize `:␟817830b30c16a82f008858d8f7a6d64e7826a2b2␟3095176897800627036:Please provide an Image to use`;
    } return [["title", i18n_0], [1, "flex-column"], [3, "formControl", 4, "ngIf"], ["attr.aria-label", "Server Type", 1, "server-type-wrapper", 3, "formControl"], ["value", "jupyter", "attr.aria-label", "Use JupyterLab based server"], ["svgIcon", "jupyterlab", 1, "server-type"], ["value", "group-one", "attr.aria-label", "Use Group One based server", 4, "ngIf"], ["value", "group-two", "attr.aria-label", "Use Group Two based server", 4, "ngIf"], ["class", "wide", "appearance", "outline", 4, "ngIf"], [1, "row"], ["appearance", "outline", 1, "column"], i18n_2, [3, "formControl"], ["value", "Always"], i18n_4, ["value", "IfNotPresent"], i18n_6, ["value", "Never"], i18n_8, i18n_10, ["value", "group-one", "attr.aria-label", "Use Group One based server"], ["svgIcon", "group-one", 1, "server-type"], ["value", "group-two", "attr.aria-label", "Use Group Two based server"], ["svgIcon", "group-two", 1, "server-type"], ["appearance", "outline", 1, "wide"], i18n_12, ["placeholder", i18n_14, 3, "formControl"], [3, "value", "matTooltip", 4, "ngFor", "ngForOf"], i18n_16, [3, "value", "matTooltip"], i18n_18, ["placeholder", i18n_20, 3, "formControl"], i18n_22, i18n_24, ["placeholder", i18n_26, 3, "formControl"], i18n_28, i18n_30, ["matInput", "", "placeholder", "Provide a custom Image", 3, "formControl"], ["cstmimg", ""], i18n_32]; }, template: function FormImageComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "lib-form-section", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](2, FormImageComponent_mat_checkbox_2_Template, 2, 1, "mat-checkbox", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "mat-button-toggle-group", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "mat-button-toggle", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](5, "mat-icon", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](6, FormImageComponent_mat_button_toggle_6_Template, 2, 0, "mat-button-toggle", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](7, FormImageComponent_mat_button_toggle_7_Template, 2, 0, "mat-button-toggle", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](8, FormImageComponent_mat_form_field_8_Template, 7, 2, "mat-form-field", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](9, FormImageComponent_mat_form_field_9_Template, 7, 2, "mat-form-field", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](10, FormImageComponent_mat_form_field_10_Template, 7, 2, "mat-form-field", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](11, FormImageComponent_mat_form_field_11_Template, 7, 1, "mat-form-field", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "lib-advanced-options");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](13, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](14, "mat-form-field", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](15, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵi18n"](16, 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](17, "mat-select", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](18, "mat-option", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵi18n"](19, 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](20, "mat-option", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵi18n"](21, 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](22, "mat-option", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵi18n"](23, 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } if (rf & 2) {
        let tmp_2_0;
        let tmp_3_0;
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.allowCustomImage);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formControl", ctx.parentForm.get("serverType"));
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", !((tmp_2_0 = ctx.parentForm.get("imageGroupOne")) == null ? null : tmp_2_0.disabled));
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", !((tmp_3_0 = ctx.parentForm.get("imageGroupTwo")) == null ? null : tmp_3_0.disabled));
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", !(ctx.parentForm == null ? null : ctx.parentForm.value.customImageCheck) && (ctx.parentForm == null ? null : ctx.parentForm.value.serverType) === "jupyter");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", !(ctx.parentForm == null ? null : ctx.parentForm.value.customImageCheck) && (ctx.parentForm == null ? null : ctx.parentForm.value.serverType) === "group-one");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", !(ctx.parentForm == null ? null : ctx.parentForm.value.customImageCheck) && (ctx.parentForm == null ? null : ctx.parentForm.value.serverType) === "group-two");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.parentForm == null ? null : ctx.parentForm.value.customImageCheck);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formControl", ctx.parentForm.get("imagePullPolicy"));
    } }, directives: [kubeflow__WEBPACK_IMPORTED_MODULE_6__.FormSectionComponent, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgIf, _angular_material_button_toggle__WEBPACK_IMPORTED_MODULE_8__.MatButtonToggleGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControlDirective, _angular_material_button_toggle__WEBPACK_IMPORTED_MODULE_8__.MatButtonToggle, _angular_material_icon__WEBPACK_IMPORTED_MODULE_4__.MatIcon, kubeflow__WEBPACK_IMPORTED_MODULE_6__.AdvancedOptionsComponent, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__.MatFormField, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__.MatLabel, _angular_material_select__WEBPACK_IMPORTED_MODULE_10__.MatSelect, _angular_material_core__WEBPACK_IMPORTED_MODULE_11__.MatOption, _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_12__.MatCheckbox, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgForOf, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_9__.MatError, _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_13__.MatTooltip, _angular_material_input__WEBPACK_IMPORTED_MODULE_14__.MatInput, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.DefaultValueAccessor], styles: [".server-type[_ngcontent-%COMP%] {\n  height: 32px;\n  width: 150px;\n}\n\n.server-type-wrapper[_ngcontent-%COMP%] {\n  margin-bottom: 1rem;\n  width: -webkit-fit-content;\n  width: -moz-fit-content;\n  width: fit-content;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZvcm0taW1hZ2UuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxZQUFBO0VBQ0EsWUFBQTtBQUNGOztBQUVBO0VBQ0UsbUJBQUE7RUFDQSwwQkFBQTtFQUFBLHVCQUFBO0VBQUEsa0JBQUE7QUFDRiIsImZpbGUiOiJmb3JtLWltYWdlLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnNlcnZlci10eXBlIHtcbiAgaGVpZ2h0OiAzMnB4O1xuICB3aWR0aDogMTUwcHg7XG59XG5cbi5zZXJ2ZXItdHlwZS13cmFwcGVyIHtcbiAgbWFyZ2luLWJvdHRvbTogMXJlbTtcbiAgd2lkdGg6IGZpdC1jb250ZW50O1xufVxuIl19 */"] });


/***/ }),

/***/ 4249:
/*!**************************************************************************!*\
  !*** ./src/app/pages/form/form-default/form-name/form-name.component.ts ***!
  \**************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormNameComponent": function() { return /* binding */ FormNameComponent; }
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 826);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var src_app_services_backend_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/services/backend.service */ 600);
/* harmony import */ var kubeflow__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! kubeflow */ 872);




class FormNameComponent {
    constructor(backend, ns) {
        this.backend = backend;
        this.ns = ns;
        this.subscriptions = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subscription();
        this.existingNotebooks = new Set();
    }
    ngOnInit() {
        // Keep track of the existing Notebooks in the selected Namespace
        // Use these names to check if the input name exists
        const nsSub = this.ns.getSelectedNamespace().subscribe(ns => {
            this.backend.getNotebooks(ns).subscribe(notebooks => {
                this.existingNotebooks.clear();
                notebooks.map(nb => this.existingNotebooks.add(nb.name));
            });
        });
        this.subscriptions.add(nsSub);
    }
    ngOnDestroy() {
        this.subscriptions.unsubscribe();
    }
}
FormNameComponent.ɵfac = function FormNameComponent_Factory(t) { return new (t || FormNameComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_services_backend_service__WEBPACK_IMPORTED_MODULE_0__.JWABackendService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](kubeflow__WEBPACK_IMPORTED_MODULE_3__.NamespaceService)); };
FormNameComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({ type: FormNameComponent, selectors: [["app-form-name-namespace"]], inputs: { parentForm: "parentForm" }, decls: 2, vars: 3, consts: function () { let i18n_0; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_8953033926734869941$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_NAME_FORM_NAME_COMPONENT_TS_1 = goog.getMsg("Name");
        i18n_0 = MSG_EXTERNAL_8953033926734869941$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_NAME_FORM_NAME_COMPONENT_TS_1;
    }
    else {
        i18n_0 = $localize `:␟cff1428d10d59d14e45edec3c735a27b5482db59␟8953033926734869941:Name`;
    } return [["title", i18n_0], ["maxLength", "40", "resourceName", "Notebook Server", 3, "nameControl", "namespaceControl", "existingNames"]]; }, template: function FormNameComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "lib-form-section", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](1, "lib-form-name-namespace-inputs", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("nameControl", ctx.parentForm.get("name"))("namespaceControl", ctx.parentForm.get("namespace"))("existingNames", ctx.existingNotebooks);
    } }, directives: [kubeflow__WEBPACK_IMPORTED_MODULE_3__.FormSectionComponent, kubeflow__WEBPACK_IMPORTED_MODULE_3__.NameNamespaceInputsComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJmb3JtLW5hbWUuY29tcG9uZW50LnNjc3MifQ== */"] });


/***/ }),

/***/ 4537:
/*!**************************************************************************************************!*\
  !*** ./src/app/pages/form/form-default/form-workspace-volume/form-workspace-volume.component.ts ***!
  \**************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormWorkspaceVolumeComponent": function() { return /* binding */ FormWorkspaceVolumeComponent; }
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 826);
/* harmony import */ var src_app_shared_utils_volumes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/shared/utils/volumes */ 562);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var kubeflow__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! kubeflow */ 872);
/* harmony import */ var _angular_material_expansion__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/expansion */ 2976);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/button */ 1095);
/* harmony import */ var _volume_mount_mount_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../volume/mount/mount.component */ 8758);
/* harmony import */ var _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/tooltip */ 1436);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/material/icon */ 6627);
/* harmony import */ var _volume_existing_existing_volume_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../volume/existing/existing-volume.component */ 9335);
/* harmony import */ var _volume_new_new_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../volume/new/new.component */ 4129);












function FormWorkspaceVolumeComponent_mat_expansion_panel_2_ng_container_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("matTooltip", ctx_r1.getVolumeName(ctx_r1.volGroup.value));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", ctx_r1.getVolumeName(ctx_r1.volGroup.value), ", ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"]("", ctx_r1.getNewVolumeType(ctx_r1.volGroup.value), ",");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx_r1.getNewVolumeSize(ctx_r1.volGroup.value));
} }
function FormWorkspaceVolumeComponent_mat_expansion_panel_2_ng_container_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("matTooltip", ctx_r2.getVolumeName(ctx_r2.volGroup.value));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", ctx_r2.getVolumeName(ctx_r2.volGroup.value), " ");
} }
function FormWorkspaceVolumeComponent_mat_expansion_panel_2_mat_icon_8_Template(rf, ctx) { if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "mat-icon", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function FormWorkspaceVolumeComponent_mat_expansion_panel_2_mat_icon_8_Template_mat_icon_click_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r9); const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2); return ctx_r8.onDelete($event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " delete ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function FormWorkspaceVolumeComponent_mat_expansion_panel_2_mat_icon_9_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "mat-icon", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " expand_more ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function FormWorkspaceVolumeComponent_mat_expansion_panel_2_mat_icon_10_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "mat-icon", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " expand_less ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function FormWorkspaceVolumeComponent_mat_expansion_panel_2_app_existing_volume_12_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "app-existing-volume", 14);
} if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("volGroup", ctx_r6.volGroup);
} }
function FormWorkspaceVolumeComponent_mat_expansion_panel_2_app_new_volume_13_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "app-new-volume", 21);
} if (rf & 2) {
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("volGroup", ctx_r7.volGroup)("externalName", ctx_r7.externalName);
} }
function FormWorkspaceVolumeComponent_mat_expansion_panel_2_Template(rf, ctx) { if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "mat-expansion-panel", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("opened", function FormWorkspaceVolumeComponent_mat_expansion_panel_2_Template_mat_expansion_panel_opened_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r11); const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return ctx_r10.panelOpen = true; })("closed", function FormWorkspaceVolumeComponent_mat_expansion_panel_2_Template_mat_expansion_panel_closed_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r11); const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return ctx_r12.panelOpen = false; });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "mat-expansion-panel-header");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "mat-panel-title");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "mat-panel-description");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](5, FormWorkspaceVolumeComponent_mat_expansion_panel_2_ng_container_5_Template, 7, 4, "ng-container", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](6, FormWorkspaceVolumeComponent_mat_expansion_panel_2_ng_container_6_Template, 3, 2, "ng-container", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](8, FormWorkspaceVolumeComponent_mat_expansion_panel_2_mat_icon_8_Template, 2, 0, "mat-icon", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](9, FormWorkspaceVolumeComponent_mat_expansion_panel_2_mat_icon_9_Template, 2, 0, "mat-icon", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](10, FormWorkspaceVolumeComponent_mat_expansion_panel_2_mat_icon_10_Template, 2, 0, "mat-icon", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](12, FormWorkspaceVolumeComponent_mat_expansion_panel_2_app_existing_volume_12_Template, 1, 1, "app-existing-volume", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](13, FormWorkspaceVolumeComponent_mat_expansion_panel_2_app_new_volume_13_Template, 1, 2, "app-new-volume", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](14, "app-volume-mount", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", ctx_r0.getVolumeTitle(ctx_r0.volGroup.value), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r0.volGroup.get("newPvc"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r0.volGroup.get("existingSource"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !ctx_r0.readonly);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !ctx_r0.panelOpen);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r0.panelOpen);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵclassProp"]("readonly", ctx_r0.readonly);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r0.volGroup.get("existingSource"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r0.volGroup.get("newPvc"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("volGroup", ctx_r0.volGroup);
} }
class FormWorkspaceVolumeComponent {
    constructor(snackBar) {
        this.snackBar = snackBar;
        this.panelOpen = false;
        this.subscriptions = new rxjs__WEBPACK_IMPORTED_MODULE_5__.Subscription();
        this.getVolumeTitle = src_app_shared_utils_volumes__WEBPACK_IMPORTED_MODULE_0__.getVolumeTitle;
        this.getVolumeName = src_app_shared_utils_volumes__WEBPACK_IMPORTED_MODULE_0__.getVolumeName;
        this.getNewVolumeSize = src_app_shared_utils_volumes__WEBPACK_IMPORTED_MODULE_0__.getNewVolumeSize;
        this.getNewVolumeType = src_app_shared_utils_volumes__WEBPACK_IMPORTED_MODULE_0__.getNewVolumeType;
    }
    ngOnInit() { }
    ngOnDestroy() {
        this.subscriptions.unsubscribe();
        this.snackBar.close();
    }
    onDelete(event) {
        event.stopPropagation();
        this.removeVolumeFields(this.volGroup);
        this.volGroup.disable();
        this.panelOpen = false;
    }
    addNewVolume() {
        this.volGroup.addControl('newPvc', (0,src_app_shared_utils_volumes__WEBPACK_IMPORTED_MODULE_0__.createNewPvcFormGroup)());
        this.volGroup.get('mount').setValue('/home/jovyan');
        this.volGroup.enable();
        this.volGroup.get('newPvc.spec.storageClassName').disable();
    }
    attachExistingVolume() {
        this.volGroup.addControl('existingSource', (0,src_app_shared_utils_volumes__WEBPACK_IMPORTED_MODULE_0__.createExistingSourceFormGroup)());
        this.volGroup.get('mount').setValue('/home/jovyan');
        this.volGroup.enable();
    }
    removeVolumeFields(vol) {
        if (vol.get('newPvc')) {
            vol.removeControl('newPvc');
        }
        if (vol.get('existingSource')) {
            vol.removeControl('existingSource');
        }
    }
}
FormWorkspaceVolumeComponent.ɵfac = function FormWorkspaceVolumeComponent_Factory(t) { return new (t || FormWorkspaceVolumeComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](kubeflow__WEBPACK_IMPORTED_MODULE_6__.SnackBarService)); };
FormWorkspaceVolumeComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({ type: FormWorkspaceVolumeComponent, selectors: [["app-form-workspace-volume"]], inputs: { readonly: "readonly", volGroup: "volGroup", externalName: "externalName" }, decls: 8, vars: 3, consts: function () { let i18n_0; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_3398373965382400215$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_WORKSPACE_VOLUME_FORM_WORKSPACE_VOLUME_COMPONENT_TS_1 = goog.getMsg("Workspace Volume");
        i18n_0 = MSG_EXTERNAL_3398373965382400215$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_WORKSPACE_VOLUME_FORM_WORKSPACE_VOLUME_COMPONENT_TS_1;
    }
    else {
        i18n_0 = $localize `:␟5f02a6412cf09bf5dd273aeb77215ce0ef343716␟3398373965382400215:Workspace Volume`;
    } let i18n_2; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_8863614977842315994$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_WORKSPACE_VOLUME_FORM_WORKSPACE_VOLUME_COMPONENT_TS_3 = goog.getMsg("Volume that will be mounted in you home directory.");
        i18n_2 = MSG_EXTERNAL_8863614977842315994$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_WORKSPACE_VOLUME_FORM_WORKSPACE_VOLUME_COMPONENT_TS_3;
    }
    else {
        i18n_2 = $localize `:␟bfd11a174dc7f530bd30c5031ab555cc76e2b0ed␟8863614977842315994:Volume that will be mounted in you home directory.`;
    } let i18n_4; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_1142047506147649422$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_WORKSPACE_VOLUME_FORM_WORKSPACE_VOLUME_COMPONENT_TS_5 = goog.getMsg(" + Add new volume ");
        i18n_4 = MSG_EXTERNAL_1142047506147649422$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_WORKSPACE_VOLUME_FORM_WORKSPACE_VOLUME_COMPONENT_TS_5;
    }
    else {
        i18n_4 = $localize `:␟912571feb5980547173477e4818f758118e83ca1␟1142047506147649422: + Add new volume `;
    } let i18n_6; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_1161391785498397314$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_WORKSPACE_VOLUME_FORM_WORKSPACE_VOLUME_COMPONENT_TS_7 = goog.getMsg(" + Attach existing volume ");
        i18n_6 = MSG_EXTERNAL_1161391785498397314$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_WORKSPACE_VOLUME_FORM_WORKSPACE_VOLUME_COMPONENT_TS_7;
    }
    else {
        i18n_6 = $localize `:␟1b0c6c93b58dac1a8719f5ec525193b2357e5e24␟1161391785498397314: + Attach existing volume `;
    } let i18n_8; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_7200856845698679324$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_WORKSPACE_VOLUME_FORM_WORKSPACE_VOLUME_COMPONENT_TS__9 = goog.getMsg("Delete volume");
        i18n_8 = MSG_EXTERNAL_7200856845698679324$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_WORKSPACE_VOLUME_FORM_WORKSPACE_VOLUME_COMPONENT_TS__9;
    }
    else {
        i18n_8 = $localize `:␟e295c323cbcd6575dd493a8f2da7dd85d8d9706e␟7200856845698679324:Delete volume`;
    } let i18n_10; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_1568125515243307887$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_WORKSPACE_VOLUME_FORM_WORKSPACE_VOLUME_COMPONENT_TS__11 = goog.getMsg("Show volume details");
        i18n_10 = MSG_EXTERNAL_1568125515243307887$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_WORKSPACE_VOLUME_FORM_WORKSPACE_VOLUME_COMPONENT_TS__11;
    }
    else {
        i18n_10 = $localize `:␟66b97ad4367fde1abbcb9fb8a4910c3f03b6af89␟1568125515243307887:Show volume details`;
    } let i18n_12; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_3475484794929439395$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_WORKSPACE_VOLUME_FORM_WORKSPACE_VOLUME_COMPONENT_TS__13 = goog.getMsg("Hide volume details");
        i18n_12 = MSG_EXTERNAL_3475484794929439395$$SRC_APP_PAGES_FORM_FORM_DEFAULT_FORM_WORKSPACE_VOLUME_FORM_WORKSPACE_VOLUME_COMPONENT_TS__13;
    }
    else {
        i18n_12 = $localize `:␟80793a3166e187779e7a5fa2f80b043083bca4a5␟3475484794929439395:Hide volume details`;
    } return [["title", i18n_0, "text", i18n_2], ["hideToggle", "", 3, "opened", "closed", 4, "ngIf"], [1, "volume-buttons"], ["type", "button", "color", "primary", "mat-stroked-button", "", 3, "disabled", "click"], i18n_4, i18n_6, ["hideToggle", "", 3, "opened", "closed"], [4, "ngIf"], [1, "icons"], ["matTooltip", i18n_8, "class", "delete-icon", 3, "click", 4, "ngIf"], ["matTooltip", i18n_10, 4, "ngIf"], ["matTooltip", i18n_12, 4, "ngIf"], [3, "volGroup", 4, "ngIf"], [3, "volGroup", "externalName", 4, "ngIf"], [3, "volGroup"], [1, "pvc-name", "truncate", 3, "matTooltip"], [1, "pvc-type"], [1, "vol-name", "truncate", 3, "matTooltip"], ["matTooltip", i18n_8, 1, "delete-icon", 3, "click"], ["matTooltip", i18n_10], ["matTooltip", i18n_12], [3, "volGroup", "externalName"]]; }, template: function FormWorkspaceVolumeComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "lib-form-section", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "mat-accordion");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](2, FormWorkspaceVolumeComponent_mat_expansion_panel_2_Template, 15, 11, "mat-expansion-panel", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "button", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function FormWorkspaceVolumeComponent_Template_button_click_4_listener() { return ctx.addNewVolume(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵi18n"](5, 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "button", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function FormWorkspaceVolumeComponent_Template_button_click_6_listener() { return ctx.attachExistingVolume(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵi18n"](7, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !ctx.volGroup.disabled);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("disabled", !ctx.volGroup.disabled || ctx.readonly);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("disabled", !ctx.volGroup.disabled || ctx.readonly);
    } }, directives: [kubeflow__WEBPACK_IMPORTED_MODULE_6__.FormSectionComponent, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_7__.MatAccordion, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgIf, _angular_material_button__WEBPACK_IMPORTED_MODULE_9__.MatButton, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_7__.MatExpansionPanel, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_7__.MatExpansionPanelHeader, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_7__.MatExpansionPanelTitle, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_7__.MatExpansionPanelDescription, _volume_mount_mount_component__WEBPACK_IMPORTED_MODULE_1__.VolumeMountComponent, _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_10__.MatTooltip, _angular_material_icon__WEBPACK_IMPORTED_MODULE_11__.MatIcon, _volume_existing_existing_volume_component__WEBPACK_IMPORTED_MODULE_2__.ExistingVolumeComponent, _volume_new_new_component__WEBPACK_IMPORTED_MODULE_3__.NewVolumeComponent], styles: ["[_nghost-%COMP%] {\n  display: block;\n}\n\n.readonly[_ngcontent-%COMP%] {\n  pointer-events: none;\n}\n\n.pvc-name[_ngcontent-%COMP%] {\n  max-width: 200px;\n  margin-right: 0.3rem;\n}\n\n.pvc-type[_ngcontent-%COMP%] {\n  margin-right: 0.3rem;\n}\n\n.vol-name[_ngcontent-%COMP%] {\n  max-width: 400px;\n  margin-right: 0.3rem;\n}\n\n.icons[_ngcontent-%COMP%] {\n  margin-left: auto;\n  min-width: 88px;\n}\n\n.icons[_ngcontent-%COMP%]   .mat-icon[_ngcontent-%COMP%]:hover {\n  color: rgba(0, 0, 0, 0.72);\n}\n\n.icons[_ngcontent-%COMP%]   .delete-icon[_ngcontent-%COMP%] {\n  margin-right: 24px;\n  padding-left: 16px;\n}\n\n.mat-expansion-panel-header-description[_ngcontent-%COMP%] {\n  margin-right: 0;\n  display: flex;\n  align-items: center;\n}\n\n.mat-expansion-panel-header-title[_ngcontent-%COMP%] {\n  align-items: center;\n}\n\n.volume-buttons[_ngcontent-%COMP%] {\n  display: flex;\n  margin-top: 1rem;\n  margin-bottom: 1.5rem;\n}\n\n.volume-buttons[_ngcontent-%COMP%]   .mat-stroked-button[_ngcontent-%COMP%]:first-child {\n  margin-right: 1rem;\n}\n\n.volume-buttons[_ngcontent-%COMP%]   .mat-stroked-button[_ngcontent-%COMP%] {\n  width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZvcm0td29ya3NwYWNlLXZvbHVtZS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGNBQUE7QUFDRjs7QUFFQTtFQUNFLG9CQUFBO0FBQ0Y7O0FBRUE7RUFDRSxnQkFBQTtFQUNBLG9CQUFBO0FBQ0Y7O0FBRUE7RUFDRSxvQkFBQTtBQUNGOztBQUVBO0VBQ0UsZ0JBQUE7RUFDQSxvQkFBQTtBQUNGOztBQUVBO0VBQ0UsaUJBQUE7RUFDQSxlQUFBO0FBQ0Y7O0FBQ0U7RUFDRSwwQkFBQTtBQUNKOztBQUVFO0VBQ0Usa0JBQUE7RUFDQSxrQkFBQTtBQUFKOztBQUlBO0VBQ0UsZUFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtBQURGOztBQUlBO0VBQ0UsbUJBQUE7QUFERjs7QUFJQTtFQUNFLGFBQUE7RUFDQSxnQkFBQTtFQUNBLHFCQUFBO0FBREY7O0FBR0U7RUFDRSxrQkFBQTtBQURKOztBQUlFO0VBQ0UsV0FBQTtBQUZKIiwiZmlsZSI6ImZvcm0td29ya3NwYWNlLXZvbHVtZS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IHtcbiAgZGlzcGxheTogYmxvY2s7XG59XG5cbi5yZWFkb25seSB7XG4gIHBvaW50ZXItZXZlbnRzOiBub25lO1xufVxuXG4ucHZjLW5hbWUge1xuICBtYXgtd2lkdGg6IDIwMHB4O1xuICBtYXJnaW4tcmlnaHQ6IDAuM3JlbTtcbn1cblxuLnB2Yy10eXBlIHtcbiAgbWFyZ2luLXJpZ2h0OiAwLjNyZW07XG59XG5cbi52b2wtbmFtZSB7XG4gIG1heC13aWR0aDogNDAwcHg7XG4gIG1hcmdpbi1yaWdodDogMC4zcmVtO1xufVxuXG4uaWNvbnMge1xuICBtYXJnaW4tbGVmdDogYXV0bztcbiAgbWluLXdpZHRoOiA4OHB4O1xuXG4gIC5tYXQtaWNvbjpob3ZlciB7XG4gICAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC43Mik7XG4gIH1cblxuICAuZGVsZXRlLWljb24ge1xuICAgIG1hcmdpbi1yaWdodDogMjRweDtcbiAgICBwYWRkaW5nLWxlZnQ6IDE2cHg7XG4gIH1cbn1cblxuLm1hdC1leHBhbnNpb24tcGFuZWwtaGVhZGVyLWRlc2NyaXB0aW9uIHtcbiAgbWFyZ2luLXJpZ2h0OiAwO1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuXG4ubWF0LWV4cGFuc2lvbi1wYW5lbC1oZWFkZXItdGl0bGUge1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuXG4udm9sdW1lLWJ1dHRvbnMge1xuICBkaXNwbGF5OiBmbGV4O1xuICBtYXJnaW4tdG9wOiAxcmVtO1xuICBtYXJnaW4tYm90dG9tOiAxLjVyZW07XG5cbiAgLm1hdC1zdHJva2VkLWJ1dHRvbjpmaXJzdC1jaGlsZCB7XG4gICAgbWFyZ2luLXJpZ2h0OiAxcmVtO1xuICB9XG5cbiAgLm1hdC1zdHJva2VkLWJ1dHRvbiB7XG4gICAgd2lkdGg6IDEwMCU7XG4gIH1cbn1cbiJdfQ== */"] });


/***/ }),

/***/ 3261:
/*!**************************************************!*\
  !*** ./src/app/pages/form/form-default/utils.ts ***!
  \**************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getFormDefaults": function() { return /* binding */ getFormDefaults; },
/* harmony export */   "updateGPUControl": function() { return /* binding */ updateGPUControl; },
/* harmony export */   "calculateLimits": function() { return /* binding */ calculateLimits; },
/* harmony export */   "initCpuFormControls": function() { return /* binding */ initCpuFormControls; },
/* harmony export */   "initMemoryFormControls": function() { return /* binding */ initMemoryFormControls; },
/* harmony export */   "initFormControls": function() { return /* binding */ initFormControls; },
/* harmony export */   "initWorkspaceVolumeControl": function() { return /* binding */ initWorkspaceVolumeControl; },
/* harmony export */   "initDataVolumeControl": function() { return /* binding */ initDataVolumeControl; },
/* harmony export */   "configSizeToNumber": function() { return /* binding */ configSizeToNumber; }
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var src_app_shared_utils_volumes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/shared/utils/volumes */ 562);


function getFormDefaults() {
    const fb = new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormBuilder();
    return fb.group({
        name: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_1__.Validators.required]],
        namespace: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_1__.Validators.required]],
        image: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_1__.Validators.required]],
        imageGroupOne: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_1__.Validators.required]],
        imageGroupTwo: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_1__.Validators.required]],
        allowCustomImage: [true, []],
        imagePullPolicy: ['IfNotPresent', [_angular_forms__WEBPACK_IMPORTED_MODULE_1__.Validators.required]],
        customImage: ['', []],
        customImageCheck: [false, []],
        serverType: ['jupyter', [_angular_forms__WEBPACK_IMPORTED_MODULE_1__.Validators.required]],
        cpu: [1, [_angular_forms__WEBPACK_IMPORTED_MODULE_1__.Validators.required]],
        cpuLimit: ['', []],
        memory: [1, [_angular_forms__WEBPACK_IMPORTED_MODULE_1__.Validators.required]],
        memoryLimit: ['', []],
        gpus: fb.group({
            vendor: ['', []],
            num: ['', []],
        }),
        workspace: fb.group({
            mount: ['/home/jovyan', [_angular_forms__WEBPACK_IMPORTED_MODULE_1__.Validators.required]],
            newPvc: fb.group({
                metadata: fb.group({
                    name: ['{notebook-name}-volume', [_angular_forms__WEBPACK_IMPORTED_MODULE_1__.Validators.required]],
                }),
                spec: fb.group({
                    accessModes: [['ReadWriteOnce']],
                    resources: fb.group({
                        requests: fb.group({
                            storage: ['10Gi'],
                        }),
                    }),
                }),
            }),
        }),
        affinityConfig: ['', []],
        tolerationGroup: ['', []],
        datavols: fb.array([]),
        shm: [true, []],
        configurations: [[], []],
    });
}
function updateGPUControl(formCtrl, gpuConf) {
    // If the backend didn't send the value, default to none
    if (gpuConf == null) {
        formCtrl.get('num').setValue('none');
        return;
    }
    // Set the values
    const gpu = gpuConf.value;
    formCtrl.get('num').setValue(gpu.num);
    formCtrl.get('vendor').setValue(gpu.vendor);
    // Don't allow the user to edit them if the admin does not allow it
    if (gpuConf.readOnly) {
        formCtrl.get('num').disable();
        formCtrl.get('vendor').disable();
    }
}
function calculateLimits(requests, factor) {
    const limit = configSizeToNumber(requests) * configSizeToNumber(factor);
    if (isNaN(limit)) {
        return null;
    }
    return limit.toFixed(1);
}
function initCpuFormControls(formCtrl, config) {
    const cpu = Number(config.cpu.value);
    if (!isNaN(cpu)) {
        formCtrl.controls.cpu.setValue(cpu);
    }
    if (config.cpu.readOnly) {
        formCtrl.controls.cpu.disable();
        formCtrl.controls.cpuLimit.disable();
    }
    formCtrl.controls.cpuLimit.setValue(calculateLimits(cpu, config.cpu.limitFactor));
}
function initMemoryFormControls(formCtrl, config) {
    const memory = configSizeToNumber(config.memory.value);
    if (!isNaN(memory)) {
        formCtrl.controls.memory.setValue(memory);
    }
    if (config.memory.readOnly) {
        formCtrl.controls.memory.disable();
        formCtrl.controls.memoryLimit.disable();
    }
    formCtrl.controls.memoryLimit.setValue(calculateLimits(memory, config.memory.limitFactor));
}
function initFormControls(formCtrl, config) {
    var _a, _b;
    initCpuFormControls(formCtrl, config);
    initMemoryFormControls(formCtrl, config);
    formCtrl.controls.image.setValue(config.image.value);
    if ((_a = config.imageGroupOne) === null || _a === void 0 ? void 0 : _a.value) {
        formCtrl.controls.imageGroupOne.setValue(config.imageGroupOne.value);
    }
    else {
        formCtrl.controls.imageGroupOne.disable();
    }
    if ((_b = config.imageGroupTwo) === null || _b === void 0 ? void 0 : _b.value) {
        formCtrl.controls.imageGroupTwo.setValue(config.imageGroupTwo.value);
    }
    else {
        formCtrl.controls.imageGroupTwo.disable();
    }
    formCtrl.controls.imagePullPolicy.setValue(config.imagePullPolicy.value);
    if (config.imagePullPolicy.readOnly) {
        formCtrl.controls.imagePullPolicy.disable();
    }
    // Workspace volume
    initWorkspaceVolumeControl(formCtrl, config);
    // Data volumes
    initDataVolumeControl(formCtrl, config);
    // Affinity
    formCtrl.controls.affinityConfig.setValue(config.affinityConfig.value);
    if (config.affinityConfig.readOnly) {
        formCtrl.controls.affinityConfig.disable();
    }
    // Tolerations
    formCtrl.controls.tolerationGroup.setValue(config.tolerationGroup.value);
    if (config.tolerationGroup.readOnly) {
        formCtrl.controls.tolerationGroup.disable();
    }
    // GPUs
    updateGPUControl(formCtrl.get('gpus'), config.gpus);
    formCtrl.controls.shm.setValue(config.shm.value);
    if (config.shm.readOnly) {
        formCtrl.controls.shm.disable();
    }
    // PodDefaults / Configurations. Set the pre selected labels
    formCtrl.controls.configurations.setValue(config.configurations.value);
    if (config.configurations.readOnly) {
        formCtrl.controls.configurations.disable();
    }
}
function initWorkspaceVolumeControl(form, config) {
    const workspace = config.workspaceVolume.value;
    if (!workspace) {
        form.get('workspace').disable();
        return;
    }
    form.setControl('workspace', (0,src_app_shared_utils_volumes__WEBPACK_IMPORTED_MODULE_0__.createFormGroupFromVolume)(workspace));
}
function initDataVolumeControl(form, config) {
    const datavols = config.dataVolumes.value;
    const datavolsArray = new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormArray([]);
    form.setControl('datavols', datavolsArray);
    for (const vol of datavols) {
        datavolsArray.push((0,src_app_shared_utils_volumes__WEBPACK_IMPORTED_MODULE_0__.createFormGroupFromVolume)(vol));
    }
}
function configSizeToNumber(size) {
    if (size == null) {
        return NaN;
    }
    if (typeof size === 'number') {
        return size;
    }
    return Number(size.replace('Gi', ''));
}


/***/ }),

/***/ 9335:
/*!**************************************************************************************!*\
  !*** ./src/app/pages/form/form-default/volume/existing/existing-volume.component.ts ***!
  \**************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ExistingVolumeComponent": function() { return /* binding */ ExistingVolumeComponent; }
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var src_app_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/types */ 4984);
/* harmony import */ var src_app_shared_utils_volumes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/shared/utils/volumes */ 562);
/* harmony import */ var js_yaml__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! js-yaml */ 9979);
/* harmony import */ var src_app_shared_utils_yaml__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/utils/yaml */ 6473);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/form-field */ 8295);
/* harmony import */ var _angular_material_select__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/select */ 7441);
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/core */ 7817);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _pvc_pvc_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pvc/pvc.component */ 218);
/* harmony import */ var ng2_ace_editor__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ng2-ace-editor */ 9617);












function ExistingVolumeComponent_ng_container_8_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](1, "app-existing-pvc", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("pvcGroup", ctx_r0.getPvcFormGroup());
} }
function ExistingVolumeComponent_ng_template_9_mat_error_7_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "mat-error");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](ctx_r3.errorParsingYaml);
} }
function ExistingVolumeComponent_ng_template_9_Template(rf, ctx) { if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵi18n"](1, 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "a", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵi18n"](3, 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerStart"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵi18n"](5, 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](6, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("textChange", function ExistingVolumeComponent_ng_template_9_Template_div_textChange_6_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r5); const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](); return ctx_r4.yaml = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](7, ExistingVolumeComponent_ng_template_9_mat_error_7_Template, 2, 1, "mat-error", 15);
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("text", ctx_r2.yaml);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r2.errorParsingYaml);
} }
class ExistingVolumeComponent {
    constructor() {
        this.EXISTING_VOLUME_TYPE = src_app_types__WEBPACK_IMPORTED_MODULE_0__.EXISTING_VOLUME_TYPE;
        this.errorParsingYaml = '';
        this.yamlInternal = '';
    }
    get yaml() {
        return this.yamlInternal;
    }
    set yaml(text) {
        // Try to parse the YAML contents into a JS dict and store it in the
        // FormControl for the existingSource
        this.yamlInternal = text;
        const [parsed, error] = (0,src_app_shared_utils_yaml__WEBPACK_IMPORTED_MODULE_3__.parseYAML)(text);
        this.errorParsingYaml = error;
        if (error) {
            return;
        }
        this.volGroup.get('existingSource').setValue(parsed);
    }
    get type() {
        if (!this.volGroup) {
            return src_app_types__WEBPACK_IMPORTED_MODULE_0__.EXISTING_VOLUME_TYPE.CUSTOM;
        }
        if (this.volGroup.get('existingSource') instanceof _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormControl) {
            return src_app_types__WEBPACK_IMPORTED_MODULE_0__.EXISTING_VOLUME_TYPE.CUSTOM;
        }
        if (this.volGroup.get('existingSource') instanceof _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormGroup) {
            return src_app_types__WEBPACK_IMPORTED_MODULE_0__.EXISTING_VOLUME_TYPE.PVC;
        }
    }
    ngOnInit() {
        const existingSource = this.volGroup.get('existingSource').value;
        this.yaml = (0,js_yaml__WEBPACK_IMPORTED_MODULE_2__.dump)(existingSource);
    }
    typeChanged(type) {
        // In case of custom we change from a form group to a simple form control
        // The user will be inputing a YAML, which we will be converting to JS dict
        if (type === src_app_types__WEBPACK_IMPORTED_MODULE_0__.EXISTING_VOLUME_TYPE.CUSTOM) {
            const currSrc = this.volGroup.get('existingSource').value;
            this.yamlInternal = (0,js_yaml__WEBPACK_IMPORTED_MODULE_2__.dump)(currSrc);
            this.volGroup.setControl('existingSource', new _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormControl(currSrc));
            return;
        }
        // Use a FormGroup for PVC, since there will be a form with subfields
        this.volGroup.setControl('existingSource', (0,src_app_shared_utils_volumes__WEBPACK_IMPORTED_MODULE_1__.createExistingSourceFormGroup)());
        const sourceGroup = this.volGroup.get('existingSource');
        const source = src_app_types__WEBPACK_IMPORTED_MODULE_0__.EXISTING_SOURCE.PERSISTENT_VOLUME_CLAIM;
        sourceGroup.addControl(source, (0,src_app_shared_utils_volumes__WEBPACK_IMPORTED_MODULE_1__.createSourceFormGroup)(source));
    }
    getPvcFormGroup() {
        return this.volGroup.get('existingSource.persistentVolumeClaim');
    }
}
ExistingVolumeComponent.ɵfac = function ExistingVolumeComponent_Factory(t) { return new (t || ExistingVolumeComponent)(); };
ExistingVolumeComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({ type: ExistingVolumeComponent, selectors: [["app-existing-volume"]], inputs: { volGroup: "volGroup" }, decls: 11, vars: 5, consts: function () { let i18n_0; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_8650499415827640724$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_EXISTING_EXISTING_VOLUME_COMPONENT_TS_1 = goog.getMsg("Type");
        i18n_0 = MSG_EXTERNAL_8650499415827640724$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_EXISTING_EXISTING_VOLUME_COMPONENT_TS_1;
    }
    else {
        i18n_0 = $localize `:␟f61c6867295f3b53d23557021f2f4e0aa1d0b8fc␟8650499415827640724:Type`;
    } let i18n_2; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_810947860660187060$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_EXISTING_EXISTING_VOLUME_COMPONENT_TS_3 = goog.getMsg(" Kubernetes Volume ");
        i18n_2 = MSG_EXTERNAL_810947860660187060$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_EXISTING_EXISTING_VOLUME_COMPONENT_TS_3;
    }
    else {
        i18n_2 = $localize `:␟aa4cb8436999a266d2ce198460a31f2b34b656a2␟810947860660187060: Kubernetes Volume `;
    } let i18n_4; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_5594363535349500896$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_EXISTING_EXISTING_VOLUME_COMPONENT_TS_5 = goog.getMsg("Insert your custom K8s volume spec.");
        i18n_4 = MSG_EXTERNAL_5594363535349500896$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_EXISTING_EXISTING_VOLUME_COMPONENT_TS_5;
    }
    else {
        i18n_4 = $localize `:␟90af90accd31a3d187f21a25ee57aa01681394bb␟5594363535349500896:Insert your custom K8s volume spec.`;
    } let i18n_6; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_720964526638374966$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_EXISTING_EXISTING_VOLUME_COMPONENT_TS_7 = goog.getMsg(" Custom (Advanced) ");
        i18n_6 = MSG_EXTERNAL_720964526638374966$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_EXISTING_EXISTING_VOLUME_COMPONENT_TS_7;
    }
    else {
        i18n_6 = $localize `:␟f76feb32fc89ce5736a62ee29ed3de9de1439e03␟720964526638374966: Custom (Advanced) `;
    } let i18n_8; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_4027459734657890990$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_EXISTING_EXISTING_VOLUME_COMPONENT_TS__9 = goog.getMsg("Check the ");
        i18n_8 = MSG_EXTERNAL_4027459734657890990$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_EXISTING_EXISTING_VOLUME_COMPONENT_TS__9;
    }
    else {
        i18n_8 = $localize `:␟b335fa806932b539c41cb777d52f71dc057f7608␟4027459734657890990:Check the `;
    } let i18n_10; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_8770534612779897078$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_EXISTING_EXISTING_VOLUME_COMPONENT_TS__11 = goog.getMsg("K8s docs");
        i18n_10 = MSG_EXTERNAL_8770534612779897078$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_EXISTING_EXISTING_VOLUME_COMPONENT_TS__11;
    }
    else {
        i18n_10 = $localize `:␟626cb4d573fdc3d2f2a110136194ce5b4735dac3␟8770534612779897078:K8s docs`;
    } let i18n_12; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_5329282524534762878$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_EXISTING_EXISTING_VOLUME_COMPONENT_TS__13 = goog.getMsg(" for the supported volumes and their specs");
        i18n_12 = MSG_EXTERNAL_5329282524534762878$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_EXISTING_EXISTING_VOLUME_COMPONENT_TS__13;
    }
    else {
        i18n_12 = $localize `:␟0f63b191d2f34ec123ce019e85d056f52d4ee971␟5329282524534762878: for the supported volumes and their specs`;
    } return [["appearance", "outline", 1, "wide"], i18n_0, [3, "value", "selectionChange"], [3, "value"], i18n_2, ["matTooltip", i18n_4, 3, "value"], i18n_6, [4, "ngIf", "ngIfElse"], ["customSrc", ""], [3, "pvcGroup"], i18n_8, ["href", "https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.19/#volume-v1-core", "target", "_blank"], i18n_10, i18n_12, ["ace-editor", "", "mode", "yaml", "theme", "xcode", 3, "text", "textChange"], [4, "ngIf"]]; }, template: function ExistingVolumeComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "mat-form-field", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](1, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵi18n"](2, 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](3, "mat-select", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("selectionChange", function ExistingVolumeComponent_Template_mat_select_selectionChange_3_listener($event) { return ctx.typeChanged($event.value); });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](4, "mat-option", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵi18n"](5, 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](6, "mat-option", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵi18n"](7, 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](8, ExistingVolumeComponent_ng_container_8_Template, 2, 1, "ng-container", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](9, ExistingVolumeComponent_ng_template_9_Template, 8, 2, "ng-template", null, 8, _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplateRefExtractor"]);
    } if (rf & 2) {
        const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵreference"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("value", ctx.type);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("value", ctx.EXISTING_VOLUME_TYPE.PVC);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("value", ctx.EXISTING_VOLUME_TYPE.CUSTOM);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.type === ctx.EXISTING_VOLUME_TYPE.PVC)("ngIfElse", _r1);
    } }, directives: [_angular_material_form_field__WEBPACK_IMPORTED_MODULE_8__.MatFormField, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_8__.MatLabel, _angular_material_select__WEBPACK_IMPORTED_MODULE_9__.MatSelect, _angular_material_core__WEBPACK_IMPORTED_MODULE_10__.MatOption, _angular_common__WEBPACK_IMPORTED_MODULE_11__.NgIf, _pvc_pvc_component__WEBPACK_IMPORTED_MODULE_4__.ExistingPvcComponent, ng2_ace_editor__WEBPACK_IMPORTED_MODULE_5__.AceEditorDirective, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_8__.MatError], styles: ["[_nghost-%COMP%] {\n  display: block;\n}\n\n[ace-editor][_ngcontent-%COMP%] {\n  width: auto;\n  height: 250px;\n  margin-top: 0.5rem;\n  margin-bottom: 1rem;\n}\n\n.mat-error[_ngcontent-%COMP%] {\n  margin-bottom: 1rem;\n  white-space: pre-wrap;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImV4aXN0aW5nLXZvbHVtZS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGNBQUE7QUFDRjs7QUFFQTtFQUNFLFdBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtBQUNGOztBQUVBO0VBQ0UsbUJBQUE7RUFDQSxxQkFBQTtBQUNGIiwiZmlsZSI6ImV4aXN0aW5nLXZvbHVtZS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IHtcbiAgZGlzcGxheTogYmxvY2s7XG59XG5cblthY2UtZWRpdG9yXSB7XG4gIHdpZHRoOiBhdXRvO1xuICBoZWlnaHQ6IDI1MHB4O1xuICBtYXJnaW4tdG9wOiAwLjVyZW07XG4gIG1hcmdpbi1ib3R0b206IDFyZW07XG59XG5cbi5tYXQtZXJyb3Ige1xuICBtYXJnaW4tYm90dG9tOiAxcmVtO1xuICB3aGl0ZS1zcGFjZTogcHJlLXdyYXA7XG59XG4iXX0= */"] });


/***/ }),

/***/ 1142:
/*!***********************************************************************************!*\
  !*** ./src/app/pages/form/form-default/volume/existing/existing-volume.module.ts ***!
  \***********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ExistingVolumeModule": function() { return /* binding */ ExistingVolumeModule; }
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _existing_volume_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./existing-volume.component */ 9335);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/form-field */ 8295);
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/input */ 3166);
/* harmony import */ var _angular_material_select__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/select */ 7441);
/* harmony import */ var _pvc_pvc_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pvc/pvc.module */ 1432);
/* harmony import */ var ng2_ace_editor__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ng2-ace-editor */ 9617);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);









class ExistingVolumeModule {
}
ExistingVolumeModule.ɵfac = function ExistingVolumeModule_Factory(t) { return new (t || ExistingVolumeModule)(); };
ExistingVolumeModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({ type: ExistingVolumeModule });
ExistingVolumeModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_material_form_field__WEBPACK_IMPORTED_MODULE_5__.MatFormFieldModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.ReactiveFormsModule,
            _angular_material_input__WEBPACK_IMPORTED_MODULE_7__.MatInputModule,
            _angular_material_select__WEBPACK_IMPORTED_MODULE_8__.MatSelectModule,
            _pvc_pvc_module__WEBPACK_IMPORTED_MODULE_1__.ExistingPvcModule,
            ng2_ace_editor__WEBPACK_IMPORTED_MODULE_2__.AceEditorModule,
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](ExistingVolumeModule, { declarations: [_existing_volume_component__WEBPACK_IMPORTED_MODULE_0__.ExistingVolumeComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
        _angular_material_form_field__WEBPACK_IMPORTED_MODULE_5__.MatFormFieldModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_6__.ReactiveFormsModule,
        _angular_material_input__WEBPACK_IMPORTED_MODULE_7__.MatInputModule,
        _angular_material_select__WEBPACK_IMPORTED_MODULE_8__.MatSelectModule,
        _pvc_pvc_module__WEBPACK_IMPORTED_MODULE_1__.ExistingPvcModule,
        ng2_ace_editor__WEBPACK_IMPORTED_MODULE_2__.AceEditorModule], exports: [_existing_volume_component__WEBPACK_IMPORTED_MODULE_0__.ExistingVolumeComponent] }); })();


/***/ }),

/***/ 218:
/*!******************************************************************************!*\
  !*** ./src/app/pages/form/form-default/volume/existing/pvc/pvc.component.ts ***!
  \******************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ExistingPvcComponent": function() { return /* binding */ ExistingPvcComponent; }
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var src_app_services_backend_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/services/backend.service */ 600);
/* harmony import */ var kubeflow__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! kubeflow */ 872);
/* harmony import */ var _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/checkbox */ 7539);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/form-field */ 8295);
/* harmony import */ var _angular_material_select__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/select */ 7441);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/core */ 7817);









function ExistingPvcComponent_mat_option_7_ng_container_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const pvc_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](pvc_r2.size);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](pvc_r2.mode);
} }
function ExistingPvcComponent_mat_option_7_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-option", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](4, ExistingPvcComponent_mat_option_7_ng_container_4_Template, 5, 2, "ng-container", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const pvc_r2 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵreference"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("value", pvc_r2.name);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](pvc_r2.name);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", _r0.panelOpen);
} }
class ExistingPvcComponent {
    constructor(backend, ns) {
        this.backend = backend;
        this.ns = ns;
        this.pvcs = [];
    }
    ngOnInit() {
        this.ns.getSelectedNamespace().subscribe(ns => {
            this.backend.getVolumes(ns).subscribe(pvcs => {
                this.pvcs = pvcs;
            });
        });
    }
}
ExistingPvcComponent.ɵfac = function ExistingPvcComponent_Factory(t) { return new (t || ExistingPvcComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_services_backend_service__WEBPACK_IMPORTED_MODULE_0__.JWABackendService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](kubeflow__WEBPACK_IMPORTED_MODULE_2__.NamespaceService)); };
ExistingPvcComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: ExistingPvcComponent, selectors: [["app-existing-pvc"]], inputs: { pvcGroup: "pvcGroup" }, decls: 8, vars: 3, consts: function () { let i18n_0; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_8953033926734869941$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_EXISTING_PVC_PVC_COMPONENT_TS_1 = goog.getMsg("Name");
        i18n_0 = MSG_EXTERNAL_8953033926734869941$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_EXISTING_PVC_PVC_COMPONENT_TS_1;
    }
    else {
        i18n_0 = $localize `:␟cff1428d10d59d14e45edec3c735a27b5482db59␟8953033926734869941:Name`;
    } return [[3, "formControl"], ["appearance", "outline", 1, "wide"], i18n_0, ["select", ""], [3, "value", 4, "ngFor", "ngForOf"], [3, "value"], [1, "flex"], [1, "name", "truncate"], [4, "ngIf"], [1, "size"], [1, "mode"]]; }, template: function ExistingPvcComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-checkbox", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1, "Readonly");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "mat-form-field", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵi18n"](4, 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "mat-select", 0, 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](7, ExistingPvcComponent_mat_option_7_Template, 5, 3, "mat-option", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formControl", ctx.pvcGroup.get("readOnly"));
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formControl", ctx.pvcGroup.get("claimName"));
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx.pvcs);
    } }, directives: [_angular_material_checkbox__WEBPACK_IMPORTED_MODULE_3__.MatCheckbox, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControlDirective, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_5__.MatFormField, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_5__.MatLabel, _angular_material_select__WEBPACK_IMPORTED_MODULE_6__.MatSelect, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgForOf, _angular_material_core__WEBPACK_IMPORTED_MODULE_8__.MatOption, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgIf], styles: ["[_nghost-%COMP%] {\n  display: block;\n}\n\n.name[_ngcontent-%COMP%] {\n  width: 60%;\n  margin-right: 1rem;\n}\n\n.size[_ngcontent-%COMP%] {\n  width: 15%;\n}\n\n.mode[_ngcontent-%COMP%] {\n  width: 25%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInB2Yy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGNBQUE7QUFDRjs7QUFFQTtFQUNFLFVBQUE7RUFDQSxrQkFBQTtBQUNGOztBQUVBO0VBQ0UsVUFBQTtBQUNGOztBQUVBO0VBQ0UsVUFBQTtBQUNGIiwiZmlsZSI6InB2Yy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IHtcbiAgZGlzcGxheTogYmxvY2s7XG59XG5cbi5uYW1lIHtcbiAgd2lkdGg6IDYwJTtcbiAgbWFyZ2luLXJpZ2h0OiAxcmVtO1xufVxuXG4uc2l6ZSB7XG4gIHdpZHRoOiAxNSU7XG59XG5cbi5tb2RlIHtcbiAgd2lkdGg6IDI1JTtcbn1cbiJdfQ== */"] });


/***/ }),

/***/ 1432:
/*!***************************************************************************!*\
  !*** ./src/app/pages/form/form-default/volume/existing/pvc/pvc.module.ts ***!
  \***************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ExistingPvcModule": function() { return /* binding */ ExistingPvcModule; }
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _pvc_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pvc.component */ 218);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/form-field */ 8295);
/* harmony import */ var _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/checkbox */ 7539);
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/input */ 3166);
/* harmony import */ var _angular_material_select__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/select */ 7441);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7716);








class ExistingPvcModule {
}
ExistingPvcModule.ɵfac = function ExistingPvcModule_Factory(t) { return new (t || ExistingPvcModule)(); };
ExistingPvcModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({ type: ExistingPvcModule });
ExistingPvcModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__.ReactiveFormsModule,
            _angular_material_form_field__WEBPACK_IMPORTED_MODULE_4__.MatFormFieldModule,
            _angular_material_input__WEBPACK_IMPORTED_MODULE_5__.MatInputModule,
            _angular_material_select__WEBPACK_IMPORTED_MODULE_6__.MatSelectModule,
            _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_7__.MatCheckboxModule,
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](ExistingPvcModule, { declarations: [_pvc_component__WEBPACK_IMPORTED_MODULE_0__.ExistingPvcComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_3__.ReactiveFormsModule,
        _angular_material_form_field__WEBPACK_IMPORTED_MODULE_4__.MatFormFieldModule,
        _angular_material_input__WEBPACK_IMPORTED_MODULE_5__.MatInputModule,
        _angular_material_select__WEBPACK_IMPORTED_MODULE_6__.MatSelectModule,
        _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_7__.MatCheckboxModule], exports: [_pvc_component__WEBPACK_IMPORTED_MODULE_0__.ExistingPvcComponent] }); })();


/***/ }),

/***/ 8758:
/*!*************************************************************************!*\
  !*** ./src/app/pages/form/form-default/volume/mount/mount.component.ts ***!
  \*************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VolumeMountComponent": function() { return /* binding */ VolumeMountComponent; }
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/material/form-field */ 8295);
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material/input */ 3166);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 3679);




class VolumeMountComponent {
    constructor() { }
    ngOnInit() { }
}
VolumeMountComponent.ɵfac = function VolumeMountComponent_Factory(t) { return new (t || VolumeMountComponent)(); };
VolumeMountComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: VolumeMountComponent, selectors: [["app-volume-mount"]], inputs: { volGroup: "volGroup" }, decls: 4, vars: 1, consts: function () { let i18n_0; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_8621172051657531969$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_MOUNT_MOUNT_COMPONENT_TS_1 = goog.getMsg("Mount path");
        i18n_0 = MSG_EXTERNAL_8621172051657531969$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_MOUNT_MOUNT_COMPONENT_TS_1;
    }
    else {
        i18n_0 = $localize `:␟4c01df36153e04929724e0c55bad22f8a3a83510␟8621172051657531969:Mount path`;
    } return [["appearance", "outline", 1, "wide"], i18n_0, ["autocomplete", "off", "matInput", "", 3, "formControl"]]; }, template: function VolumeMountComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-form-field", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵi18n"](2, 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "input", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("formControl", ctx.volGroup.get("mount"));
    } }, directives: [_angular_material_form_field__WEBPACK_IMPORTED_MODULE_1__.MatFormField, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_1__.MatLabel, _angular_material_input__WEBPACK_IMPORTED_MODULE_2__.MatInput, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControlDirective], styles: [".form-title[_ngcontent-%COMP%] {\n  font-weight: 500;\n  margin-bottom: 0.6rem;\n  color: rgba(0, 0, 0, 0.64);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1vdW50LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZ0JBQUE7RUFDQSxxQkFBQTtFQUNBLDBCQUFBO0FBQ0YiLCJmaWxlIjoibW91bnQuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZm9ybS10aXRsZSB7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIG1hcmdpbi1ib3R0b206IDAuNnJlbTtcbiAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC42NCk7XG59XG4iXX0= */"] });


/***/ }),

/***/ 9801:
/*!**********************************************************************!*\
  !*** ./src/app/pages/form/form-default/volume/mount/mount.module.ts ***!
  \**********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VolumeMountModule": function() { return /* binding */ VolumeMountModule; }
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _mount_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mount.component */ 8758);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/form-field */ 8295);
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/input */ 3166);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7716);






class VolumeMountModule {
}
VolumeMountModule.ɵfac = function VolumeMountModule_Factory(t) { return new (t || VolumeMountModule)(); };
VolumeMountModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({ type: VolumeMountModule });
VolumeMountModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__.ReactiveFormsModule,
            _angular_material_form_field__WEBPACK_IMPORTED_MODULE_4__.MatFormFieldModule,
            _angular_material_input__WEBPACK_IMPORTED_MODULE_5__.MatInputModule,
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](VolumeMountModule, { declarations: [_mount_component__WEBPACK_IMPORTED_MODULE_0__.VolumeMountComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_3__.ReactiveFormsModule,
        _angular_material_form_field__WEBPACK_IMPORTED_MODULE_4__.MatFormFieldModule,
        _angular_material_input__WEBPACK_IMPORTED_MODULE_5__.MatInputModule], exports: [_mount_component__WEBPACK_IMPORTED_MODULE_0__.VolumeMountComponent] }); })();


/***/ }),

/***/ 5739:
/*!*******************************************************************************************!*\
  !*** ./src/app/pages/form/form-default/volume/new/access-modes/access-modes.component.ts ***!
  \*******************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VolumeAccessModesComponent": function() { return /* binding */ VolumeAccessModesComponent; }
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_material_radio__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material/radio */ 2613);




class VolumeAccessModesComponent {
    constructor() {
        this.mode = new _angular_forms__WEBPACK_IMPORTED_MODULE_0__.FormControl('', _angular_forms__WEBPACK_IMPORTED_MODULE_0__.Validators.required);
    }
    ngOnInit() {
        // Update the initial value of temp control.
        // We expect the input Group to always have one value
        const modes = this.modesCtrl.value;
        this.mode.setValue(modes[0]);
        this.mode.valueChanges.subscribe(mode => {
            this.modesCtrl.setValue([mode]);
        });
    }
}
VolumeAccessModesComponent.ɵfac = function VolumeAccessModesComponent_Factory(t) { return new (t || VolumeAccessModesComponent)(); };
VolumeAccessModesComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: VolumeAccessModesComponent, selectors: [["app-volume-access-modes"]], inputs: { modesCtrl: "modesCtrl" }, decls: 9, vars: 1, consts: function () { let i18n_0; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_4025389224276032486$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_ACCESS_MODES_ACCESS_MODES_COMPONENT_TS_1 = goog.getMsg(" Access mode ");
        i18n_0 = MSG_EXTERNAL_4025389224276032486$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_ACCESS_MODES_ACCESS_MODES_COMPONENT_TS_1;
    }
    else {
        i18n_0 = $localize `:␟dfc76e0a631038177c1bee4388585cbd8cda5ee0␟4025389224276032486: Access mode `;
    } let i18n_2; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_2348450887687942129$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_ACCESS_MODES_ACCESS_MODES_COMPONENT_TS_3 = goog.getMsg(" ReadWriteOnce ");
        i18n_2 = MSG_EXTERNAL_2348450887687942129$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_ACCESS_MODES_ACCESS_MODES_COMPONENT_TS_3;
    }
    else {
        i18n_2 = $localize `:␟21933e80b99b15c68c8c6865c779c71abaf8bf27␟2348450887687942129: ReadWriteOnce `;
    } let i18n_4; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_2287102196239033322$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_ACCESS_MODES_ACCESS_MODES_COMPONENT_TS_5 = goog.getMsg("ReadOnlyMany");
        i18n_4 = MSG_EXTERNAL_2287102196239033322$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_ACCESS_MODES_ACCESS_MODES_COMPONENT_TS_5;
    }
    else {
        i18n_4 = $localize `:␟63d01b21c7a9fcc7903bd3b7ded47685ad741aa8␟2287102196239033322:ReadOnlyMany`;
    } let i18n_6; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_8202395223890644346$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_ACCESS_MODES_ACCESS_MODES_COMPONENT_TS_7 = goog.getMsg(" ReadWriteMany ");
        i18n_6 = MSG_EXTERNAL_8202395223890644346$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_ACCESS_MODES_ACCESS_MODES_COMPONENT_TS_7;
    }
    else {
        i18n_6 = $localize `:␟bdf7f1a8504aac15affc41c3a29122d89128e45b␟8202395223890644346: ReadWriteMany `;
    } return [["id", "access-mode-label", 1, "form-title"], i18n_0, ["aria-labelledby", "access-mode-label", 3, "formControl"], ["value", "ReadWriteOnce"], i18n_2, ["value", "ReadOnlyMany"], i18n_4, ["value", "ReadWriteMany"], i18n_6]; }, template: function VolumeAccessModesComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "label", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵi18n"](1, 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "mat-radio-group", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "mat-radio-button", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵi18n"](4, 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "mat-radio-button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵi18n"](6, 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "mat-radio-button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵi18n"](8, 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formControl", ctx.mode);
    } }, directives: [_angular_material_radio__WEBPACK_IMPORTED_MODULE_2__.MatRadioGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_0__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_0__.FormControlDirective, _angular_material_radio__WEBPACK_IMPORTED_MODULE_2__.MatRadioButton], styles: ["[_nghost-%COMP%] {\n  display: inline-block;\n}\n\n.form-title[_ngcontent-%COMP%] {\n  font-weight: 500;\n  margin-bottom: 0.4rem;\n  color: rgba(0, 0, 0, 0.64);\n  display: block;\n}\n\n.mat-radio-group[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n}\n\n.mat-radio-group[_ngcontent-%COMP%]   .mat-radio-button[_ngcontent-%COMP%] {\n  margin-bottom: 0.5rem;\n}\n\n.mat-radio-group[_ngcontent-%COMP%]   .mat-radio-button[_ngcontent-%COMP%]:last-child {\n  margin-bottom: 1rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFjY2Vzcy1tb2Rlcy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHFCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxnQkFBQTtFQUNBLHFCQUFBO0VBQ0EsMEJBQUE7RUFDQSxjQUFBO0FBQ0Y7O0FBRUE7RUFDRSxhQUFBO0VBQ0Esc0JBQUE7QUFDRjs7QUFDRTtFQUNFLHFCQUFBO0FBQ0o7O0FBRUU7RUFDRSxtQkFBQTtBQUFKIiwiZmlsZSI6ImFjY2Vzcy1tb2Rlcy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IHtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xufVxuXG4uZm9ybS10aXRsZSB7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIG1hcmdpbi1ib3R0b206IDAuNHJlbTtcbiAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC42NCk7XG4gIGRpc3BsYXk6IGJsb2NrO1xufVxuXG4ubWF0LXJhZGlvLWdyb3VwIHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcblxuICAubWF0LXJhZGlvLWJ1dHRvbiB7XG4gICAgbWFyZ2luLWJvdHRvbTogMC41cmVtO1xuICB9XG5cbiAgLm1hdC1yYWRpby1idXR0b246bGFzdC1jaGlsZCB7XG4gICAgbWFyZ2luLWJvdHRvbTogMXJlbTtcbiAgfVxufVxuIl19 */"] });


/***/ }),

/***/ 8783:
/*!****************************************************************************************!*\
  !*** ./src/app/pages/form/form-default/volume/new/access-modes/access-modes.module.ts ***!
  \****************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VolumeAccessModesModule": function() { return /* binding */ VolumeAccessModesModule; }
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _access_modes_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./access-modes.component */ 5739);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/form-field */ 8295);
/* harmony import */ var _angular_material_radio__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/radio */ 2613);
/* harmony import */ var _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/tooltip */ 1436);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7716);







class VolumeAccessModesModule {
}
VolumeAccessModesModule.ɵfac = function VolumeAccessModesModule_Factory(t) { return new (t || VolumeAccessModesModule)(); };
VolumeAccessModesModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({ type: VolumeAccessModesModule });
VolumeAccessModesModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__.ReactiveFormsModule,
            _angular_material_form_field__WEBPACK_IMPORTED_MODULE_4__.MatFormFieldModule,
            _angular_material_radio__WEBPACK_IMPORTED_MODULE_5__.MatRadioModule,
            _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_6__.MatTooltipModule,
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](VolumeAccessModesModule, { declarations: [_access_modes_component__WEBPACK_IMPORTED_MODULE_0__.VolumeAccessModesComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_3__.ReactiveFormsModule,
        _angular_material_form_field__WEBPACK_IMPORTED_MODULE_4__.MatFormFieldModule,
        _angular_material_radio__WEBPACK_IMPORTED_MODULE_5__.MatRadioModule,
        _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_6__.MatTooltipModule], exports: [_access_modes_component__WEBPACK_IMPORTED_MODULE_0__.VolumeAccessModesComponent] }); })();


/***/ }),

/***/ 1910:
/*!***************************************************************************!*\
  !*** ./src/app/pages/form/form-default/volume/new/name/name.component.ts ***!
  \***************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VolumeNameComponent": function() { return /* binding */ VolumeNameComponent; }
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 826);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/form-field */ 8295);
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/input */ 3166);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/icon */ 6627);
/* harmony import */ var _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/tooltip */ 1436);








function VolumeNameComponent_mat_form_field_0_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-form-field", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵi18n"](2, 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "input", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("formControl", ctx_r0.metadataGroup.get("name"));
} }
function VolumeNameComponent_mat_form_field_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "mat-form-field", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵi18n"](2, 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "input", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "mat-icon", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, "info");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("formControl", ctx_r1.metadataGroup.get("generateName"));
} }
const NB_NAME_SUBST = '{notebook-name}';
class VolumeNameComponent {
    constructor() {
        this.templatedName = '';
        this.subs = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subscription();
        this.externalNamePrv = '';
    }
    get metadataGroup() {
        return this.group;
    }
    set metadataGroup(meta) {
        this.group = meta;
        this.subs.unsubscribe();
        // substitute {notebook-name}
        const nameCtrl = this.getNameCtrl(this.metadataGroup);
        setTimeout(() => {
            nameCtrl.setValue(this.templatedName.replace(NB_NAME_SUBST, this.externalName));
        });
    }
    get externalName() {
        return this.externalNamePrv;
    }
    set externalName(name) {
        this.externalNamePrv = name;
        if (!name) {
            return;
        }
        const nameCtrl = this.getNameCtrl(this.metadataGroup);
        if (nameCtrl.dirty) {
            return;
        }
        // to avoid ExpressionChangedAfterItHasBeenCheckedError
        setTimeout(() => {
            nameCtrl.setValue(this.templatedName.replace(NB_NAME_SUBST, name));
        });
    }
    ngOnInit() {
        this.templatedName = this.getNameCtrl(this.metadataGroup).value;
    }
    ngOnDestroy() {
        this.subs.unsubscribe();
    }
    getNameCtrl(metadata) {
        if (metadata.contains('name')) {
            return metadata.get('name');
        }
        if (metadata.contains('generateName')) {
            return metadata.get('generateName');
        }
    }
}
VolumeNameComponent.ɵfac = function VolumeNameComponent_Factory(t) { return new (t || VolumeNameComponent)(); };
VolumeNameComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: VolumeNameComponent, selectors: [["app-volume-name"]], inputs: { metadataGroup: "metadataGroup", externalName: "externalName" }, decls: 2, vars: 2, consts: function () { let i18n_0; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_8953033926734869941$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_NAME_NAME_COMPONENT_TS__1 = goog.getMsg("Name");
        i18n_0 = MSG_EXTERNAL_8953033926734869941$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_NAME_NAME_COMPONENT_TS__1;
    }
    else {
        i18n_0 = $localize `:␟cff1428d10d59d14e45edec3c735a27b5482db59␟8953033926734869941:Name`;
    } let i18n_2; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_2948619678148692701$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_NAME_NAME_COMPONENT_TS__3 = goog.getMsg("Name (suffix)");
        i18n_2 = MSG_EXTERNAL_2948619678148692701$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_NAME_NAME_COMPONENT_TS__3;
    }
    else {
        i18n_2 = $localize `:␟78c9916383da84b98abed62d9ed56f8e8febff96␟2948619678148692701:Name (suffix)`;
    } let i18n_4; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_6798731770798195602$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_NAME_NAME_COMPONENT_TS__5 = goog.getMsg("The cluster will append a random suffix to this name");
        i18n_4 = MSG_EXTERNAL_6798731770798195602$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_NAME_NAME_COMPONENT_TS__5;
    }
    else {
        i18n_4 = $localize `:␟d421e4bee57dd46a7691643ddf5d2361f17dacf0␟6798731770798195602:The cluster will append a random suffix to this name`;
    } return [["appearance", "outline", "class", "wide", 4, "ngIf"], ["appearance", "outline", 1, "wide"], i18n_0, ["autocomplete", "off", "matInput", "", 3, "formControl"], i18n_2, ["matSuffix", "", "matTooltip", i18n_4, 1, "info-icon"]]; }, template: function VolumeNameComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, VolumeNameComponent_mat_form_field_0_Template, 4, 1, "mat-form-field", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, VolumeNameComponent_mat_form_field_1_Template, 6, 1, "mat-form-field", 0);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.metadataGroup.get("name"));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.metadataGroup.get("generateName"));
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.NgIf, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_3__.MatFormField, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_3__.MatLabel, _angular_material_input__WEBPACK_IMPORTED_MODULE_4__.MatInput, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControlDirective, _angular_material_icon__WEBPACK_IMPORTED_MODULE_6__.MatIcon, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_3__.MatSuffix, _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_7__.MatTooltip], styles: ["[_nghost-%COMP%] {\n  display: block;\n}\n\n.info-icon[_ngcontent-%COMP%] {\n  color: rgba(0, 0, 0, 0.48);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5hbWUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxjQUFBO0FBQ0Y7O0FBRUE7RUFDRSwwQkFBQTtBQUNGIiwiZmlsZSI6Im5hbWUuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdCB7XG4gIGRpc3BsYXk6IGJsb2NrO1xufVxuXG4uaW5mby1pY29uIHtcbiAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC40OCk7XG59XG4iXX0= */"] });


/***/ }),

/***/ 5373:
/*!************************************************************************!*\
  !*** ./src/app/pages/form/form-default/volume/new/name/name.module.ts ***!
  \************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VolumeNameModule": function() { return /* binding */ VolumeNameModule; }
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _name_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./name.component */ 1910);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/form-field */ 8295);
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/input */ 3166);
/* harmony import */ var _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/checkbox */ 7539);
/* harmony import */ var kubeflow__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! kubeflow */ 872);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7716);








class VolumeNameModule {
}
VolumeNameModule.ɵfac = function VolumeNameModule_Factory(t) { return new (t || VolumeNameModule)(); };
VolumeNameModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({ type: VolumeNameModule });
VolumeNameModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__.ReactiveFormsModule,
            _angular_material_form_field__WEBPACK_IMPORTED_MODULE_4__.MatFormFieldModule,
            _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_5__.MatCheckboxModule,
            _angular_material_input__WEBPACK_IMPORTED_MODULE_6__.MatInputModule,
            kubeflow__WEBPACK_IMPORTED_MODULE_7__.FormModule,
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](VolumeNameModule, { declarations: [_name_component__WEBPACK_IMPORTED_MODULE_0__.VolumeNameComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_3__.ReactiveFormsModule,
        _angular_material_form_field__WEBPACK_IMPORTED_MODULE_4__.MatFormFieldModule,
        _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_5__.MatCheckboxModule,
        _angular_material_input__WEBPACK_IMPORTED_MODULE_6__.MatInputModule,
        kubeflow__WEBPACK_IMPORTED_MODULE_7__.FormModule], exports: [_name_component__WEBPACK_IMPORTED_MODULE_0__.VolumeNameComponent] }); })();


/***/ }),

/***/ 4129:
/*!*********************************************************************!*\
  !*** ./src/app/pages/form/form-default/volume/new/new.component.ts ***!
  \*********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NewVolumeComponent": function() { return /* binding */ NewVolumeComponent; }
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var js_yaml__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! js-yaml */ 9979);
/* harmony import */ var src_app_shared_utils_yaml__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/shared/utils/yaml */ 6473);
/* harmony import */ var src_app_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/types */ 4984);
/* harmony import */ var src_app_shared_utils_volumes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/utils/volumes */ 562);
/* harmony import */ var kubeflow__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! kubeflow */ 872);
/* harmony import */ var _app_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @app/environment */ 2340);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/material/form-field */ 8295);
/* harmony import */ var _angular_material_select__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/material/select */ 7441);
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/material/core */ 7817);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _rok_url_rok_url_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./rok-url/rok-url.component */ 7174);
/* harmony import */ var ng2_ace_editor__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ng2-ace-editor */ 9617);
/* harmony import */ var _name_name_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./name/name.component */ 1910);
/* harmony import */ var _size_size_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./size/size.component */ 899);
/* harmony import */ var _access_modes_access_modes_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./access-modes/access-modes.component */ 5739);
/* harmony import */ var _storage_class_storage_class_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./storage-class/storage-class.component */ 3951);



















function NewVolumeComponent_mat_option_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "mat-option", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵi18n"](1, 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("value", ctx_r0.NEW_VOLUME_TYPE.ROK_SNAPSHOT);
} }
function NewVolumeComponent_app_rok_url_9_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](0, "app-rok-url", 13);
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("volGroup", ctx_r1.volGroup);
} }
function NewVolumeComponent_ng_container_11_mat_error_8_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "mat-error");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtextInterpolate"](ctx_r4.errorParsingYaml);
} }
function NewVolumeComponent_ng_container_11_Template(rf, ctx) { if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerStart"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵi18n"](2, 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](3, "a", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtext"](4, "K8s docs");
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerStart"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵi18n"](6, 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](7, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("textChange", function NewVolumeComponent_ng_container_11_Template_div_textChange_7_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵrestoreView"](_r6); const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](); return ctx_r5.yaml = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](8, NewVolumeComponent_ng_container_11_mat_error_8_Template, 2, 1, "mat-error", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("text", ctx_r2.yaml);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r2.errorParsingYaml);
} }
function NewVolumeComponent_ng_container_12_app_storage_class_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](0, "app-storage-class", 23);
} if (rf & 2) {
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("scControl", ctx_r7.volGroup.get("newPvc.spec.storageClassName"));
} }
function NewVolumeComponent_ng_container_12_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](1, "app-volume-name", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](2, "app-volume-size", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](3, NewVolumeComponent_ng_container_12_app_storage_class_3_Template, 1, 1, "app-storage-class", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelement"](4, "app-volume-access-modes", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("metadataGroup", ctx_r3.volGroup.get("newPvc.metadata"))("externalName", ctx_r3.externalName);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("sizeCtrl", ctx_r3.volGroup.get("newPvc.spec.resources.requests.storage"));
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx_r3.volumeType === ctx_r3.NEW_VOLUME_TYPE.EMPTY);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("modesCtrl", ctx_r3.volGroup.get("newPvc.spec.accessModes"));
} }
class NewVolumeComponent {
    constructor(rok) {
        this.rok = rok;
        this.env = _app_environment__WEBPACK_IMPORTED_MODULE_4__.environment;
        this.yamlPrv = '';
        this.errorParsingYaml = '';
        this.NEW_VOLUME_TYPE = src_app_types__WEBPACK_IMPORTED_MODULE_2__.NEW_VOLUME_TYPE;
    }
    get volumeType() {
        var _a;
        if (!this.volGroup) {
            return src_app_types__WEBPACK_IMPORTED_MODULE_2__.NEW_VOLUME_TYPE.EMPTY;
        }
        const pvcGroup = this.volGroup.get('newPvc');
        // if we have a form-control then we expect the user to be typing yaml text
        if (pvcGroup instanceof _angular_forms__WEBPACK_IMPORTED_MODULE_12__.FormControl) {
            return src_app_types__WEBPACK_IMPORTED_MODULE_2__.NEW_VOLUME_TYPE.CUSTOM;
        }
        const pvc = pvcGroup.value;
        const annotations = (_a = pvc === null || pvc === void 0 ? void 0 : pvc.metadata) === null || _a === void 0 ? void 0 : _a.annotations;
        if (annotations && 'rok/origin' in annotations) {
            return src_app_types__WEBPACK_IMPORTED_MODULE_2__.NEW_VOLUME_TYPE.ROK_SNAPSHOT;
        }
        return src_app_types__WEBPACK_IMPORTED_MODULE_2__.NEW_VOLUME_TYPE.EMPTY;
    }
    get yaml() {
        return this.yamlPrv;
    }
    set yaml(text) {
        // Try to parse the YAML contents into a JS dict and store it in the
        // FormControl for the newPvc
        this.yamlPrv = text;
        const [parsed, error] = (0,src_app_shared_utils_yaml__WEBPACK_IMPORTED_MODULE_1__.parseYAML)(text);
        this.errorParsingYaml = error;
        if (error) {
            return;
        }
        this.volGroup.get('newPvc').setValue(parsed);
    }
    ngOnInit() { }
    typeChanged(type) {
        if (type === src_app_types__WEBPACK_IMPORTED_MODULE_2__.NEW_VOLUME_TYPE.CUSTOM) {
            // Remove the FormGroup and make newPvc a FormControl, since it's value
            // will be updated from the parsed YAML that the user will write
            const currPvc = this.volGroup.get('newPvc').value;
            this.volGroup.setControl('newPvc', new _angular_forms__WEBPACK_IMPORTED_MODULE_12__.FormControl({}));
            this.yaml = (0,js_yaml__WEBPACK_IMPORTED_MODULE_0__.dump)(currPvc);
            return;
        }
        // In both empty and Rok we will have an initial empty PVC definition
        this.volGroup.setControl('newPvc', (0,src_app_shared_utils_volumes__WEBPACK_IMPORTED_MODULE_3__.createNewPvcFormGroup)());
        if (type === src_app_types__WEBPACK_IMPORTED_MODULE_2__.NEW_VOLUME_TYPE.EMPTY) {
            return;
        }
        // Add annotations for Rok snapshot
        const meta = this.volGroup.get('newPvc.metadata');
        (0,src_app_shared_utils_volumes__WEBPACK_IMPORTED_MODULE_3__.setGenerateNameCtrl)(meta);
        const annotations = new _angular_forms__WEBPACK_IMPORTED_MODULE_12__.FormGroup({
            'rok/origin': new _angular_forms__WEBPACK_IMPORTED_MODULE_12__.FormControl('', [_angular_forms__WEBPACK_IMPORTED_MODULE_12__.Validators.required], [(0,kubeflow__WEBPACK_IMPORTED_MODULE_13__.rokUrlValidator)(this.rok)]),
        });
        meta.addControl('annotations', annotations);
        // set storage class to be rok
        this.volGroup.get('newPvc.spec.storageClassName').enable();
        this.volGroup.get('newPvc.spec.storageClassName').setValue('rok');
    }
}
NewVolumeComponent.ɵfac = function NewVolumeComponent_Factory(t) { return new (t || NewVolumeComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdirectiveInject"](kubeflow__WEBPACK_IMPORTED_MODULE_13__.RokService)); };
NewVolumeComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵdefineComponent"]({ type: NewVolumeComponent, selectors: [["app-new-volume"]], inputs: { volGroup: "volGroup", externalName: "externalName" }, decls: 13, vars: 7, consts: function () { let i18n_0; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_8650499415827640724$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_NEW_COMPONENT_TS_1 = goog.getMsg("Type");
        i18n_0 = MSG_EXTERNAL_8650499415827640724$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_NEW_COMPONENT_TS_1;
    }
    else {
        i18n_0 = $localize `:␟f61c6867295f3b53d23557021f2f4e0aa1d0b8fc␟8650499415827640724:Type`;
    } let i18n_2; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_3293764150377907994$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_NEW_COMPONENT_TS_3 = goog.getMsg(" Empty volume ");
        i18n_2 = MSG_EXTERNAL_3293764150377907994$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_NEW_COMPONENT_TS_3;
    }
    else {
        i18n_2 = $localize `:␟3cee9bf23fd146de773f2eb0215e36d2ba8241bc␟3293764150377907994: Empty volume `;
    } let i18n_4; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_504344178295085185$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_NEW_COMPONENT_TS_5 = goog.getMsg("Edit the K8s PVC full spec");
        i18n_4 = MSG_EXTERNAL_504344178295085185$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_NEW_COMPONENT_TS_5;
    }
    else {
        i18n_4 = $localize `:␟467cb43f65c4fc4a58e318c5a295e892749658f5␟504344178295085185:Edit the K8s PVC full spec`;
    } let i18n_6; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_720964526638374966$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_NEW_COMPONENT_TS_7 = goog.getMsg(" Custom (Advanced) ");
        i18n_6 = MSG_EXTERNAL_720964526638374966$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_NEW_COMPONENT_TS_7;
    }
    else {
        i18n_6 = $localize `:␟f76feb32fc89ce5736a62ee29ed3de9de1439e03␟720964526638374966: Custom (Advanced) `;
    } let i18n_8; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_5968359843000060162$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_NEW_COMPONENT_TS__9 = goog.getMsg(" Rok snapshot ");
        i18n_8 = MSG_EXTERNAL_5968359843000060162$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_NEW_COMPONENT_TS__9;
    }
    else {
        i18n_8 = $localize `:␟3650d2757f8ad98fbfb20ae4c5444357faa872df␟5968359843000060162: Rok snapshot `;
    } let i18n_10; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_4027459734657890990$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_NEW_COMPONENT_TS__11 = goog.getMsg("Check the ");
        i18n_10 = MSG_EXTERNAL_4027459734657890990$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_NEW_COMPONENT_TS__11;
    }
    else {
        i18n_10 = $localize `:␟b335fa806932b539c41cb777d52f71dc057f7608␟4027459734657890990:Check the `;
    } let i18n_12; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_5329282524534762878$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_NEW_COMPONENT_TS__13 = goog.getMsg(" for the supported volumes and their specs");
        i18n_12 = MSG_EXTERNAL_5329282524534762878$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_NEW_COMPONENT_TS__13;
    }
    else {
        i18n_12 = $localize `:␟0f63b191d2f34ec123ce019e85d056f52d4ee971␟5329282524534762878: for the supported volumes and their specs`;
    } return [["appearance", "outline", 1, "wide"], i18n_0, [3, "value", "selectionChange"], [3, "value"], i18n_2, [3, "value", 4, "ngIf"], ["matTooltip", i18n_4, 3, "value"], i18n_6, [3, "volGroup", 4, "ngIf"], [3, "ngSwitch"], [4, "ngSwitchCase"], [4, "ngSwitchDefault"], i18n_8, [3, "volGroup"], i18n_10, ["target", "_blank", "href", "https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.19/#persistentvolumeclaim-v1-core"], i18n_12, ["ace-editor", "", "mode", "yaml", "theme", "xcode", 3, "text", "textChange"], [4, "ngIf"], [3, "metadataGroup", "externalName"], [3, "sizeCtrl"], [3, "scControl", 4, "ngIf"], [3, "modesCtrl"], [3, "scControl"]]; }, template: function NewVolumeComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](0, "mat-form-field", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](1, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵi18n"](2, 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](3, "mat-select", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵlistener"]("selectionChange", function NewVolumeComponent_Template_mat_select_selectionChange_3_listener($event) { return ctx.typeChanged($event.value); });
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](4, "mat-option", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵi18n"](5, 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](6, NewVolumeComponent_mat_option_6_Template, 2, 1, "mat-option", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementStart"](7, "mat-option", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵi18n"](8, 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](9, NewVolumeComponent_app_rok_url_9_Template, 1, 1, "app-rok-url", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerStart"](10, 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](11, NewVolumeComponent_ng_container_11_Template, 9, 2, "ng-container", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵtemplate"](12, NewVolumeComponent_ng_container_12_Template, 5, 5, "ng-container", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵelementContainerEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("value", ctx.volumeType);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("value", ctx.NEW_VOLUME_TYPE.EMPTY);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx.env.ui === "rok");
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("value", ctx.NEW_VOLUME_TYPE.CUSTOM);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngIf", ctx.volGroup.get("newPvc.metadata.annotations.rok/origin"));
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngSwitch", ctx.volumeType);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_11__["ɵɵproperty"]("ngSwitchCase", ctx.NEW_VOLUME_TYPE.CUSTOM);
    } }, directives: [_angular_material_form_field__WEBPACK_IMPORTED_MODULE_14__.MatFormField, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_14__.MatLabel, _angular_material_select__WEBPACK_IMPORTED_MODULE_15__.MatSelect, _angular_material_core__WEBPACK_IMPORTED_MODULE_16__.MatOption, _angular_common__WEBPACK_IMPORTED_MODULE_17__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_17__.NgSwitch, _angular_common__WEBPACK_IMPORTED_MODULE_17__.NgSwitchCase, _angular_common__WEBPACK_IMPORTED_MODULE_17__.NgSwitchDefault, _rok_url_rok_url_component__WEBPACK_IMPORTED_MODULE_5__.RokUrlComponent, ng2_ace_editor__WEBPACK_IMPORTED_MODULE_6__.AceEditorDirective, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_14__.MatError, _name_name_component__WEBPACK_IMPORTED_MODULE_7__.VolumeNameComponent, _size_size_component__WEBPACK_IMPORTED_MODULE_8__.VolumeSizeComponent, _access_modes_access_modes_component__WEBPACK_IMPORTED_MODULE_9__.VolumeAccessModesComponent, _storage_class_storage_class_component__WEBPACK_IMPORTED_MODULE_10__.StorageClassComponent], styles: ["[_nghost-%COMP%] {\n  display: block;\n}\n\n[ace-editor][_ngcontent-%COMP%] {\n  width: auto;\n  height: 250px;\n  margin-top: 0.5rem;\n  margin-bottom: 1rem;\n}\n\n.mat-error[_ngcontent-%COMP%] {\n  margin-bottom: 1rem;\n  white-space: pre-wrap;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5ldy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGNBQUE7QUFDRjs7QUFFQTtFQUNFLFdBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtBQUNGOztBQUVBO0VBQ0UsbUJBQUE7RUFDQSxxQkFBQTtBQUNGIiwiZmlsZSI6Im5ldy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IHtcbiAgZGlzcGxheTogYmxvY2s7XG59XG5cblthY2UtZWRpdG9yXSB7XG4gIHdpZHRoOiBhdXRvO1xuICBoZWlnaHQ6IDI1MHB4O1xuICBtYXJnaW4tdG9wOiAwLjVyZW07XG4gIG1hcmdpbi1ib3R0b206IDFyZW07XG59XG5cbi5tYXQtZXJyb3Ige1xuICBtYXJnaW4tYm90dG9tOiAxcmVtO1xuICB3aGl0ZS1zcGFjZTogcHJlLXdyYXA7XG59XG4iXX0= */"] });


/***/ }),

/***/ 753:
/*!******************************************************************!*\
  !*** ./src/app/pages/form/form-default/volume/new/new.module.ts ***!
  \******************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NewVolumeModule": function() { return /* binding */ NewVolumeModule; }
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _new_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./new.component */ 4129);
/* harmony import */ var _name_name_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./name/name.module */ 5373);
/* harmony import */ var _storage_class_storage_class_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./storage-class/storage-class.module */ 6643);
/* harmony import */ var _access_modes_access_modes_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./access-modes/access-modes.module */ 8783);
/* harmony import */ var _size_size_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./size/size.module */ 1219);
/* harmony import */ var ng2_ace_editor__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ng2-ace-editor */ 9617);
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/input */ 3166);
/* harmony import */ var _angular_material_select__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/select */ 7441);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/material/form-field */ 8295);
/* harmony import */ var _rok_url_rok_url_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./rok-url/rok-url.module */ 5355);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 7716);













class NewVolumeModule {
}
NewVolumeModule.ɵfac = function NewVolumeModule_Factory(t) { return new (t || NewVolumeModule)(); };
NewVolumeModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineNgModule"]({ type: NewVolumeModule });
NewVolumeModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_8__.CommonModule,
            _name_name_module__WEBPACK_IMPORTED_MODULE_1__.VolumeNameModule,
            _storage_class_storage_class_module__WEBPACK_IMPORTED_MODULE_2__.StorageClassModule,
            _access_modes_access_modes_module__WEBPACK_IMPORTED_MODULE_3__.VolumeAccessModesModule,
            _size_size_module__WEBPACK_IMPORTED_MODULE_4__.VolumeSizeModule,
            ng2_ace_editor__WEBPACK_IMPORTED_MODULE_5__.AceEditorModule,
            _angular_material_input__WEBPACK_IMPORTED_MODULE_9__.MatInputModule,
            _angular_material_select__WEBPACK_IMPORTED_MODULE_10__.MatSelectModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_11__.ReactiveFormsModule,
            _angular_material_form_field__WEBPACK_IMPORTED_MODULE_12__.MatFormFieldModule,
            _rok_url_rok_url_module__WEBPACK_IMPORTED_MODULE_6__.RokUrlModule,
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵsetNgModuleScope"](NewVolumeModule, { declarations: [_new_component__WEBPACK_IMPORTED_MODULE_0__.NewVolumeComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_8__.CommonModule,
        _name_name_module__WEBPACK_IMPORTED_MODULE_1__.VolumeNameModule,
        _storage_class_storage_class_module__WEBPACK_IMPORTED_MODULE_2__.StorageClassModule,
        _access_modes_access_modes_module__WEBPACK_IMPORTED_MODULE_3__.VolumeAccessModesModule,
        _size_size_module__WEBPACK_IMPORTED_MODULE_4__.VolumeSizeModule,
        ng2_ace_editor__WEBPACK_IMPORTED_MODULE_5__.AceEditorModule,
        _angular_material_input__WEBPACK_IMPORTED_MODULE_9__.MatInputModule,
        _angular_material_select__WEBPACK_IMPORTED_MODULE_10__.MatSelectModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_11__.ReactiveFormsModule,
        _angular_material_form_field__WEBPACK_IMPORTED_MODULE_12__.MatFormFieldModule,
        _rok_url_rok_url_module__WEBPACK_IMPORTED_MODULE_6__.RokUrlModule], exports: [_new_component__WEBPACK_IMPORTED_MODULE_0__.NewVolumeComponent] }); })();


/***/ }),

/***/ 7174:
/*!*********************************************************************************!*\
  !*** ./src/app/pages/form/form-default/volume/new/rok-url/rok-url.component.ts ***!
  \*********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RokUrlComponent": function() { return /* binding */ RokUrlComponent; }
/* harmony export */ });
/* harmony import */ var kubeflow__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! kubeflow */ 872);
/* harmony import */ var src_app_shared_utils_volumes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/shared/utils/volumes */ 562);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);




class RokUrlComponent {
    constructor(rok, snack) {
        this.rok = rok;
        this.snack = snack;
    }
    ngOnInit() { }
    autofillRokVolume(url) {
        this.rok.getObjectMetadata(url).subscribe(headers => {
            const name = headers.get('X-Object-Meta-workspace') ||
                headers.get('X-Object-Meta-dataset') ||
                headers.get('x-object-meta-pvc');
            let size = parseInt(headers.get('Content-Length'), 10);
            size = size / Math.pow(1024, 3);
            const path = headers.get('X-Object-Meta-mountpoint');
            const pvcGroup = this.volGroup.get('newPvc');
            pvcGroup.get('spec.resources.requests.storage').setValue(`${size}Gi`);
            this.volGroup.get('mount').setValue(path);
            // ensure we use generateName
            const meta = this.volGroup.get('newPvc.metadata');
            (0,src_app_shared_utils_volumes__WEBPACK_IMPORTED_MODULE_0__.setGenerateNameCtrl)(meta, `${name}-`);
            this.snack.open('Volume was autofilled successfully.', kubeflow__WEBPACK_IMPORTED_MODULE_1__.SnackType.Success, 3000);
        });
    }
}
RokUrlComponent.ɵfac = function RokUrlComponent_Factory(t) { return new (t || RokUrlComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](kubeflow__WEBPACK_IMPORTED_MODULE_1__.RokService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](kubeflow__WEBPACK_IMPORTED_MODULE_1__.SnackBarService)); };
RokUrlComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({ type: RokUrlComponent, selectors: [["app-rok-url"]], inputs: { volGroup: "volGroup" }, decls: 1, vars: 1, consts: [["mode", "file", 1, "wide", 3, "control", "urlPasted", "urlEntered"]], template: function RokUrlComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "lib-rok-url-input", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("urlPasted", function RokUrlComponent_Template_lib_rok_url_input_urlPasted_0_listener($event) { return ctx.autofillRokVolume($event); })("urlEntered", function RokUrlComponent_Template_lib_rok_url_input_urlEntered_0_listener($event) { return ctx.autofillRokVolume($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("control", ctx.volGroup.get("newPvc.metadata.annotations.rok/origin"));
    } }, directives: [kubeflow__WEBPACK_IMPORTED_MODULE_1__.RokUrlInputComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJyb2stdXJsLmNvbXBvbmVudC5zY3NzIn0= */"] });


/***/ }),

/***/ 5355:
/*!******************************************************************************!*\
  !*** ./src/app/pages/form/form-default/volume/new/rok-url/rok-url.module.ts ***!
  \******************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RokUrlModule": function() { return /* binding */ RokUrlModule; }
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _rok_url_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./rok-url.component */ 7174);
/* harmony import */ var kubeflow__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! kubeflow */ 872);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7716);




class RokUrlModule {
}
RokUrlModule.ɵfac = function RokUrlModule_Factory(t) { return new (t || RokUrlModule)(); };
RokUrlModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({ type: RokUrlModule });
RokUrlModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({ imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule, kubeflow__WEBPACK_IMPORTED_MODULE_3__.FormModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](RokUrlModule, { declarations: [_rok_url_component__WEBPACK_IMPORTED_MODULE_0__.RokUrlComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule, kubeflow__WEBPACK_IMPORTED_MODULE_3__.FormModule], exports: [_rok_url_component__WEBPACK_IMPORTED_MODULE_0__.RokUrlComponent] }); })();


/***/ }),

/***/ 899:
/*!***************************************************************************!*\
  !*** ./src/app/pages/form/form-default/volume/new/size/size.component.ts ***!
  \***************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VolumeSizeComponent": function() { return /* binding */ VolumeSizeComponent; }
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material/form-field */ 8295);
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/input */ 3166);





class VolumeSizeComponent {
    constructor() {
        this.sizeNum = new _angular_forms__WEBPACK_IMPORTED_MODULE_0__.FormControl(1, _angular_forms__WEBPACK_IMPORTED_MODULE_0__.Validators.required);
    }
    get sizeCtrl() {
        return this.ctrl;
    }
    set sizeCtrl(ctrl) {
        if (this.sub) {
            this.sub.unsubscribe();
        }
        this.ctrl = ctrl;
        this.sub = this.ctrl.valueChanges.subscribe(size => {
            this.sizeNum.setValue(this.parseK8sGiSizeToInt(size));
        });
    }
    ngOnInit() {
        this.sizeNum.setValue(this.parseK8sGiSizeToInt(this.sizeCtrl.value));
        this.sizeCtrl.setValue(`${this.sizeNum.value}Gi`);
        this.sizeNum.valueChanges.subscribe(size => {
            this.sizeCtrl.setValue(`${size}Gi`, { emitEvent: false });
        });
    }
    parseK8sGiSizeToInt(sizeK8s) {
        if (sizeK8s.includes('Gi')) {
            return parseInt(sizeK8s.replace('Gi', ''), 10);
        }
        if (sizeK8s.includes('Mi')) {
            return parseInt(sizeK8s.replace('Mi', ''), 10) / 1000;
        }
        return parseInt(sizeK8s, 10);
    }
}
VolumeSizeComponent.ɵfac = function VolumeSizeComponent_Factory(t) { return new (t || VolumeSizeComponent)(); };
VolumeSizeComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: VolumeSizeComponent, selectors: [["app-volume-size"]], inputs: { sizeCtrl: "sizeCtrl" }, decls: 4, vars: 1, consts: function () { let i18n_0; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_2772330728479814494$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_SIZE_SIZE_COMPONENT_TS_1 = goog.getMsg("Size in Gi");
        i18n_0 = MSG_EXTERNAL_2772330728479814494$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_SIZE_SIZE_COMPONENT_TS_1;
    }
    else {
        i18n_0 = $localize `:␟e1b3e1dca04b54d87b5a7ff9593676dacaf6dce0␟2772330728479814494:Size in Gi`;
    } return [["appearance", "outline", 1, "wide"], i18n_0, ["autocomplete", "off", "matInput", "", "type", "number", "min", "1", 3, "formControl"]]; }, template: function VolumeSizeComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-form-field", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵi18n"](2, 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](3, "input", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formControl", ctx.sizeNum);
    } }, directives: [_angular_material_form_field__WEBPACK_IMPORTED_MODULE_2__.MatFormField, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_2__.MatLabel, _angular_material_input__WEBPACK_IMPORTED_MODULE_3__.MatInput, _angular_forms__WEBPACK_IMPORTED_MODULE_0__.MinValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_0__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_0__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_0__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_0__.FormControlDirective], styles: ["[_nghost-%COMP%] {\n  display: block;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNpemUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxjQUFBO0FBQ0YiLCJmaWxlIjoic2l6ZS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0IHtcbiAgZGlzcGxheTogYmxvY2s7XG59XG4iXX0= */"] });


/***/ }),

/***/ 1219:
/*!************************************************************************!*\
  !*** ./src/app/pages/form/form-default/volume/new/size/size.module.ts ***!
  \************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VolumeSizeModule": function() { return /* binding */ VolumeSizeModule; }
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _size_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./size.component */ 899);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/form-field */ 8295);
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/input */ 3166);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7716);






class VolumeSizeModule {
}
VolumeSizeModule.ɵfac = function VolumeSizeModule_Factory(t) { return new (t || VolumeSizeModule)(); };
VolumeSizeModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({ type: VolumeSizeModule });
VolumeSizeModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__.ReactiveFormsModule,
            _angular_material_form_field__WEBPACK_IMPORTED_MODULE_4__.MatFormFieldModule,
            _angular_material_input__WEBPACK_IMPORTED_MODULE_5__.MatInputModule,
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](VolumeSizeModule, { declarations: [_size_component__WEBPACK_IMPORTED_MODULE_0__.VolumeSizeComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_3__.ReactiveFormsModule,
        _angular_material_form_field__WEBPACK_IMPORTED_MODULE_4__.MatFormFieldModule,
        _angular_material_input__WEBPACK_IMPORTED_MODULE_5__.MatInputModule], exports: [_size_component__WEBPACK_IMPORTED_MODULE_0__.VolumeSizeComponent] }); })();


/***/ }),

/***/ 3951:
/*!*********************************************************************************************!*\
  !*** ./src/app/pages/form/form-default/volume/new/storage-class/storage-class.component.ts ***!
  \*********************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StorageClassComponent": function() { return /* binding */ StorageClassComponent; }
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var src_app_services_backend_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/services/backend.service */ 600);
/* harmony import */ var _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material/checkbox */ 7539);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/form-field */ 8295);
/* harmony import */ var _angular_material_select__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/select */ 7441);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/core */ 7817);








function StorageClassComponent_mat_form_field_4_mat_option_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-option", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const sc_r2 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("value", sc_r2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", sc_r2, " ");
} }
function StorageClassComponent_mat_form_field_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-form-field", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "mat-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵi18n"](2, 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "mat-select", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "mat-option", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵi18n"](5, 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](6, StorageClassComponent_mat_form_field_4_mat_option_6_Template, 2, 2, "mat-option", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formControl", ctx_r0.scControl);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx_r0.storageClasses);
} }
class StorageClassComponent {
    constructor(backend) {
        this.backend = backend;
        this.storageClasses = [];
    }
    ngOnInit() {
        // get list of storage classes
        this.backend.getStorageClasses().subscribe(classes => {
            this.storageClasses = classes;
        });
        // get the default storage class
        this.backend.getDefaultStorageClass().subscribe(sc => {
            this.defaultStoraceClass = sc;
            if (!this.scControl || !this.scControl.disabled) {
                return;
            }
            // if control is disabled then the user wants to use the default SC
            this.scControl.setValue(sc);
        });
    }
    useDefaultSC(useDefault) {
        if (useDefault) {
            this.scControl.disable();
            return;
        }
        this.scControl.enable();
    }
}
StorageClassComponent.ɵfac = function StorageClassComponent_Factory(t) { return new (t || StorageClassComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_services_backend_service__WEBPACK_IMPORTED_MODULE_0__.JWABackendService)); };
StorageClassComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: StorageClassComponent, selectors: [["app-storage-class"]], inputs: { scControl: "scControl" }, decls: 5, vars: 2, consts: function () { let i18n_0; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_4222409682577085383$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_STORAGE_CLASS_STORAGE_CLASS_COMPONENT_TS_1 = goog.getMsg("Storage class");
        i18n_0 = MSG_EXTERNAL_4222409682577085383$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_STORAGE_CLASS_STORAGE_CLASS_COMPONENT_TS_1;
    }
    else {
        i18n_0 = $localize `:␟8ed57f58c52893da918e1980cd1e32164e3102d5␟4222409682577085383:Storage class`;
    } let i18n_2; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_4641016612479344576$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_STORAGE_CLASS_STORAGE_CLASS_COMPONENT_TS_3 = goog.getMsg(" Use default class\n");
        i18n_2 = MSG_EXTERNAL_4641016612479344576$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_STORAGE_CLASS_STORAGE_CLASS_COMPONENT_TS_3;
    }
    else {
        i18n_2 = $localize `:␟54fa36f107a0650f7556f5841b80dc015586c6f2␟4641016612479344576: Use default class
`;
    } let i18n_4; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_4378796785985219718$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_STORAGE_CLASS_STORAGE_CLASS_COMPONENT_TS__5 = goog.getMsg("Class");
        i18n_4 = MSG_EXTERNAL_4378796785985219718$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_STORAGE_CLASS_STORAGE_CLASS_COMPONENT_TS__5;
    }
    else {
        i18n_4 = $localize `:␟f60c6c571ed1e6266976ca261a2b2d0ebaa16c6e␟4378796785985219718:Class`;
    } let i18n_6; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_8403775781739160278$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_STORAGE_CLASS_STORAGE_CLASS_COMPONENT_TS__7 = goog.getMsg("Empty storage class");
        i18n_6 = MSG_EXTERNAL_8403775781739160278$$SRC_APP_PAGES_FORM_FORM_DEFAULT_VOLUME_NEW_STORAGE_CLASS_STORAGE_CLASS_COMPONENT_TS__7;
    }
    else {
        i18n_6 = $localize `:␟a35c9d1ca73f1956db44f5cf67f7c79214e0a46e␟8403775781739160278:Empty storage class`;
    } return [[1, "form-title"], i18n_0, [3, "checked", "change"], i18n_2, ["appearance", "outline", "class", "wide", 4, "ngIf"], ["appearance", "outline", 1, "wide"], i18n_4, [3, "formControl"], ["value", ""], i18n_6, [3, "value", 4, "ngFor", "ngForOf"], [3, "value"]]; }, template: function StorageClassComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵi18n"](1, 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "mat-checkbox", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("change", function StorageClassComponent_Template_mat_checkbox_change_2_listener($event) { return ctx.useDefaultSC($event.checked); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵi18n"](3, 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](4, StorageClassComponent_mat_form_field_4_Template, 7, 2, "mat-form-field", 4);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("checked", ctx.scControl == null ? null : ctx.scControl.disabled);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.scControl);
    } }, directives: [_angular_material_checkbox__WEBPACK_IMPORTED_MODULE_2__.MatCheckbox, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_4__.MatFormField, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_4__.MatLabel, _angular_material_select__WEBPACK_IMPORTED_MODULE_5__.MatSelect, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormControlDirective, _angular_material_core__WEBPACK_IMPORTED_MODULE_7__.MatOption, _angular_common__WEBPACK_IMPORTED_MODULE_3__.NgForOf], styles: ["[_nghost-%COMP%] {\n  display: block;\n}\n\n.form-title[_ngcontent-%COMP%] {\n  font-weight: 500;\n  margin-bottom: 0.4rem;\n  color: rgba(0, 0, 0, 0.64);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN0b3JhZ2UtY2xhc3MuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxjQUFBO0FBQ0Y7O0FBRUE7RUFDRSxnQkFBQTtFQUNBLHFCQUFBO0VBQ0EsMEJBQUE7QUFDRiIsImZpbGUiOiJzdG9yYWdlLWNsYXNzLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3Qge1xuICBkaXNwbGF5OiBibG9jaztcbn1cblxuLmZvcm0tdGl0bGUge1xuICBmb250LXdlaWdodDogNTAwO1xuICBtYXJnaW4tYm90dG9tOiAwLjRyZW07XG4gIGNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuNjQpO1xufVxuIl19 */"] });


/***/ }),

/***/ 6643:
/*!******************************************************************************************!*\
  !*** ./src/app/pages/form/form-default/volume/new/storage-class/storage-class.module.ts ***!
  \******************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StorageClassModule": function() { return /* binding */ StorageClassModule; }
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _storage_class_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./storage-class.component */ 3951);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/form-field */ 8295);
/* harmony import */ var _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/checkbox */ 7539);
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/input */ 3166);
/* harmony import */ var _angular_material_select__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/select */ 7441);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7716);








class StorageClassModule {
}
StorageClassModule.ɵfac = function StorageClassModule_Factory(t) { return new (t || StorageClassModule)(); };
StorageClassModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({ type: StorageClassModule });
StorageClassModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__.ReactiveFormsModule,
            _angular_material_form_field__WEBPACK_IMPORTED_MODULE_4__.MatFormFieldModule,
            _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_5__.MatCheckboxModule,
            _angular_material_input__WEBPACK_IMPORTED_MODULE_6__.MatInputModule,
            _angular_material_select__WEBPACK_IMPORTED_MODULE_7__.MatSelectModule,
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](StorageClassModule, { declarations: [_storage_class_component__WEBPACK_IMPORTED_MODULE_0__.StorageClassComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_3__.ReactiveFormsModule,
        _angular_material_form_field__WEBPACK_IMPORTED_MODULE_4__.MatFormFieldModule,
        _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_5__.MatCheckboxModule,
        _angular_material_input__WEBPACK_IMPORTED_MODULE_6__.MatInputModule,
        _angular_material_select__WEBPACK_IMPORTED_MODULE_7__.MatSelectModule], exports: [_storage_class_component__WEBPACK_IMPORTED_MODULE_0__.StorageClassComponent] }); })();


/***/ }),

/***/ 5097:
/*!*****************************************************************!*\
  !*** ./src/app/pages/form/form-default/volume/volume.module.ts ***!
  \*****************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VolumeModule": function() { return /* binding */ VolumeModule; }
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/icon */ 6627);
/* harmony import */ var _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/tooltip */ 1436);
/* harmony import */ var _existing_existing_volume_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./existing/existing-volume.module */ 1142);
/* harmony import */ var _mount_mount_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mount/mount.module */ 9801);
/* harmony import */ var _new_new_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./new/new.module */ 753);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/button */ 1095);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);








class VolumeModule {
}
VolumeModule.ɵfac = function VolumeModule_Factory(t) { return new (t || VolumeModule)(); };
VolumeModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({ type: VolumeModule });
VolumeModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_material_icon__WEBPACK_IMPORTED_MODULE_5__.MatIconModule,
            _angular_material_button__WEBPACK_IMPORTED_MODULE_6__.MatButtonModule,
            _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_7__.MatTooltipModule,
            _existing_existing_volume_module__WEBPACK_IMPORTED_MODULE_0__.ExistingVolumeModule,
            _mount_mount_module__WEBPACK_IMPORTED_MODULE_1__.VolumeMountModule,
            _new_new_module__WEBPACK_IMPORTED_MODULE_2__.NewVolumeModule,
        ], _existing_existing_volume_module__WEBPACK_IMPORTED_MODULE_0__.ExistingVolumeModule, _mount_mount_module__WEBPACK_IMPORTED_MODULE_1__.VolumeMountModule, _new_new_module__WEBPACK_IMPORTED_MODULE_2__.NewVolumeModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](VolumeModule, { imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
        _angular_material_icon__WEBPACK_IMPORTED_MODULE_5__.MatIconModule,
        _angular_material_button__WEBPACK_IMPORTED_MODULE_6__.MatButtonModule,
        _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_7__.MatTooltipModule,
        _existing_existing_volume_module__WEBPACK_IMPORTED_MODULE_0__.ExistingVolumeModule,
        _mount_mount_module__WEBPACK_IMPORTED_MODULE_1__.VolumeMountModule,
        _new_new_module__WEBPACK_IMPORTED_MODULE_2__.NewVolumeModule], exports: [_existing_existing_volume_module__WEBPACK_IMPORTED_MODULE_0__.ExistingVolumeModule, _mount_mount_module__WEBPACK_IMPORTED_MODULE_1__.VolumeMountModule, _new_new_module__WEBPACK_IMPORTED_MODULE_2__.NewVolumeModule] }); })();


/***/ }),

/***/ 5215:
/*!***********************************************************!*\
  !*** ./src/app/pages/form/form-rok/form-rok.component.ts ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormRokComponent": function() { return /* binding */ FormRokComponent; }
/* harmony export */ });
/* harmony import */ var _app_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @app/environment */ 2340);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _form_default_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../form-default/utils */ 3261);
/* harmony import */ var _form_default_form_default_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../form-default/form-default.component */ 849);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var kubeflow__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! kubeflow */ 872);
/* harmony import */ var src_app_services_backend_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/backend.service */ 600);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _rok_jupyter_lab_selector_rok_jupyter_lab_selector_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./rok-jupyter-lab-selector/rok-jupyter-lab-selector.component */ 4373);
/* harmony import */ var _form_default_form_name_form_name_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../form-default/form-name/form-name.component */ 4249);
/* harmony import */ var _form_default_form_image_form_image_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../form-default/form-image/form-image.component */ 1330);
/* harmony import */ var _form_default_form_cpu_ram_form_cpu_ram_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../form-default/form-cpu-ram/form-cpu-ram.component */ 9492);
/* harmony import */ var _form_default_form_gpus_form_gpus_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../form-default/form-gpus/form-gpus.component */ 184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _form_default_form_data_volumes_form_data_volumes_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../form-default/form-data-volumes/form-data-volumes.component */ 5524);
/* harmony import */ var _rok_form_configurations_rok_form_configurations_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./rok-form-configurations/rok-form-configurations.component */ 936);
/* harmony import */ var _form_default_form_affinity_tolerations_form_affinity_tolerations_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../form-default/form-affinity-tolerations/form-affinity-tolerations.component */ 6440);
/* harmony import */ var _form_default_form_advanced_options_form_advanced_options_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../form-default/form-advanced-options/form-advanced-options.component */ 5905);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/material/button */ 1095);
/* harmony import */ var _form_default_form_workspace_volume_form_workspace_volume_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../form-default/form-workspace-volume/form-workspace-volume.component */ 4537);





















function FormRokComponent_app_form_workspace_volume_9_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](0, "app-form-workspace-volume", 16);
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("readonly", ctx_r0.config == null ? null : ctx_r0.config.workspaceVolume == null ? null : ctx_r0.config.workspaceVolume.readOnly)("volGroup", ctx_r0.formCtrl.get("workspace"))("externalName", ctx_r0.formCtrl.get("name").value);
} }
class FormRokComponent extends _form_default_form_default_component__WEBPACK_IMPORTED_MODULE_2__.FormDefaultComponent {
    constructor(ns, backend, router, popup, rok) {
        super(ns, backend, router, popup);
        this.ns = ns;
        this.backend = backend;
        this.router = router;
        this.popup = popup;
        this.rok = rok;
        this.env = _app_environment__WEBPACK_IMPORTED_MODULE_0__.environment;
    }
    ngOnInit() {
        super.ngOnInit();
        this.rok.initCSRF();
    }
    // Form handling functions
    getFormDefaults() {
        // Init the form
        const formCtrl = (0,_form_default_utils__WEBPACK_IMPORTED_MODULE_1__.getFormDefaults)();
        // Add labUrl control
        formCtrl.addControl('environment', new _angular_forms__WEBPACK_IMPORTED_MODULE_15__.FormControl('', [_angular_forms__WEBPACK_IMPORTED_MODULE_15__.Validators.required]));
        return formCtrl;
    }
    initFormControls(formCtrl, config) {
        // Sets the values from our internal dict. This is an initialization step
        // that should be only run once
        (0,_form_default_utils__WEBPACK_IMPORTED_MODULE_1__.initFormControls)(formCtrl, config);
        // Handle the Pod environment
        if (config.environment && config.environment.value) {
            const envVal = JSON.stringify(config.environment.value);
            formCtrl.controls.environment.setValue(envVal);
        }
        else {
            formCtrl.controls.environment.setValue('{}');
        }
        if (config.environment && config.environment.readOnly) {
            formCtrl.controls.environment.disable();
        }
    }
}
FormRokComponent.ɵfac = function FormRokComponent_Factory(t) { return new (t || FormRokComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](kubeflow__WEBPACK_IMPORTED_MODULE_16__.NamespaceService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](src_app_services_backend_service__WEBPACK_IMPORTED_MODULE_3__.JWABackendService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_17__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](kubeflow__WEBPACK_IMPORTED_MODULE_16__.SnackBarService), _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdirectiveInject"](kubeflow__WEBPACK_IMPORTED_MODULE_16__.RokService)); };
FormRokComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdefineComponent"]({ type: FormRokComponent, selectors: [["app-form-rok"]], features: [_angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵInheritDefinitionFeature"]], decls: 19, vars: 26, consts: function () { let i18n_0; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_8239470330825170191$$SRC_APP_PAGES_FORM_FORM_ROK_FORM_ROK_COMPONENT_TS_1 = goog.getMsg(" LAUNCH ");
        i18n_0 = MSG_EXTERNAL_8239470330825170191$$SRC_APP_PAGES_FORM_FORM_ROK_FORM_ROK_COMPONENT_TS_1;
    }
    else {
        i18n_0 = $localize `:␟426440b9cd9f72a1537050344630be55c8d96aa8␟8239470330825170191: LAUNCH `;
    } let i18n_2; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_9168358659421118429$$SRC_APP_PAGES_FORM_FORM_ROK_FORM_ROK_COMPONENT_TS_3 = goog.getMsg(" CANCEL ");
        i18n_2 = MSG_EXTERNAL_9168358659421118429$$SRC_APP_PAGES_FORM_FORM_ROK_FORM_ROK_COMPONENT_TS_3;
    }
    else {
        i18n_2 = $localize `:␟35d035552a3b9e0fb0d9be51e18575b2ed727678␟9168358659421118429: CANCEL `;
    } return [[1, "lib-content-wrapper"], ["title", "New notebook", 3, "backButton", "back"], [1, "page-padding", "lib-flex-grow", "lib-overflow-auto"], ["novalidate", "", 1, "form", 3, "formGroup", "ngSubmit"], [3, "parentForm"], [3, "parentForm", "images", "imagesGroupOne", "imagesGroupTwo", "allowCustomImage"], [3, "parentForm", "readonlyCPU", "readonlyMemory", "cpuLimitFactor", "memoryLimitFactor"], [3, "parentForm", "vendors"], [3, "readonly", "volGroup", "externalName", 4, "ngIf"], [3, "volsArray", "readonly", "externalName"], [3, "parentForm", "affinityConfigs", "tolerationGroups"], [1, "form-buttons"], ["mat-raised-button", "", "color", "primary", 1, "form--button-margin", 3, "disabled", "click"], i18n_0, ["mat-raised-button", "", "type", "button", 3, "click"], i18n_2, [3, "readonly", "volGroup", "externalName"]]; }, template: function FormRokComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](1, "lib-title-actions-toolbar", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("back", function FormRokComponent_Template_lib_title_actions_toolbar_back_1_listener() { return ctx.onCancel(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](3, "form", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("ngSubmit", function FormRokComponent_Template_form_ngSubmit_3_listener() { return ctx.onSubmit(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](4, "app-rok-jupyter-lab-selector", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](5, "app-form-name-namespace", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](6, "app-form-image", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](7, "app-form-cpu-ram", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](8, "app-form-gpus", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵtemplate"](9, FormRokComponent_app_form_workspace_volume_9_Template, 1, 3, "app-form-workspace-volume", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](10, "app-form-data-volumes", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](11, "app-rok-form-configurations", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](12, "app-form-affinity-tolerations", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelement"](13, "app-form-advanced-options", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](14, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](15, "button", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function FormRokComponent_Template_button_click_15_listener() { return ctx.onSubmit(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵi18n"](16, 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementStart"](17, "button", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵlistener"]("click", function FormRokComponent_Template_button_click_17_listener() { return ctx.onCancel(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵi18n"](18, 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("backButton", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("formGroup", ctx.formCtrl);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("parentForm", ctx.formCtrl);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("parentForm", ctx.formCtrl);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("parentForm", ctx.formCtrl)("images", ctx.config == null ? null : ctx.config.image == null ? null : ctx.config.image.options)("imagesGroupOne", ctx.config == null ? null : ctx.config.imageGroupOne == null ? null : ctx.config.imageGroupOne.options)("imagesGroupTwo", ctx.config == null ? null : ctx.config.imageGroupTwo == null ? null : ctx.config.imageGroupTwo.options)("allowCustomImage", ctx.config == null ? null : ctx.config.allowCustomImage);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("parentForm", ctx.formCtrl)("readonlyCPU", ctx.config == null ? null : ctx.config.cpu == null ? null : ctx.config.cpu.readOnly)("readonlyMemory", ctx.config == null ? null : ctx.config.memory == null ? null : ctx.config.memory.readOnly)("cpuLimitFactor", ctx.config == null ? null : ctx.config.cpu == null ? null : ctx.config.cpu.limitFactor)("memoryLimitFactor", ctx.config == null ? null : ctx.config.memory == null ? null : ctx.config.memory.limitFactor);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("parentForm", ctx.formCtrl)("vendors", ctx.config == null ? null : ctx.config.gpus == null ? null : ctx.config.gpus.value.vendors);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("ngIf", ctx.formCtrl.get("workspace"));
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("volsArray", ctx.formCtrl.get("datavols"))("readonly", ctx.config == null ? null : ctx.config.dataVolumes == null ? null : ctx.config.dataVolumes.readOnly)("externalName", ctx.formCtrl.get("name").value);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("parentForm", ctx.formCtrl);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("parentForm", ctx.formCtrl)("affinityConfigs", ctx.config == null ? null : ctx.config.affinityConfig == null ? null : ctx.config.affinityConfig.options)("tolerationGroups", ctx.config == null ? null : ctx.config.tolerationGroup == null ? null : ctx.config.tolerationGroup.options);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("parentForm", ctx.formCtrl);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵproperty"]("disabled", !ctx.formCtrl.valid || ctx.blockSubmit);
    } }, directives: [kubeflow__WEBPACK_IMPORTED_MODULE_16__.TitleActionsToolbarComponent, _angular_forms__WEBPACK_IMPORTED_MODULE_15__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_15__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_15__.FormGroupDirective, _rok_jupyter_lab_selector_rok_jupyter_lab_selector_component__WEBPACK_IMPORTED_MODULE_4__.RokJupyterLabSelectorComponent, _form_default_form_name_form_name_component__WEBPACK_IMPORTED_MODULE_5__.FormNameComponent, _form_default_form_image_form_image_component__WEBPACK_IMPORTED_MODULE_6__.FormImageComponent, _form_default_form_cpu_ram_form_cpu_ram_component__WEBPACK_IMPORTED_MODULE_7__.FormCpuRamComponent, _form_default_form_gpus_form_gpus_component__WEBPACK_IMPORTED_MODULE_8__.FormGpusComponent, _angular_common__WEBPACK_IMPORTED_MODULE_18__.NgIf, _form_default_form_data_volumes_form_data_volumes_component__WEBPACK_IMPORTED_MODULE_9__.FormDataVolumesComponent, _rok_form_configurations_rok_form_configurations_component__WEBPACK_IMPORTED_MODULE_10__.RokFormConfigurationsComponent, _form_default_form_affinity_tolerations_form_affinity_tolerations_component__WEBPACK_IMPORTED_MODULE_11__.FormAffinityTolerationsComponent, _form_default_form_advanced_options_form_advanced_options_component__WEBPACK_IMPORTED_MODULE_12__.FormAdvancedOptionsComponent, _angular_material_button__WEBPACK_IMPORTED_MODULE_19__.MatButton, _form_default_form_workspace_volume_form_workspace_volume_component__WEBPACK_IMPORTED_MODULE_13__.FormWorkspaceVolumeComponent], styles: [".form[_ngcontent-%COMP%] {\n  margin-top: 1rem;\n  margin-left: 1rem;\n  max-width: 600px;\n}\n\n.form-buttons[_ngcontent-%COMP%] {\n  margin-bottom: 1rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZvcm0tZGVmYXVsdC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtBQUNGOztBQUVBO0VBQ0UsbUJBQUE7QUFDRiIsImZpbGUiOiJmb3JtLWRlZmF1bHQuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZm9ybSB7XG4gIG1hcmdpbi10b3A6IDFyZW07XG4gIG1hcmdpbi1sZWZ0OiAxcmVtO1xuICBtYXgtd2lkdGg6IDYwMHB4O1xufVxuXG4uZm9ybS1idXR0b25zIHtcbiAgbWFyZ2luLWJvdHRvbTogMXJlbTtcbn1cbiJdfQ== */", "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJmb3JtLXJvay5jb21wb25lbnQuc2NzcyJ9 */"] });


/***/ }),

/***/ 5052:
/*!********************************************************!*\
  !*** ./src/app/pages/form/form-rok/form-rok.module.ts ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormRokModule": function() { return /* binding */ FormRokModule; }
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/checkbox */ 7539);
/* harmony import */ var _angular_material_slide_toggle__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/slide-toggle */ 5396);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/icon */ 6627);
/* harmony import */ var kubeflow__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! kubeflow */ 872);
/* harmony import */ var _form_rok_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./form-rok.component */ 5215);
/* harmony import */ var _form_default_form_default_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../form-default/form-default.module */ 5903);
/* harmony import */ var _rok_jupyter_lab_selector_rok_jupyter_lab_selector_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./rok-jupyter-lab-selector/rok-jupyter-lab-selector.component */ 4373);
/* harmony import */ var _rok_form_configurations_rok_form_configurations_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./rok-form-configurations/rok-form-configurations.component */ 936);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);










class FormRokModule {
}
FormRokModule.ɵfac = function FormRokModule_Factory(t) { return new (t || FormRokModule)(); };
FormRokModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineNgModule"]({ type: FormRokModule });
FormRokModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            kubeflow__WEBPACK_IMPORTED_MODULE_6__.FormModule,
            _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_7__.MatCheckboxModule,
            _angular_material_slide_toggle__WEBPACK_IMPORTED_MODULE_8__.MatSlideToggleModule,
            _angular_material_icon__WEBPACK_IMPORTED_MODULE_9__.MatIconModule,
            kubeflow__WEBPACK_IMPORTED_MODULE_6__.TitleActionsToolbarModule,
            _form_default_form_default_module__WEBPACK_IMPORTED_MODULE_1__.FormDefaultModule,
            kubeflow__WEBPACK_IMPORTED_MODULE_6__.TitleActionsToolbarModule,
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsetNgModuleScope"](FormRokModule, { declarations: [_form_rok_component__WEBPACK_IMPORTED_MODULE_0__.FormRokComponent,
        _rok_jupyter_lab_selector_rok_jupyter_lab_selector_component__WEBPACK_IMPORTED_MODULE_2__.RokJupyterLabSelectorComponent,
        _rok_form_configurations_rok_form_configurations_component__WEBPACK_IMPORTED_MODULE_3__.RokFormConfigurationsComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
        kubeflow__WEBPACK_IMPORTED_MODULE_6__.FormModule,
        _angular_material_checkbox__WEBPACK_IMPORTED_MODULE_7__.MatCheckboxModule,
        _angular_material_slide_toggle__WEBPACK_IMPORTED_MODULE_8__.MatSlideToggleModule,
        _angular_material_icon__WEBPACK_IMPORTED_MODULE_9__.MatIconModule,
        kubeflow__WEBPACK_IMPORTED_MODULE_6__.TitleActionsToolbarModule,
        _form_default_form_default_module__WEBPACK_IMPORTED_MODULE_1__.FormDefaultModule,
        kubeflow__WEBPACK_IMPORTED_MODULE_6__.TitleActionsToolbarModule], exports: [_form_rok_component__WEBPACK_IMPORTED_MODULE_0__.FormRokComponent] }); })();


/***/ }),

/***/ 936:
/*!**************************************************************************************************!*\
  !*** ./src/app/pages/form/form-rok/rok-form-configurations/rok-form-configurations.component.ts ***!
  \**************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RokFormConfigurationsComponent": function() { return /* binding */ RokFormConfigurationsComponent; }
/* harmony export */ });
/* harmony import */ var _form_default_form_configurations_form_configurations_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../form-default/form-configurations/form-configurations.component */ 4999);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var kubeflow__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! kubeflow */ 872);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/form-field */ 8295);
/* harmony import */ var _angular_material_select__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/select */ 7441);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/input */ 3166);
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/core */ 7817);









function RokFormConfigurationsComponent_mat_option_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-option", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const config_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("value", config_r1.label);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", config_r1.desc, " ");
} }
class RokFormConfigurationsComponent extends _form_default_form_configurations_form_configurations_component__WEBPACK_IMPORTED_MODULE_0__.FormConfigurationsComponent {
}
RokFormConfigurationsComponent.ɵfac = /*@__PURE__*/ function () { let ɵRokFormConfigurationsComponent_BaseFactory; return function RokFormConfigurationsComponent_Factory(t) { return (ɵRokFormConfigurationsComponent_BaseFactory || (ɵRokFormConfigurationsComponent_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetInheritedFactory"](RokFormConfigurationsComponent)))(t || RokFormConfigurationsComponent); }; }();
RokFormConfigurationsComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: RokFormConfigurationsComponent, selectors: [["app-rok-form-configurations"]], features: [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵInheritDefinitionFeature"]], decls: 12, vars: 3, consts: function () { let i18n_0; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_9147549536677777412$$SRC_APP_PAGES_FORM_FORM_ROK_ROK_FORM_CONFIGURATIONS_ROK_FORM_CONFIGURATIONS_COMPONENT_TS_1 = goog.getMsg("Configurations");
        i18n_0 = MSG_EXTERNAL_9147549536677777412$$SRC_APP_PAGES_FORM_FORM_ROK_ROK_FORM_CONFIGURATIONS_ROK_FORM_CONFIGURATIONS_COMPONENT_TS_1;
    }
    else {
        i18n_0 = $localize `:␟edd04e579025543c017d80558217d1e2788708df␟9147549536677777412:Configurations`;
    } return [["title", i18n_0], ["appearance", "outline", 1, "wide"], ["multiple", "", 3, "formControl"], [3, "value", 4, "ngFor", "ngForOf"], ["matInput", "", "placeholder", "Environment variables in JSON", 3, "formControl"], [3, "value"]]; }, template: function RokFormConfigurationsComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "lib-form-section", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "mat-form-field", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](3, "Configurations");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "mat-select", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](5, RokFormConfigurationsComponent_mat_option_5_Template, 2, 2, "mat-option", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "mat-form-field", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](8, "Environment");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](9, "input", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](10, "mat-error");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](11, "Environment is invalid");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formControl", ctx.parentForm.get("configurations"));
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx.podDefaults);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formControl", ctx.parentForm.get("environment"));
    } }, directives: [kubeflow__WEBPACK_IMPORTED_MODULE_2__.FormSectionComponent, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_3__.MatFormField, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_3__.MatLabel, _angular_material_select__WEBPACK_IMPORTED_MODULE_4__.MatSelect, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControlDirective, _angular_common__WEBPACK_IMPORTED_MODULE_6__.NgForOf, _angular_material_input__WEBPACK_IMPORTED_MODULE_7__.MatInput, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.DefaultValueAccessor, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_3__.MatError, _angular_material_core__WEBPACK_IMPORTED_MODULE_8__.MatOption], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJyb2stZm9ybS1jb25maWd1cmF0aW9ucy5jb21wb25lbnQuc2NzcyJ9 */"] });


/***/ }),

/***/ 4373:
/*!****************************************************************************************************!*\
  !*** ./src/app/pages/form/form-rok/rok-jupyter-lab-selector/rok-jupyter-lab-selector.component.ts ***!
  \****************************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RokJupyterLabSelectorComponent": function() { return /* binding */ RokJupyterLabSelectorComponent; }
/* harmony export */ });
/* harmony import */ var _app_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @app/environment */ 2340);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var kubeflow__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! kubeflow */ 872);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils */ 4933);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);






class RokJupyterLabSelectorComponent {
    constructor(rok, popup) {
        this.rok = rok;
        this.popup = popup;
        this.env = _app_environment__WEBPACK_IMPORTED_MODULE_0__.environment;
        this.ctrl = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControl('', [], [(0,kubeflow__WEBPACK_IMPORTED_MODULE_3__.rokUrlValidator)(this.rok)]);
    }
    ngOnInit() { }
    labAutofillClicked(url) {
        (0,_utils__WEBPACK_IMPORTED_MODULE_1__.getJupyterLabMetaFromRokURL)(url, this.rok).subscribe(lab => {
            (0,_utils__WEBPACK_IMPORTED_MODULE_1__.setLabValues)(lab, this.parentForm);
            const rokOrigin = 'newPvc.metadata.annotations.rok/origin';
            // Autofill the workspace volume
            const workspace = this.parentForm.get('workspace');
            const wsUrl = workspace.get(rokOrigin).value;
            (0,_utils__WEBPACK_IMPORTED_MODULE_1__.getVolumeMetadataFromRokURL)(wsUrl, this.rok).subscribe(metadata => {
                (0,_utils__WEBPACK_IMPORTED_MODULE_1__.updateVolumeFormGroupWithRokMetadata)(metadata, workspace);
            });
            // Autofill the data volumes
            const dataVols = this.parentForm.get('datavols');
            const controls = dataVols.controls;
            for (const volCtrl of controls) {
                const volUrl = volCtrl.get(rokOrigin).value;
                (0,_utils__WEBPACK_IMPORTED_MODULE_1__.getVolumeMetadataFromRokURL)(volUrl, this.rok).subscribe(metadata => {
                    (0,_utils__WEBPACK_IMPORTED_MODULE_1__.updateVolumeFormGroupWithRokMetadata)(metadata, volCtrl);
                });
            }
            this.popup.open('Successfully retrieved details from Rok Jupyter Lab URL', kubeflow__WEBPACK_IMPORTED_MODULE_3__.SnackType.Success, 4000);
        });
    }
}
RokJupyterLabSelectorComponent.ɵfac = function RokJupyterLabSelectorComponent_Factory(t) { return new (t || RokJupyterLabSelectorComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](kubeflow__WEBPACK_IMPORTED_MODULE_3__.RokService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](kubeflow__WEBPACK_IMPORTED_MODULE_3__.SnackBarService)); };
RokJupyterLabSelectorComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({ type: RokJupyterLabSelectorComponent, selectors: [["app-rok-jupyter-lab-selector"]], inputs: { parentForm: "parentForm" }, decls: 2, vars: 1, consts: function () { let i18n_0; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_4883073038054832372$$SRC_APP_PAGES_FORM_FORM_ROK_ROK_JUPYTER_LAB_SELECTOR_ROK_JUPYTER_LAB_SELECTOR_COMPONENT_TS_1 = goog.getMsg("Rok JupyterLab URL");
        i18n_0 = MSG_EXTERNAL_4883073038054832372$$SRC_APP_PAGES_FORM_FORM_ROK_ROK_JUPYTER_LAB_SELECTOR_ROK_JUPYTER_LAB_SELECTOR_COMPONENT_TS_1;
    }
    else {
        i18n_0 = $localize `:␟74af76db6695215fb9d397e21e09c6d7b6b8ba27␟4883073038054832372:Rok JupyterLab URL`;
    } let i18n_2; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_4574989754672869232$$SRC_APP_PAGES_FORM_FORM_ROK_ROK_JUPYTER_LAB_SELECTOR_ROK_JUPYTER_LAB_SELECTOR_COMPONENT_TS_3 = goog.getMsg("\n    Create a new Notebook from a snapshot URL.");
        i18n_2 = MSG_EXTERNAL_4574989754672869232$$SRC_APP_PAGES_FORM_FORM_ROK_ROK_JUPYTER_LAB_SELECTOR_ROK_JUPYTER_LAB_SELECTOR_COMPONENT_TS_3;
    }
    else {
        i18n_2 = $localize `:␟4374b7f944d0abc5a1534b04c40ddad5bcb93378␟4574989754672869232:
    Create a new Notebook from a snapshot URL.`;
    } return [["title", i18n_0, "text", i18n_2], [3, "control", "urlEntered"]]; }, template: function RokJupyterLabSelectorComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "lib-form-section", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "lib-rok-url-input", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("urlEntered", function RokJupyterLabSelectorComponent_Template_lib_rok_url_input_urlEntered_1_listener($event) { return ctx.labAutofillClicked($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("control", ctx.ctrl);
    } }, directives: [kubeflow__WEBPACK_IMPORTED_MODULE_3__.FormSectionComponent, kubeflow__WEBPACK_IMPORTED_MODULE_3__.RokUrlInputComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJyb2stanVweXRlci1sYWItc2VsZWN0b3IuY29tcG9uZW50LnNjc3MifQ== */"] });


/***/ }),

/***/ 4933:
/*!**********************************************!*\
  !*** ./src/app/pages/form/form-rok/utils.ts ***!
  \**********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getJupyterLabMetaFromRokURL": function() { return /* binding */ getJupyterLabMetaFromRokURL; },
/* harmony export */   "getVolumeMetadataFromRokURL": function() { return /* binding */ getVolumeMetadataFromRokURL; },
/* harmony export */   "setLabValues": function() { return /* binding */ setLabValues; },
/* harmony export */   "updateVolumeFormGroupWithRokUrl": function() { return /* binding */ updateVolumeFormGroupWithRokUrl; },
/* harmony export */   "updateVolumeFormGroupWithRokMetadata": function() { return /* binding */ updateVolumeFormGroupWithRokMetadata; }
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ 8002);
/* harmony import */ var src_app_shared_utils_volumes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/shared/utils/volumes */ 562);



// Functions to create Autofilled Rok Objects
function getJupyterLabMetaFromRokURL(url, rok) {
    return rok.getObjectMetadata(url).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.map)((headers) => {
        const notebook = {};
        // Fill the notebook with the info from the response
        notebook.namespace = headers.get('X-Object-Meta-namespace');
        notebook.image = headers.get('X-Object-Meta-image');
        // Convert CPU to number
        notebook.cpu = headers.get('X-Object-Meta-cpu');
        if (typeof notebook.cpu === 'number') {
        }
        else if (notebook.cpu.includes('m')) {
            const cpu = parseInt(notebook.cpu.replace('m', ''), 10);
            notebook.cpu = cpu / 1000;
        }
        // Convert memory to Gi
        const memory = headers.get('X-Object-Meta-memory');
        if (memory.includes('G')) {
            notebook.memory = parseInt(memory.replace('G', ''), 10);
        }
        else if (memory.includes('M')) {
            notebook.memory = parseInt(memory.replace('M', ''), 10) / 1000;
        }
        else {
            notebook.memory = parseInt(memory, 10);
        }
        notebook.environment = headers.get('X-Object-Meta-environment');
        // Workspace Volume
        const workspaceRokUrl = headers.get('X-Object-Group-Member-0-URL');
        if (workspaceRokUrl) {
            notebook.workspaceUrl = workspaceRokUrl;
        }
        // Data Volumes
        const volsNum = headers.get('X-Object-Group-Member-Count');
        if (!volsNum) {
            return notebook;
        }
        notebook.datavolsUrls = [];
        for (let i = 1; i < parseInt(volsNum, 10); i++) {
            const volRokUrl = headers.get('X-Object-Group-Member-' + i + '-URL');
            notebook.datavolsUrls.push(volRokUrl);
        }
        return notebook;
    }));
}
function getVolumeMetadataFromRokURL(url, rok) {
    return rok.getObjectMetadata(url).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.map)((headers) => {
        console.log(`Creating volume object from fetched metadata`);
        const volume = {};
        // Fill the notebook with the info from the response
        volume.name =
            headers.get('X-Object-Meta-workspace') ||
                headers.get('X-Object-Meta-dataset') ||
                headers.get('x-object-meta-pvc');
        volume.name = `${volume.name}-`;
        const size = parseInt(headers.get('Content-Length'), 10);
        volume.size = `${size / Math.pow(1024, 3)}Gi`;
        volume.path = headers.get('X-Object-Meta-mountpoint');
        return volume;
    }));
}
// Functions for autofilling control values
function setLabValues(lab, formCtrl) {
    console.log(`Setting Jupyter Lab form values based on object: ${JSON.stringify(lab)}`);
    formCtrl.get('customImage').setValue(lab.image);
    formCtrl.get('customImageCheck').setValue(true);
    formCtrl.get('customImage').markAsDirty();
    formCtrl.get('cpu').setValue(lab.cpu, { emitEvent: false });
    formCtrl.get('cpuLimit').setValue(null);
    formCtrl.get('cpu').markAsDirty();
    formCtrl.get('memory').setValue(lab.memory, { emitEvent: false });
    formCtrl.get('memoryLimit').setValue(null);
    formCtrl.get('memory').markAsDirty();
    // Change env only if it exists
    if (lab.environment !== null) {
        formCtrl.get('environment').setValue(lab.environment);
        formCtrl.get('environment').markAsDirty();
    }
    // Clear the existing Data Volumes array
    const dataVols = formCtrl.get('datavols');
    dataVols.clear();
    for (const url of lab.datavolsUrls) {
        const volGroup = (0,src_app_shared_utils_volumes__WEBPACK_IMPORTED_MODULE_0__.createNewPvcVolumeFormGroup)();
        updateVolumeFormGroupWithRokUrl(lab.workspaceUrl, volGroup);
    }
    // update the workspace volume
    const workspace = (0,src_app_shared_utils_volumes__WEBPACK_IMPORTED_MODULE_0__.createNewPvcVolumeFormGroup)();
    formCtrl.removeControl('workspace');
    formCtrl.addControl('workspace', workspace);
    updateVolumeFormGroupWithRokUrl(lab.workspaceUrl, workspace);
    // update data volumes
    const dataVolsArray = formCtrl.get('datavols');
    dataVolsArray.clear();
    for (const url of lab.datavolsUrls) {
        const volGroup = (0,src_app_shared_utils_volumes__WEBPACK_IMPORTED_MODULE_0__.createNewPvcVolumeFormGroup)();
        updateVolumeFormGroupWithRokUrl(url, volGroup);
        dataVolsArray.push(volGroup);
    }
}
function updateVolumeFormGroupWithRokUrl(url, volume) {
    // If Volume was existing source then it will need to change to New PVC
    if (volume.get('existingSource')) {
        volume.removeControl('existingSource');
        volume.addControl('newPvc', (0,src_app_shared_utils_volumes__WEBPACK_IMPORTED_MODULE_0__.createNewPvcFormGroup)());
    }
    // ensure the PVC's metadata has annotations
    const metadataGroup = volume.get('newPvc.metadata');
    if (!metadataGroup.get('annotations')) {
        metadataGroup.addControl('annotations', new _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormGroup({}));
    }
    // add rok/origin with Snapshot URL
    const annotationsGroup = metadataGroup.get('annotations');
    annotationsGroup.addControl('rok/origin', new _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormControl(url, [_angular_forms__WEBPACK_IMPORTED_MODULE_2__.Validators.required]));
}
function updateVolumeFormGroupWithRokMetadata(metadata, volume) {
    volume.get('mount').setValue(metadata.path);
    // set the size
    volume.get('newPvc.spec.resources.requests.storage').setValue(metadata.size);
    // ensure the new PVC has generateName set, and not name
    const meta = volume.get('newPvc.metadata');
    (0,src_app_shared_utils_volumes__WEBPACK_IMPORTED_MODULE_0__.setGenerateNameCtrl)(meta, metadata.name);
    meta.get('generateName').markAsDirty();
    volume.get('newPvc.spec.storageClassName').enable();
    volume.get('newPvc.spec.storageClassName').setValue('rok');
}


/***/ }),

/***/ 5804:
/*!**********************************************!*\
  !*** ./src/app/pages/form/form.component.ts ***!
  \**********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormComponent": function() { return /* binding */ FormComponent; }
/* harmony export */ });
/* harmony import */ var _app_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @app/environment */ 2340);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _form_default_form_default_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./form-default/form-default.component */ 849);
/* harmony import */ var _form_rok_form_rok_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./form-rok/form-rok.component */ 5215);





function FormComponent_app_form_default_0_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "app-form-default");
} }
function FormComponent_app_form_rok_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "app-form-rok");
} }
class FormComponent {
    constructor() {
        this.env = _app_environment__WEBPACK_IMPORTED_MODULE_0__.environment;
    }
    ngOnInit() { }
}
FormComponent.ɵfac = function FormComponent_Factory(t) { return new (t || FormComponent)(); };
FormComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({ type: FormComponent, selectors: [["app-form"]], decls: 2, vars: 2, consts: [[4, "ngIf"]], template: function FormComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](0, FormComponent_app_form_default_0_Template, 1, 0, "app-form-default", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, FormComponent_app_form_rok_1_Template, 1, 0, "app-form-rok", 0);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.env.ui === "default");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.env.ui === "rok");
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.NgIf, _form_default_form_default_component__WEBPACK_IMPORTED_MODULE_1__.FormDefaultComponent, _form_rok_form_rok_component__WEBPACK_IMPORTED_MODULE_2__.FormRokComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJmb3JtLmNvbXBvbmVudC5zY3NzIn0= */"] });


/***/ }),

/***/ 9552:
/*!*******************************************!*\
  !*** ./src/app/pages/form/form.module.ts ***!
  \*******************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormModule": function() { return /* binding */ FormModule; }
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/core */ 7817);
/* harmony import */ var _form_default_form_default_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./form-default/form-default.module */ 5903);
/* harmony import */ var _form_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./form.component */ 5804);
/* harmony import */ var kubeflow__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! kubeflow */ 872);
/* harmony import */ var _form_rok_form_rok_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./form-rok/form-rok.module */ 5052);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);







class FormModule {
}
FormModule.ɵfac = function FormModule_Factory(t) { return new (t || FormModule)(); };
FormModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({ type: FormModule });
FormModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({ providers: [
        { provide: _angular_material_core__WEBPACK_IMPORTED_MODULE_4__.ErrorStateMatcher, useClass: kubeflow__WEBPACK_IMPORTED_MODULE_5__.ImmediateErrorStateMatcher },
    ], imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule, _form_default_form_default_module__WEBPACK_IMPORTED_MODULE_0__.FormDefaultModule, _form_rok_form_rok_module__WEBPACK_IMPORTED_MODULE_2__.FormRokModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](FormModule, { declarations: [_form_component__WEBPACK_IMPORTED_MODULE_1__.FormComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule, _form_default_form_default_module__WEBPACK_IMPORTED_MODULE_0__.FormDefaultModule, _form_rok_form_rok_module__WEBPACK_IMPORTED_MODULE_2__.FormRokModule] }); })();


/***/ }),

/***/ 4295:
/*!*****************************************************!*\
  !*** ./src/app/pages/index/index-default/config.ts ***!
  \*****************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getDeleteDialogConfig": function() { return /* binding */ getDeleteDialogConfig; },
/* harmony export */   "getStopDialogConfig": function() { return /* binding */ getStopDialogConfig; },
/* harmony export */   "defaultConfig": function() { return /* binding */ defaultConfig; }
/* harmony export */ });
/* harmony import */ var kubeflow__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! kubeflow */ 872);
/* harmony import */ var _server_type_server_type_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./server-type/server-type.component */ 1610);


// --- Configs for the Confirm Dialogs ---
function getDeleteDialogConfig(name) {
    return {
        title: $localize `Are you sure you want to delete this notebook server? ${name}`,
        message: $localize `Warning: Your data might be lost if the notebook server
                       is not backed by persistent storage`,
        accept: $localize `DELETE`,
        confirmColor: 'warn',
        cancel: $localize `CANCEL`,
        error: '',
        applying: $localize `DELETING`,
        width: '600px',
    };
}
function getStopDialogConfig(name) {
    return {
        title: $localize `Are you sure you want to stop this notebook server? ${name}`,
        message: $localize `Warning: Your data might be lost if the notebook server
                       is not backed by persistent storage.`,
        accept: $localize `STOP`,
        confirmColor: 'primary',
        cancel: $localize `CANCEL`,
        error: '',
        applying: $localize `STOPPING`,
        width: '600px',
    };
}
// --- Config for the Resource Table ---
const defaultConfig = {
    columns: [
        {
            matHeaderCellDef: $localize `Status`,
            matColumnDef: 'status',
            value: new kubeflow__WEBPACK_IMPORTED_MODULE_1__.StatusValue(),
        },
        {
            matHeaderCellDef: $localize `Name`,
            matColumnDef: 'name',
            style: { width: '25%' },
            value: new kubeflow__WEBPACK_IMPORTED_MODULE_1__.PropertyValue({
                field: 'name',
                tooltipField: 'name',
                truncate: true,
            }),
        },
        {
            matHeaderCellDef: $localize `Type`,
            matColumnDef: 'type',
            value: new kubeflow__WEBPACK_IMPORTED_MODULE_1__.ComponentValue({
                component: _server_type_server_type_component__WEBPACK_IMPORTED_MODULE_0__.ServerTypeComponent,
            }),
        },
        {
            matHeaderCellDef: $localize `Age`,
            matColumnDef: 'age',
            style: { width: '12%' },
            textAlignment: 'right',
            value: new kubeflow__WEBPACK_IMPORTED_MODULE_1__.PropertyValue({ field: 'age', truncate: true }),
        },
        {
            matHeaderCellDef: $localize `Last activity`,
            matColumnDef: 'last_activity',
            value: new kubeflow__WEBPACK_IMPORTED_MODULE_1__.DateTimeValue({ field: 'last_activity' }),
        },
        {
            matHeaderCellDef: $localize `Image`,
            matColumnDef: 'image',
            style: { width: '30%' },
            value: new kubeflow__WEBPACK_IMPORTED_MODULE_1__.PropertyValue({
                field: 'shortImage',
                popoverField: 'image',
                truncate: true,
                style: { maxWidth: '300px' },
            }),
        },
        {
            matHeaderCellDef: $localize `GPUs`,
            matColumnDef: 'gpus',
            style: { width: '8%' },
            textAlignment: 'right',
            value: new kubeflow__WEBPACK_IMPORTED_MODULE_1__.PropertyValue({
                field: 'gpus.count',
                tooltipField: 'gpus.message',
            }),
        },
        {
            matHeaderCellDef: $localize `CPUs`,
            matColumnDef: 'cpu',
            style: { width: '8%' },
            textAlignment: 'right',
            value: new kubeflow__WEBPACK_IMPORTED_MODULE_1__.PropertyValue({ field: 'cpu' }),
        },
        {
            matHeaderCellDef: $localize `Memory`,
            matColumnDef: 'memory',
            style: { width: '8%' },
            textAlignment: 'right',
            value: new kubeflow__WEBPACK_IMPORTED_MODULE_1__.PropertyValue({ field: 'memory' }),
        },
        {
            matHeaderCellDef: $localize `Volumes`,
            matColumnDef: 'volumes',
            value: new kubeflow__WEBPACK_IMPORTED_MODULE_1__.MenuValue({ field: 'volumes', itemsIcon: 'storage' }),
        },
        {
            matHeaderCellDef: '',
            matColumnDef: 'actions',
            value: new kubeflow__WEBPACK_IMPORTED_MODULE_1__.ActionListValue([
                new kubeflow__WEBPACK_IMPORTED_MODULE_1__.ActionButtonValue({
                    name: 'connect',
                    tooltip: $localize `Connect to this notebook server`,
                    color: 'primary',
                    field: 'connectAction',
                    text: $localize `CONNECT`,
                }),
                // 2023/08/29 YCL sharing start //
                new kubeflow__WEBPACK_IMPORTED_MODULE_1__.ActionIconValue({
                    name: 'view',
                    tooltip: $localize `Share this notebook`,
                    color: '',
                    field: 'deleteAction',
                    iconReady: 'material:screen_share',
                }),
                // 2023/08/29 YCL sharing end //
                new kubeflow__WEBPACK_IMPORTED_MODULE_1__.ActionIconValue({
                    name: 'start-stop',
                    tooltipInit: $localize `Stop this notebook server`,
                    tooltipReady: $localize `Start this notebook server`,
                    color: '',
                    field: 'startStopAction',
                    iconInit: 'material:stop',
                    iconReady: 'material:play_arrow',
                }),
                new kubeflow__WEBPACK_IMPORTED_MODULE_1__.ActionIconValue({
                    name: 'delete',
                    tooltip: $localize `Delete this notebook server`,
                    color: '',
                    field: 'deleteAction',
                    iconReady: 'material:delete',
                }),
            ]),
        },
    ],
};


/***/ }),

/***/ 7622:
/*!**************************************************************************************!*\
  !*** ./src/app/pages/index/index-default/dialog-sharing/dialog-sharing.component.ts ***!
  \**************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DialogSharing": function() { return /* binding */ DialogSharing; }
/* harmony export */ });
/* harmony import */ var _angular_cdk_keycodes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/cdk/keycodes */ 6461);
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/dialog */ 2238);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var src_app_services_backend_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/services/backend.service */ 600);
/* harmony import */ var _angular_material_divider__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/divider */ 1769);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/form-field */ 8295);
/* harmony import */ var _angular_material_chips__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/chips */ 8341);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_material_select__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/select */ 7441);
/* harmony import */ var _angular_material_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/core */ 7817);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/material/button */ 1095);
/* harmony import */ var _angular_cdk_clipboard__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/cdk/clipboard */ 4785);
/* harmony import */ var _angular_material_expansion__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/material/expansion */ 2976);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/material/icon */ 6627);
















function DialogSharing_mat_chip_12_mat_icon_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-icon", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1, "cancel");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} }
function DialogSharing_mat_chip_12_Template(rf, ctx) { if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-chip", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("removed", function DialogSharing_mat_chip_12_Template_mat_chip_removed_0_listener() { const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r11); const useremail_r8 = restoredCtx.$implicit; const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return ctx_r10.remove(useremail_r8); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](2, DialogSharing_mat_chip_12_mat_icon_2_Template, 2, 0, "mat-icon", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const useremail_r8 = ctx.$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("selectable", ctx_r1.selectable)("removable", ctx_r1.removable);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", useremail_r8.name, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx_r1.removable);
} }
function DialogSharing_ng_container_38_mat_chip_6_mat_icon_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-icon", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1, "cancel");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} }
function DialogSharing_ng_container_38_mat_chip_6_Template(rf, ctx) { if (rf & 1) {
    const _r17 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-chip", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("removed", function DialogSharing_ng_container_38_mat_chip_6_Template_mat_chip_removed_0_listener() { const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r17); const viewlist_r14 = restoredCtx.$implicit; const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2); return ctx_r16.remove1(viewlist_r14); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](2, DialogSharing_ng_container_38_mat_chip_6_mat_icon_2_Template, 2, 0, "mat-icon", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const viewlist_r14 = ctx.$implicit;
    const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("selectable", ctx_r13.selectable)("removable", ctx_r13.removable);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", viewlist_r14, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx_r13.removable);
} }
function DialogSharing_ng_container_38_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "mat-form-field", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "mat-label", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](3, "\u50C5\u6AA2\u8996(View Only)");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "mat-chip-list", null, 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](6, DialogSharing_ng_container_38_mat_chip_6_Template, 3, 4, "mat-chip", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](7, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx_r2.viewlist);
} }
function DialogSharing_ng_template_39_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "p", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1, "\u50C5\u6AA2\u8996(View Only)\u76EE\u524D\u672A\u6709\u4EFB\u4F55\u5206\u4EAB");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} }
function DialogSharing_ng_container_42_mat_chip_6_mat_icon_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-icon", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1, "cancel");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} }
function DialogSharing_ng_container_42_mat_chip_6_Template(rf, ctx) { if (rf & 1) {
    const _r23 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "mat-chip", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("removed", function DialogSharing_ng_container_42_mat_chip_6_Template_mat_chip_removed_0_listener() { const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r23); const editlist_r20 = restoredCtx.$implicit; const ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2); return ctx_r22.remove2(editlist_r20); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](2, DialogSharing_ng_container_42_mat_chip_6_mat_icon_2_Template, 2, 0, "mat-icon", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const editlist_r20 = ctx.$implicit;
    const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("selectable", ctx_r19.selectable)("removable", ctx_r19.removable);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", editlist_r20, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx_r19.removable);
} }
function DialogSharing_ng_container_42_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "mat-form-field", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "mat-label", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](3, "\u53EF\u4FEE\u6539(Editable)");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "mat-chip-list", null, 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](6, DialogSharing_ng_container_42_mat_chip_6_Template, 3, 4, "mat-chip", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx_r5.editlist);
} }
function DialogSharing_ng_template_43_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "p", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1, "\u53EF\u4FEE\u6539(Editable)\u76EE\u524D\u672A\u6709\u4EFB\u4F55\u5206\u4EAB");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} }
class DialogSharing {
    constructor(backend, dialogRef, data) {
        this.backend = backend;
        this.dialogRef = dialogRef;
        this.data = data;
        this.selected1 = 'option1';
        this.visible = true;
        this.selectable = true;
        this.removable = true;
        this.addOnBlur = true;
        this.separatorKeysCodes = [_angular_cdk_keycodes__WEBPACK_IMPORTED_MODULE_2__.ENTER, _angular_cdk_keycodes__WEBPACK_IMPORTED_MODULE_2__.COMMA];
        this.fruitCtrl = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl();
        //viewlist = ['yuch917@gmail.com','illops19@gmail.com']
        //editlist = ['yuch917@gmail.com','illops19@gmail.com']
        this.viewlist = [];
        this.editlist = [];
        // Chips of email start //
        this.useremail = [];
        //2024/01/20 可添加多個email功能完成 start//
        this.useremailNames = [];
        // CopyLink 選項 串連notebook的name和namespace  end //
        // Expansion panel start // 
        this.panelOpenState = false;
        this.namespace = data.namespace;
        this.notebook = data.name;
    }
    // 2024/01/21 分享清單內容 start//
    ngOnInit() {
        this.backend.getAllAuthorizationPolicy(this.namespace).subscribe(aps => {
            console.log(this.namespace);
            var deletename = "notebook-" + this.notebook + "-authorizationpolicy-view";
            var names = aps.reduce((acc, ap) => {
                if (ap.metadata.name.includes(deletename) && ap.spec && ap.spec.rules) {
                    ap.spec.rules.forEach(rule => {
                        if (rule.when && rule.when[0] && rule.when[0].values) {
                            acc.push(...rule.when[0].values);
                        }
                    });
                }
                return acc;
            }, []);
            console.log('View List:', names);
            this.viewlist = names;
        });
        this.backend.getAllAuthorizationPolicy(this.namespace).subscribe(aps => {
            var deletename = "notebook-" + this.notebook + "-authorizationpolicy-editable";
            var names = aps.reduce((acc, ap) => {
                if (ap.metadata.name.includes(deletename) && ap.spec && ap.spec.rules) {
                    ap.spec.rules.forEach(rule => {
                        if (rule.when && rule.when[0] && rule.when[0].values) {
                            acc.push(...rule.when[0].values);
                        }
                    });
                }
                return acc;
            }, []);
            console.log('edit List:', names);
            this.editlist = names;
        });
    }
    add(event) {
        const input = event.input;
        const value = event.value;
        // Add email
        if ((value || '').trim()) {
            this.useremail.push({ name: value.trim() });
        }
        // Reset the input value
        if (input) {
            input.value = '';
        }
    }
    // Remove value
    remove(useremail) {
        const index = this.useremail.indexOf(useremail);
        if (index >= 0) {
            this.useremail.splice(index, 1);
        }
    }
    // Chips email end //
    cancel() {
        this.dialogRef.close();
    }
    onSubmit() {
        this.useremailNames = this.useremail.map(email => email.name);
        if (this.useremailNames.length === 0 || !this.selected) {
            window.alert('請填寫email或存取權');
            console.log('請添加至少一個 Email 或選擇存取權限。');
        }
        else {
            // 至少有一個不為空，執行相應的邏輯
            this.dialogRef.close({ useremail: this.useremailNames, selected: this.selected });
        }
    }
    //2024/01/20 可添加多個email功能完成 end//
    // CopyLink 選項 串連notebook的name和namespace start//
    updateCopyLink() {
        console.log('updateCopyLink:', this.selected);
        if (this.selected == 'option1') {
            this.copylink = `http://120.126.23.231/notebook/${this.namespace}/${this.notebook}/view/`;
        }
        else if (this.selected == 'option2') {
            this.copylink = `http://120.126.23.231/notebook/${this.namespace}/${this.notebook}/`;
        }
        else {
            this.copylink = `http://120.126.23.231/notebook/${this.namespace}/${this.notebook}/`;
        }
        console.log('copylink:', this.copylink);
    }
    // Expansion panel end //
    // 2024/01/16 Expansion panel for view start //
    remove1(viewlist) {
        const index1 = this.viewlist.indexOf(viewlist);
        if (index1 >= 0) {
            this.viewlist.splice(index1, 1);
            console.log("########");
            console.log([viewlist]);
            const address = `notebook-${this.notebook}-authorizationpolicy-view`;
            this.backend.modify_authorizaiton_delete(this.namespace, address, [viewlist])
                .subscribe(response => {
                console.log("########");
                console.log([viewlist]);
                console.log("Authorization modified successfully:", response);
            }, error => {
                console.error("Error modifying authorization:", error);
            });
        }
    }
    // 2024/01/16 Expansion panel for view end //
    // 2024/01/16 Expansion panel for edit start //
    remove2(editlist) {
        const index2 = this.editlist.indexOf(editlist);
        if (index2 >= 0) {
            this.editlist.splice(index2, 1);
            console.log("########");
            console.log([editlist]);
            const address = `notebook-${this.notebook}-authorizationpolicy-editable`;
            this.backend.modify_authorizaiton_delete(this.namespace, address, [editlist])
                .subscribe(response => {
                console.log("########");
                console.log([editlist]);
                console.log("Authorization modified successfully:", response);
            }, error => {
                console.error("Error modifying authorization:", error);
            });
        }
    }
    // 2024/01/16 Expansion panel for edit end //
    // 2024/01/20 取消所有分享function start //
    delete() {
        //Close the open dialog only if the DELETE request succeeded
        const delete_name = `notebook-${this.notebook}-authorizationpolicy-editable`;
        console.log('Request URL:', `/api/namespaces/${this.namespace}/aps_vnc/${delete_name}`);
        if (delete_name) {
            this.backend.deleteauthorization(delete_name, this.namespace).subscribe({
                next: response => {
                    console.log(`notebook-${this.notebook}-authorizationpolicy-editable`);
                    console.log('success');
                },
                error: error => {
                    console.log(`notebook-${this.notebook}-authorizationpolicy-editable`);
                    console.log('error');
                }
            });
        }
        ;
        const delete_name2 = `notebook-${this.notebook}-authorizationpolicy-view`;
        if (delete_name2) {
            this.backend.deleteauthorization(delete_name2, this.namespace).subscribe({
                next: response => {
                    console.log(`notebook-${this.notebook}-authorizationpolicy-view`);
                    console.log('success');
                },
                error: error => {
                    console.log(`notebook-${this.notebook}-authorizationpolicy-view`);
                    console.log('error');
                }
            });
        }
        ;
    }
}
DialogSharing.ɵfac = function DialogSharing_Factory(t) { return new (t || DialogSharing)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_app_services_backend_service__WEBPACK_IMPORTED_MODULE_0__.JWABackendService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_material_dialog__WEBPACK_IMPORTED_MODULE_4__.MatDialogRef), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_material_dialog__WEBPACK_IMPORTED_MODULE_4__.MAT_DIALOG_DATA)); };
DialogSharing.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: DialogSharing, selectors: [["app-dialog-sharing"]], decls: 45, vars: 11, consts: [["lang", "en"], ["charset", "UTF-8"], ["name", "viewport", "content", "width=device-width, initial-scale=1.0"], ["mat-dialog-title", "", 2, "text-align", "center"], [2, "color", "#0b5299"], [1, "example-chip-list", 2, "width", "530px"], ["chipList", ""], [3, "selectable", "removable", "removed", 4, "ngFor", "ngForOf"], ["matInput", "", "placeholder", "\u8ACB\u8F38\u5165Email", 3, "matChipInputFor", "matChipInputSeparatorKeyCodes", "matChipInputAddOnBlur", "matChipInputTokenEnd"], [2, "color", "#0b5299", "margin-top", "3%"], [2, "width", "530px"], [3, "value", "valueChange", "selectionChange"], ["value", "option1"], ["value", "option2"], ["mat-dialog-actions", "", "align", "center", 2, "margin-top", "3%", "margin-bottom", "4%"], ["mat-raised-button", "", "color", "warn", 3, "cdkCopyToClipboard"], ["mat-raised-button", "", "color", "primary", 2, "margin-left", "10%", 3, "click"], [3, "opened", "closed"], [1, "view-chip-list-container"], [4, "ngIf", "ngIfElse"], ["viewOnlyNoData", ""], ["noData", ""], [3, "selectable", "removable", "removed"], ["matChipRemove", "", 4, "ngIf"], ["matChipRemove", ""], [1, "view-chip-list", 2, "width", "470px"], [2, "font-size", "16px"], [2, "margin-top", "10px", "text-align", "center", "font-size", "14px"], [1, "edit-chip-list", 2, "width", "470px"]], template: function DialogSharing_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "html", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "head");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](2, "meta", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](3, "meta", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "h2", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](6, "mat-divider");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "p", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](8, "1. \u65B0\u589E\u4F7F\u7528\u8005:");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](9, "mat-form-field", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](10, "mat-chip-list", null, 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](12, DialogSharing_mat_chip_12_Template, 3, 4, "mat-chip", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](13, "input", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("matChipInputTokenEnd", function DialogSharing_Template_input_matChipInputTokenEnd_13_listener($event) { return ctx.add($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](14, "p", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](15, "2. \u9078\u64C7\u5B58\u53D6\u6B0A:");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](16, "mat-form-field", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](17, "mat-label");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](18, "\u5B58\u53D6\u6B0A :");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](19, "mat-select", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("valueChange", function DialogSharing_Template_mat_select_valueChange_19_listener($event) { return ctx.selected = $event; })("selectionChange", function DialogSharing_Template_mat_select_selectionChange_19_listener() { return ctx.updateCopyLink(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](20, "mat-option", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](21, "\u50C5\u6AA2\u8996 (View Only)");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](22, "mat-option", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](23, "\u53EF\u4FEE\u6539 (Editable)");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](24, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](25, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](26, "button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](27, " Copy Link ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](28, "button", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function DialogSharing_Template_button_click_28_listener() { return ctx.onSubmit(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](29, "\u52A0\u5165 ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](30, "button", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function DialogSharing_Template_button_click_30_listener() { return ctx.cancel(); })("click", function DialogSharing_Template_button_click_30_listener() { return ctx.delete(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](31, "\u53D6\u6D88\u6240\u6709\u5206\u4EAB ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](32, "mat-accordion");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](33, "mat-expansion-panel", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("opened", function DialogSharing_Template_mat_expansion_panel_opened_33_listener() { return ctx.panelOpenState = true; })("closed", function DialogSharing_Template_mat_expansion_panel_closed_33_listener() { return ctx.panelOpenState = false; });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](34, "mat-expansion-panel-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](35, "mat-panel-title", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](36, " \u67E5\u770B\u73FE\u6709\u5206\u4EAB\u6E05\u55AE ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](37, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](38, DialogSharing_ng_container_38_Template, 8, 1, "ng-container", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](39, DialogSharing_ng_template_39_Template, 2, 0, "ng-template", null, 20, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](41, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](42, DialogSharing_ng_container_42_Template, 7, 1, "ng-container", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](43, DialogSharing_ng_template_43_Template, 2, 0, "ng-template", null, 21, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } if (rf & 2) {
        const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵreference"](11);
        const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵreference"](40);
        const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵreference"](44);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" \u5206\u4EAB Notebook : ", ctx.notebook, "\n");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx.useremail);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("matChipInputFor", _r0)("matChipInputSeparatorKeyCodes", ctx.separatorKeysCodes)("matChipInputAddOnBlur", ctx.addOnBlur);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("value", ctx.selected);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("cdkCopyToClipboard", ctx.copylink);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.viewlist && ctx.viewlist.length > 0)("ngIfElse", _r3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.editlist && ctx.editlist.length > 0)("ngIfElse", _r6);
    } }, directives: [_angular_material_divider__WEBPACK_IMPORTED_MODULE_5__.MatDivider, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_6__.MatFormField, _angular_material_chips__WEBPACK_IMPORTED_MODULE_7__.MatChipList, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgForOf, _angular_material_chips__WEBPACK_IMPORTED_MODULE_7__.MatChipInput, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_6__.MatLabel, _angular_material_select__WEBPACK_IMPORTED_MODULE_9__.MatSelect, _angular_material_core__WEBPACK_IMPORTED_MODULE_10__.MatOption, _angular_material_button__WEBPACK_IMPORTED_MODULE_11__.MatButton, _angular_cdk_clipboard__WEBPACK_IMPORTED_MODULE_12__.CdkCopyToClipboard, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_13__.MatAccordion, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_13__.MatExpansionPanel, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_13__.MatExpansionPanelHeader, _angular_material_expansion__WEBPACK_IMPORTED_MODULE_13__.MatExpansionPanelTitle, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgIf, _angular_material_chips__WEBPACK_IMPORTED_MODULE_7__.MatChip, _angular_material_icon__WEBPACK_IMPORTED_MODULE_14__.MatIcon, _angular_material_chips__WEBPACK_IMPORTED_MODULE_7__.MatChipRemove], styles: [".view-chip-list-container[_ngcontent-%COMP%] {\n  overflow-y: auto;\n  border: 1px solid #ccc;\n  padding: 10px;\n  border-radius: 5px;\n}"], changeDetection: 0 });


/***/ }),

/***/ 5867:
/*!***********************************************************************************!*\
  !*** ./src/app/pages/index/index-default/dialog-sharing/dialog-sharing.module.ts ***!
  \***********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DialogSharingModule": function() { return /* binding */ DialogSharingModule; }
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/icon */ 6627);
/* harmony import */ var _angular_material_chips__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/chips */ 8341);
/* harmony import */ var _dialog_sharing_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dialog-sharing.component */ 7622);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/form-field */ 8295);
/* harmony import */ var _angular_material_select__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/select */ 7441);
/* harmony import */ var _angular_material_button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/button */ 1095);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _angular_material_divider__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/material/divider */ 1769);
/* harmony import */ var _angular_cdk_clipboard__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/cdk/clipboard */ 4785);
/* harmony import */ var _angular_material_expansion__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/material/expansion */ 2976);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7716);












class DialogSharingModule {
}
DialogSharingModule.ɵfac = function DialogSharingModule_Factory(t) { return new (t || DialogSharingModule)(); };
DialogSharingModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({ type: DialogSharingModule });
DialogSharingModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule,
            _angular_material_icon__WEBPACK_IMPORTED_MODULE_3__.MatIconModule,
            _angular_material_chips__WEBPACK_IMPORTED_MODULE_4__.MatChipsModule,
            _angular_material_form_field__WEBPACK_IMPORTED_MODULE_5__.MatFormFieldModule,
            _angular_material_select__WEBPACK_IMPORTED_MODULE_6__.MatSelectModule,
            _angular_material_button__WEBPACK_IMPORTED_MODULE_7__.MatButtonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule,
            _angular_material_divider__WEBPACK_IMPORTED_MODULE_9__.MatDividerModule,
            _angular_cdk_clipboard__WEBPACK_IMPORTED_MODULE_10__.ClipboardModule,
            _angular_material_expansion__WEBPACK_IMPORTED_MODULE_11__.MatExpansionModule
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](DialogSharingModule, { declarations: [_dialog_sharing_component__WEBPACK_IMPORTED_MODULE_0__.DialogSharing], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.CommonModule,
        _angular_material_icon__WEBPACK_IMPORTED_MODULE_3__.MatIconModule,
        _angular_material_chips__WEBPACK_IMPORTED_MODULE_4__.MatChipsModule,
        _angular_material_form_field__WEBPACK_IMPORTED_MODULE_5__.MatFormFieldModule,
        _angular_material_select__WEBPACK_IMPORTED_MODULE_6__.MatSelectModule,
        _angular_material_button__WEBPACK_IMPORTED_MODULE_7__.MatButtonModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule,
        _angular_material_divider__WEBPACK_IMPORTED_MODULE_9__.MatDividerModule,
        _angular_cdk_clipboard__WEBPACK_IMPORTED_MODULE_10__.ClipboardModule,
        _angular_material_expansion__WEBPACK_IMPORTED_MODULE_11__.MatExpansionModule] }); })();


/***/ }),

/***/ 946:
/*!**********************************************************************!*\
  !*** ./src/app/pages/index/index-default/index-default.component.ts ***!
  \**********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "IndexDefaultComponent": function() { return /* binding */ IndexDefaultComponent; }
/* harmony export */ });
/* harmony import */ var _app_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @app/environment */ 2340);
/* harmony import */ var _dialog_sharing_dialog_sharing_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./dialog-sharing/dialog-sharing.component */ 7622);
/* harmony import */ var kubeflow__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! kubeflow */ 872);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 826);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./config */ 4295);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lodash */ 3815);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var src_app_services_backend_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/backend.service */ 600);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/material/dialog */ 2238);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/material/input */ 3166);


// YC 2023/12/03 end













function IndexDefaultComponent_lib_namespace_select_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](0, "lib-namespace-select");
} }
class IndexDefaultComponent {
    constructor(ns, backend, confirmDialog, snackBar, router, dialog) {
        this.ns = ns;
        this.backend = backend;
        this.confirmDialog = confirmDialog;
        this.snackBar = snackBar;
        this.router = router;
        this.dialog = dialog;
        this.env = _app_environment__WEBPACK_IMPORTED_MODULE_0__.environment;
        this.currNamespace = '';
        this.subs = new rxjs__WEBPACK_IMPORTED_MODULE_6__.Subscription();
        this.config = _config__WEBPACK_IMPORTED_MODULE_2__.defaultConfig;
        this.rawData = [];
        this.processedData = [];
        this.search = new _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormControl();
        this.buttons = [
            new kubeflow__WEBPACK_IMPORTED_MODULE_8__.ToolbarButton({
                text: `New Notebook`,
                icon: 'add',
                stroked: true,
                fn: () => {
                    this.router.navigate(['/new']);
                },
            }),
        ];
    }
    ngOnInit() {
        this.poller = new kubeflow__WEBPACK_IMPORTED_MODULE_8__.ExponentialBackoff({ interval: 1000, retries: 3 });
        // Poll for new data and reset the poller if different data is found
        this.search.valueChanges.subscribe(newValue => {
            this.poller.reset();
            this.rawData = [];
        });
        this.subs.add(this.poller.start().subscribe(() => {
            if (!this.currNamespace) {
                return;
            }
            this.backend.getNotebooks(this.currNamespace).subscribe(notebooks => {
                if (!(0,lodash__WEBPACK_IMPORTED_MODULE_3__.isEqual)(this.rawData, notebooks)) {
                    this.rawData = notebooks;
                    // Update the frontend's state
                    this.processedData = this.processIncomingData(notebooks);
                    this.poller.reset();
                }
            });
        }));
        // Reset the poller whenever the selected namespace changes
        this.subs.add(this.ns.getSelectedNamespace().subscribe(ns => {
            this.currNamespace = ns;
            this.poller.reset();
        }));
    }
    ngOnDestroy() {
        this.subs.unsubscribe();
        this.poller.stop();
    }
    // Event handling functions
    reactToAction(a) {
        switch (a.action) {
            case 'delete':
                this.deleteVolumeClicked(a.data);
                break;
            case 'connect':
                this.connectClicked(a.data);
                break;
            case 'start-stop':
                this.startStopClicked(a.data);
                break;
            // 2024/1/16 YCL start //
            case 'view':
                const dialogRef = this.dialog.open(_dialog_sharing_dialog_sharing_component__WEBPACK_IMPORTED_MODULE_1__.DialogSharing, { data: { namespace: a.data.namespace, name: a.data.name } });
                dialogRef.afterClosed().subscribe((result) => {
                    //const jsyaml = require('js-yaml');
                    if (result && result.useremail) {
                        const useremail = result.useremail;
                        console.log('User Email from Dialog:', useremail);
                        const selected = result.selected;
                        // if select "view" //
                        if (selected == 'option1') {
                            const paths = `/notebook/${a.data.namespace}/${a.data.name}/view/*`;
                            const namevalue = `notebook-${a.data.name}-authorizationpolicy-view`;
                            this.backend.getAllAuthorizationPolicy(a.data.namespace).subscribe(aps => {
                                console.log(a.data.namespace);
                                var deletename = "notebook-" + a.data.name + "-authorizationpolicy-view";
                                var names = aps.map((ap) => { return ap.metadata.name; });
                                var filteredNames = names.filter((name) => name.includes(deletename));
                                if (filteredNames.length <= 0) {
                                    this.backend.createAuthorization(this.currNamespace, namevalue, paths, useremail).subscribe((response) => {
                                        console.log("Success");
                                        console.log('currNamespace:', this.currNamespace);
                                        console.log('namevalue:', namevalue);
                                        console.log("paths:", paths);
                                        console.log("useremail:", useremail);
                                        console.log("selected-option:", selected);
                                    }, (error) => {
                                        console.error('Error creating authorization policy:', error);
                                    });
                                }
                                else {
                                    //2024/01/23 新增email功能 start
                                    this.backend.modify_authorizaiton(this.currNamespace, namevalue, useremail).subscribe((response) => {
                                        console.log("Success for adding");
                                        console.log('currNamespace:', this.currNamespace);
                                        console.log('namevalue:', namevalue);
                                        console.log("useremail:", useremail);
                                        console.log("selected-option:", selected);
                                    }, (error) => {
                                        console.log('filteredName != 0, existed');
                                    });
                                }
                            });
                            //2024/01/23 新增email功能 end
                        }
                        else {
                            // if select "editable" //
                            const paths = `/notebook/${a.data.namespace}/${a.data.name}/*`;
                            const namevalue = `notebook-${a.data.name}-authorizationpolicy-editable`;
                            this.backend.getAllAuthorizationPolicy(a.data.namespace).subscribe(aps => {
                                console.log(a.data.namespace);
                                var deletename = "notebook-" + a.data.name + "-authorizationpolicy-editable";
                                var names = aps.map((ap) => { return ap.metadata.name; });
                                var filteredNames = names.filter((name) => name.includes(deletename));
                                if (filteredNames.length <= 0) {
                                    this.backend.createAuthorization(this.currNamespace, namevalue, paths, useremail).subscribe((response) => {
                                        console.log("Success");
                                        console.log('currNamespace:', this.currNamespace);
                                        console.log('namevalue:', namevalue);
                                        console.log("paths:", paths);
                                        console.log("useremail:", useremail);
                                        console.log("selected-option:", selected);
                                    }, (error) => {
                                        console.error('Error creating authorization policy:', error);
                                    });
                                }
                                else {
                                    //2024/01/23 新增email功能 start
                                    this.backend.modify_authorizaiton(this.currNamespace, namevalue, useremail).subscribe((response) => {
                                        console.log("Success for adding");
                                        console.log('currNamespace:', this.currNamespace);
                                        console.log('namevalue:', namevalue);
                                        console.log("useremail:", useremail);
                                        console.log("selected-option:", selected);
                                    }, (error) => {
                                        console.log('filteredName != 0, existed');
                                    });
                                }
                            });
                        }
                        ;
                        //2024/01/23 新增email功能 end
                    }
                });
                // 2024/1/16 YC end //
                break;
        }
    }
    deleteVolumeClicked(notebook) {
        const deleteDialogConfig = (0,_config__WEBPACK_IMPORTED_MODULE_2__.getDeleteDialogConfig)(notebook.name);
        const ref = this.confirmDialog.open(notebook.name, deleteDialogConfig);
        const delSub = ref.componentInstance.applying$.subscribe(applying => {
            if (!applying) {
                return;
            }
            // Close the open dialog only if the DELETE request succeeded
            this.backend.deleteNotebook(this.currNamespace, notebook.name).subscribe({
                next: _ => {
                    this.poller.reset();
                    ref.close(kubeflow__WEBPACK_IMPORTED_MODULE_8__.DIALOG_RESP.ACCEPT);
                },
                error: err => {
                    const errorMsg = err;
                    deleteDialogConfig.error = errorMsg;
                    ref.componentInstance.applying$.next(false);
                },
            });
            // DELETE request has succeeded
            ref.afterClosed().subscribe(res => {
                delSub.unsubscribe();
                if (res !== kubeflow__WEBPACK_IMPORTED_MODULE_8__.DIALOG_RESP.ACCEPT) {
                    return;
                }
                notebook.status.phase = kubeflow__WEBPACK_IMPORTED_MODULE_8__.STATUS_TYPE.TERMINATING;
                notebook.status.message = 'Preparing to delete the Notebook...';
                this.updateNotebookFields(notebook);
            });
        });
    }
    connectClicked(notebook) {
        // Open new tab to work on the Notebook
        window.open(`/notebook/${notebook.namespace}/${notebook.name}/`);
    }
    startStopClicked(notebook) {
        if (notebook.status.phase === kubeflow__WEBPACK_IMPORTED_MODULE_8__.STATUS_TYPE.STOPPED) {
            this.startNotebook(notebook);
        }
        else {
            this.stopNotebook(notebook);
        }
    }
    startNotebook(notebook) {
        this.snackBar.open($localize `Starting Notebook server '${notebook.name}'...`, kubeflow__WEBPACK_IMPORTED_MODULE_8__.SnackType.Info, 3000);
        notebook.status.phase = kubeflow__WEBPACK_IMPORTED_MODULE_8__.STATUS_TYPE.WAITING;
        notebook.status.message = 'Starting the Notebook Server...';
        this.updateNotebookFields(notebook);
        this.backend.startNotebook(notebook).subscribe(() => {
            this.poller.reset();
        });
    }
    stopNotebook(notebook) {
        const stopDialogConfig = (0,_config__WEBPACK_IMPORTED_MODULE_2__.getStopDialogConfig)(notebook.name);
        const ref = this.confirmDialog.open(notebook.name, stopDialogConfig);
        const stopSub = ref.componentInstance.applying$.subscribe(applying => {
            if (!applying) {
                return;
            }
            // Close the open dialog only if the request succeeded
            this.backend.stopNotebook(notebook).subscribe({
                next: _ => {
                    this.poller.reset();
                    ref.close(kubeflow__WEBPACK_IMPORTED_MODULE_8__.DIALOG_RESP.ACCEPT);
                },
                error: err => {
                    const errorMsg = err;
                    stopDialogConfig.error = errorMsg;
                    ref.componentInstance.applying$.next(false);
                },
            });
            // request has succeeded
            ref.afterClosed().subscribe(res => {
                stopSub.unsubscribe();
                if (res !== kubeflow__WEBPACK_IMPORTED_MODULE_8__.DIALOG_RESP.ACCEPT) {
                    return;
                }
                this.snackBar.open($localize `Stopping Notebook server '${notebook.name}'...`, kubeflow__WEBPACK_IMPORTED_MODULE_8__.SnackType.Info, 3000);
                notebook.status.phase = kubeflow__WEBPACK_IMPORTED_MODULE_8__.STATUS_TYPE.TERMINATING;
                notebook.status.message = 'Preparing to stop the Notebook Server...';
                this.updateNotebookFields(notebook);
            });
        });
    }
    // Data processing functions
    updateNotebookFields(notebook) {
        notebook.deleteAction = this.processDeletionActionStatus(notebook);
        notebook.connectAction = this.processConnectActionStatus(notebook);
        notebook.startStopAction = this.processStartStopActionStatus(notebook);
    }
    processIncomingData(notebooks) {
        const notebooksCopy = JSON.parse(JSON.stringify(notebooks));
        var newCopy = [];
        console.log(this.search.value);
        for (const nb of notebooksCopy) {
            if (this.search.value == null || nb.name.indexOf(this.search.value) != -1) {
                newCopy.push(nb);
                this.updateNotebookFields(nb);
            }
        }
        return newCopy;
    }
    // Action handling functions
    processDeletionActionStatus(notebook) {
        if (notebook.status.phase !== kubeflow__WEBPACK_IMPORTED_MODULE_8__.STATUS_TYPE.TERMINATING) {
            return kubeflow__WEBPACK_IMPORTED_MODULE_8__.STATUS_TYPE.READY;
        }
        return kubeflow__WEBPACK_IMPORTED_MODULE_8__.STATUS_TYPE.TERMINATING;
    }
    processStartStopActionStatus(notebook) {
        // Stop button
        if (notebook.status.phase === kubeflow__WEBPACK_IMPORTED_MODULE_8__.STATUS_TYPE.READY) {
            return kubeflow__WEBPACK_IMPORTED_MODULE_8__.STATUS_TYPE.UNINITIALIZED;
        }
        // Start button
        if (notebook.status.phase === kubeflow__WEBPACK_IMPORTED_MODULE_8__.STATUS_TYPE.STOPPED) {
            return kubeflow__WEBPACK_IMPORTED_MODULE_8__.STATUS_TYPE.READY;
        }
        // If it is terminating, then the action should be disabled
        if (notebook.status.phase === kubeflow__WEBPACK_IMPORTED_MODULE_8__.STATUS_TYPE.TERMINATING) {
            return kubeflow__WEBPACK_IMPORTED_MODULE_8__.STATUS_TYPE.UNAVAILABLE;
        }
        // If the Notebook is not Terminating, then always allow the stop action
        return kubeflow__WEBPACK_IMPORTED_MODULE_8__.STATUS_TYPE.UNINITIALIZED;
    }
    processConnectActionStatus(notebook) {
        if (notebook.status.phase !== kubeflow__WEBPACK_IMPORTED_MODULE_8__.STATUS_TYPE.READY) {
            return kubeflow__WEBPACK_IMPORTED_MODULE_8__.STATUS_TYPE.UNAVAILABLE;
        }
        return kubeflow__WEBPACK_IMPORTED_MODULE_8__.STATUS_TYPE.READY;
    }
    notebookTrackByFn(index, notebook) {
        return `${notebook.name}/${notebook.image}`;
    }
}
IndexDefaultComponent.ɵfac = function IndexDefaultComponent_Factory(t) { return new (t || IndexDefaultComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](kubeflow__WEBPACK_IMPORTED_MODULE_8__.NamespaceService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_services_backend_service__WEBPACK_IMPORTED_MODULE_4__.JWABackendService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](kubeflow__WEBPACK_IMPORTED_MODULE_8__.ConfirmDialogService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](kubeflow__WEBPACK_IMPORTED_MODULE_8__.SnackBarService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_9__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_material_dialog__WEBPACK_IMPORTED_MODULE_10__.MatDialog)); };
IndexDefaultComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({ type: IndexDefaultComponent, selectors: [["app-index-default"]], decls: 6, vars: 6, consts: function () { let i18n_0; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_5114128994255248149$$SRC_APP_PAGES_INDEX_INDEX_DEFAULT_INDEX_DEFAULT_COMPONENT_TS_1 = goog.getMsg("Notebooks");
        i18n_0 = MSG_EXTERNAL_5114128994255248149$$SRC_APP_PAGES_INDEX_INDEX_DEFAULT_INDEX_DEFAULT_COMPONENT_TS_1;
    }
    else {
        i18n_0 = $localize `:␟fbc6d8bbd465eba779b7c1aa7017cc0b47125097␟5114128994255248149:Notebooks`;
    } let i18n_2; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_1620550124401629400$$SRC_APP_PAGES_INDEX_INDEX_DEFAULT_INDEX_DEFAULT_COMPONENT_TS_3 = goog.getMsg("Search keyword");
        i18n_2 = MSG_EXTERNAL_1620550124401629400$$SRC_APP_PAGES_INDEX_INDEX_DEFAULT_INDEX_DEFAULT_COMPONENT_TS_3;
    }
    else {
        i18n_2 = $localize `:␟b344701bb936bffa68aa427bb13408806cc0140c␟1620550124401629400:Search keyword`;
    } return [[1, "lib-content-wrapper"], ["title", i18n_0, 3, "buttons"], [4, "ngIf"], ["matInput", "", "placeholder", i18n_2, 3, "formControl"], [1, "page-padding", "lib-flex-grow", "lib-overflow-auto"], [3, "config", "data", "trackByFn", "actionsEmitter"]]; }, template: function IndexDefaultComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "lib-title-actions-toolbar", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](2, IndexDefaultComponent_lib_namespace_select_2_Template, 1, 0, "lib-namespace-select", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](3, "input", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](5, "lib-table", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("actionsEmitter", function IndexDefaultComponent_Template_lib_table_actionsEmitter_5_listener($event) { return ctx.reactToAction($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("buttons", ctx.buttons);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", !ctx.env.production);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("formControl", ctx.search);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("config", ctx.config)("data", ctx.processedData)("trackByFn", ctx.notebookTrackByFn);
    } }, directives: [kubeflow__WEBPACK_IMPORTED_MODULE_8__.TitleActionsToolbarComponent, _angular_common__WEBPACK_IMPORTED_MODULE_11__.NgIf, _angular_material_input__WEBPACK_IMPORTED_MODULE_12__.MatInput, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormControlDirective, kubeflow__WEBPACK_IMPORTED_MODULE_8__.TableComponent, kubeflow__WEBPACK_IMPORTED_MODULE_8__.NamespaceSelectComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJpbmRleC1kZWZhdWx0LmNvbXBvbmVudC5zY3NzIn0= */"] });


/***/ }),

/***/ 7390:
/*!*******************************************************************!*\
  !*** ./src/app/pages/index/index-default/index-default.module.ts ***!
  \*******************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "IndexDefaultModule": function() { return /* binding */ IndexDefaultModule; }
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _index_default_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index-default.component */ 946);
/* harmony import */ var kubeflow__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! kubeflow */ 872);
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/dialog */ 2238);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/form-field */ 8295);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/icon */ 6627);
/* harmony import */ var _angular_material_chips__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/chips */ 8341);
/* harmony import */ var _dialog_sharing_dialog_sharing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./dialog-sharing/dialog-sharing.module */ 5867);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);









class IndexDefaultModule {
}
IndexDefaultModule.ɵfac = function IndexDefaultModule_Factory(t) { return new (t || IndexDefaultModule)(); };
IndexDefaultModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: IndexDefaultModule });
IndexDefaultModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule, kubeflow__WEBPACK_IMPORTED_MODULE_4__.KubeflowModule, _angular_material_dialog__WEBPACK_IMPORTED_MODULE_5__.MatDialogModule, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_6__.MatFormFieldModule, _angular_material_icon__WEBPACK_IMPORTED_MODULE_7__.MatIconModule, _angular_material_chips__WEBPACK_IMPORTED_MODULE_8__.MatChipsModule, _dialog_sharing_dialog_sharing_module__WEBPACK_IMPORTED_MODULE_1__.DialogSharingModule]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](IndexDefaultModule, { declarations: [_index_default_component__WEBPACK_IMPORTED_MODULE_0__.IndexDefaultComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule, kubeflow__WEBPACK_IMPORTED_MODULE_4__.KubeflowModule, _angular_material_dialog__WEBPACK_IMPORTED_MODULE_5__.MatDialogModule, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_6__.MatFormFieldModule, _angular_material_icon__WEBPACK_IMPORTED_MODULE_7__.MatIconModule, _angular_material_chips__WEBPACK_IMPORTED_MODULE_8__.MatChipsModule, _dialog_sharing_dialog_sharing_module__WEBPACK_IMPORTED_MODULE_1__.DialogSharingModule], exports: [_index_default_component__WEBPACK_IMPORTED_MODULE_0__.IndexDefaultComponent] }); })();


/***/ }),

/***/ 1610:
/*!********************************************************************************!*\
  !*** ./src/app/pages/index/index-default/server-type/server-type.component.ts ***!
  \********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ServerTypeComponent": function() { return /* binding */ ServerTypeComponent; }
/* harmony export */ });
/* harmony import */ var _app_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @app/environment */ 2340);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material/icon */ 6627);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser */ 9075);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);





function ServerTypeComponent_mat_icon_0_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](0, "mat-icon", 3);
} }
function ServerTypeComponent_mat_icon_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](0, "mat-icon", 4);
} }
function ServerTypeComponent_mat_icon_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](0, "mat-icon", 5);
} }
class ServerTypeComponent {
    constructor(iconRegistry, sanitizer) {
        iconRegistry.addSvgIcon('jupyterlab-icon', sanitizer.bypassSecurityTrustResourceUrl(_app_environment__WEBPACK_IMPORTED_MODULE_0__.environment.jupyterIcon));
        iconRegistry.addSvgIcon('group-one-icon', sanitizer.bypassSecurityTrustResourceUrl(_app_environment__WEBPACK_IMPORTED_MODULE_0__.environment.groupOneIcon));
        iconRegistry.addSvgIcon('group-two-icon', sanitizer.bypassSecurityTrustResourceUrl(_app_environment__WEBPACK_IMPORTED_MODULE_0__.environment.groupTwoIcon));
    }
    set element(notebook) {
        this.notebookServerType = notebook.serverType;
    }
}
ServerTypeComponent.ɵfac = function ServerTypeComponent_Factory(t) { return new (t || ServerTypeComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_material_icon__WEBPACK_IMPORTED_MODULE_2__.MatIconRegistry), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__.DomSanitizer)); };
ServerTypeComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: ServerTypeComponent, selectors: [["app-server-type"]], decls: 3, vars: 3, consts: [["svgIcon", "jupyterlab-icon", "aria-hidden", "false", "aria-label", "JupyterLab based server", 4, "ngIf"], ["svgIcon", "group-one-icon", "aria-hidden", "false", "aria-label", "Group One based server", 4, "ngIf"], ["svgIcon", "group-two-icon", "aria-hidden", "false", "aria-label", "Group Two based server", 4, "ngIf"], ["svgIcon", "jupyterlab-icon", "aria-hidden", "false", "aria-label", "JupyterLab based server"], ["svgIcon", "group-one-icon", "aria-hidden", "false", "aria-label", "Group One based server"], ["svgIcon", "group-two-icon", "aria-hidden", "false", "aria-label", "Group Two based server"]], template: function ServerTypeComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](0, ServerTypeComponent_mat_icon_0_Template, 1, 0, "mat-icon", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](1, ServerTypeComponent_mat_icon_1_Template, 1, 0, "mat-icon", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](2, ServerTypeComponent_mat_icon_2_Template, 1, 0, "mat-icon", 2);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.notebookServerType === "jupyter");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.notebookServerType === "group-one");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.notebookServerType === "group-two");
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.NgIf, _angular_material_icon__WEBPACK_IMPORTED_MODULE_2__.MatIcon], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzZXJ2ZXItdHlwZS5jb21wb25lbnQuc2NzcyJ9 */"] });


/***/ }),

/***/ 3258:
/*!**************************************************************!*\
  !*** ./src/app/pages/index/index-rok/index-rok.component.ts ***!
  \**************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "IndexRokComponent": function() { return /* binding */ IndexRokComponent; }
/* harmony export */ });
/* harmony import */ var _index_default_index_default_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../index-default/index-default.component */ 946);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var kubeflow__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! kubeflow */ 872);
/* harmony import */ var src_app_services_backend_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/services/backend.service */ 600);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/dialog */ 2238);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_material_input__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/input */ 3166);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 3679);









function IndexRokComponent_lib_namespace_select_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](0, "lib-namespace-select");
} }
class IndexRokComponent extends _index_default_index_default_component__WEBPACK_IMPORTED_MODULE_0__.IndexDefaultComponent {
    constructor(rok, ns, backend, confirmDialog, popup, router, dialog) {
        super(ns, backend, confirmDialog, popup, router, dialog);
        this.rok = rok;
        this.ns = ns;
        this.backend = backend;
        this.confirmDialog = confirmDialog;
        this.popup = popup;
        this.router = router;
        this.dialog = dialog;
        this.rok.initCSRF();
    }
}
IndexRokComponent.ɵfac = function IndexRokComponent_Factory(t) { return new (t || IndexRokComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](kubeflow__WEBPACK_IMPORTED_MODULE_3__.RokService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](kubeflow__WEBPACK_IMPORTED_MODULE_3__.NamespaceService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_services_backend_service__WEBPACK_IMPORTED_MODULE_1__.JWABackendService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](kubeflow__WEBPACK_IMPORTED_MODULE_3__.ConfirmDialogService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](kubeflow__WEBPACK_IMPORTED_MODULE_3__.SnackBarService), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_4__.Router), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_material_dialog__WEBPACK_IMPORTED_MODULE_5__.MatDialog)); };
IndexRokComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({ type: IndexRokComponent, selectors: [["app-index-rok"]], features: [_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵInheritDefinitionFeature"]], decls: 6, vars: 6, consts: function () { let i18n_0; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_5114128994255248149$$SRC_APP_PAGES_INDEX_INDEX_ROK_INDEX_ROK_COMPONENT_TS_1 = goog.getMsg("Notebooks");
        i18n_0 = MSG_EXTERNAL_5114128994255248149$$SRC_APP_PAGES_INDEX_INDEX_ROK_INDEX_ROK_COMPONENT_TS_1;
    }
    else {
        i18n_0 = $localize `:␟fbc6d8bbd465eba779b7c1aa7017cc0b47125097␟5114128994255248149:Notebooks`;
    } let i18n_2; if (typeof ngI18nClosureMode !== "undefined" && ngI18nClosureMode) {
        const MSG_EXTERNAL_1620550124401629400$$SRC_APP_PAGES_INDEX_INDEX_ROK_INDEX_ROK_COMPONENT_TS_3 = goog.getMsg("Search keyword");
        i18n_2 = MSG_EXTERNAL_1620550124401629400$$SRC_APP_PAGES_INDEX_INDEX_ROK_INDEX_ROK_COMPONENT_TS_3;
    }
    else {
        i18n_2 = $localize `:␟b344701bb936bffa68aa427bb13408806cc0140c␟1620550124401629400:Search keyword`;
    } return [[1, "lib-content-wrapper"], ["title", i18n_0, 3, "buttons"], [4, "ngIf"], ["matInput", "", "placeholder", i18n_2, 3, "formControl"], [1, "page-padding", "lib-flex-grow", "lib-overflow-auto"], [3, "config", "data", "trackByFn", "actionsEmitter"]]; }, template: function IndexRokComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "lib-title-actions-toolbar", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](2, IndexRokComponent_lib_namespace_select_2_Template, 1, 0, "lib-namespace-select", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](3, "input", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "lib-table", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("actionsEmitter", function IndexRokComponent_Template_lib_table_actionsEmitter_5_listener($event) { return ctx.reactToAction($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("buttons", ctx.buttons);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", !ctx.env.production);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("formControl", ctx.search);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("config", ctx.config)("data", ctx.processedData)("trackByFn", ctx.notebookTrackByFn);
    } }, directives: [kubeflow__WEBPACK_IMPORTED_MODULE_3__.TitleActionsToolbarComponent, _angular_common__WEBPACK_IMPORTED_MODULE_6__.NgIf, _angular_material_input__WEBPACK_IMPORTED_MODULE_7__.MatInput, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormControlDirective, kubeflow__WEBPACK_IMPORTED_MODULE_3__.TableComponent, kubeflow__WEBPACK_IMPORTED_MODULE_3__.NamespaceSelectComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJpbmRleC1kZWZhdWx0LmNvbXBvbmVudC5zY3NzIn0= */"] });


/***/ }),

/***/ 3901:
/*!***********************************************************!*\
  !*** ./src/app/pages/index/index-rok/index-rok.module.ts ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "IndexRokModule": function() { return /* binding */ IndexRokModule; }
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _index_rok_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index-rok.component */ 3258);
/* harmony import */ var kubeflow__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! kubeflow */ 872);
/* harmony import */ var _index_default_index_default_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../index-default/index-default.module */ 7390);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/form-field */ 8295);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);






class IndexRokModule {
}
IndexRokModule.ɵfac = function IndexRokModule_Factory(t) { return new (t || IndexRokModule)(); };
IndexRokModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: IndexRokModule });
IndexRokModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [[_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule, kubeflow__WEBPACK_IMPORTED_MODULE_4__.KubeflowModule, _index_default_index_default_module__WEBPACK_IMPORTED_MODULE_1__.IndexDefaultModule, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_5__.MatFormFieldModule
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](IndexRokModule, { declarations: [_index_rok_component__WEBPACK_IMPORTED_MODULE_0__.IndexRokComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule, kubeflow__WEBPACK_IMPORTED_MODULE_4__.KubeflowModule, _index_default_index_default_module__WEBPACK_IMPORTED_MODULE_1__.IndexDefaultModule, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_5__.MatFormFieldModule], exports: [_index_rok_component__WEBPACK_IMPORTED_MODULE_0__.IndexRokComponent] }); })();


/***/ }),

/***/ 7479:
/*!************************************************!*\
  !*** ./src/app/pages/index/index.component.ts ***!
  \************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "IndexComponent": function() { return /* binding */ IndexComponent; }
/* harmony export */ });
/* harmony import */ var _app_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @app/environment */ 2340);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _index_default_index_default_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./index-default/index-default.component */ 946);
/* harmony import */ var _index_rok_index_rok_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./index-rok/index-rok.component */ 3258);





function IndexComponent_app_index_default_0_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "app-index-default");
} }
function IndexComponent_app_index_rok_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "app-index-rok");
} }
class IndexComponent {
    constructor() {
        this.env = _app_environment__WEBPACK_IMPORTED_MODULE_0__.environment;
    }
    ngOnInit() { }
}
IndexComponent.ɵfac = function IndexComponent_Factory(t) { return new (t || IndexComponent)(); };
IndexComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({ type: IndexComponent, selectors: [["app-index"]], decls: 2, vars: 2, consts: [[4, "ngIf"]], template: function IndexComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](0, IndexComponent_app_index_default_0_Template, 1, 0, "app-index-default", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, IndexComponent_app_index_rok_1_Template, 1, 0, "app-index-rok", 0);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.env.ui === "default");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.env.ui === "rok");
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.NgIf, _index_default_index_default_component__WEBPACK_IMPORTED_MODULE_1__.IndexDefaultComponent, _index_rok_index_rok_component__WEBPACK_IMPORTED_MODULE_2__.IndexRokComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJpbmRleC5jb21wb25lbnQuc2NzcyJ9 */"] });


/***/ }),

/***/ 1023:
/*!*********************************************!*\
  !*** ./src/app/pages/index/index.module.ts ***!
  \*********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "IndexModule": function() { return /* binding */ IndexModule; }
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_material_icon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/icon */ 6627);
/* harmony import */ var _index_rok_index_rok_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index-rok/index-rok.module */ 3901);
/* harmony import */ var _index_default_index_default_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./index-default/index-default.module */ 7390);
/* harmony import */ var _index_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./index.component */ 7479);
/* harmony import */ var _index_default_server_type_server_type_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./index-default/server-type/server-type.component */ 1610);
/* harmony import */ var _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material/tooltip */ 1436);
/* harmony import */ var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/form-field */ 8295);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);









class IndexModule {
}
IndexModule.ɵfac = function IndexModule_Factory(t) { return new (t || IndexModule)(); };
IndexModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineNgModule"]({ type: IndexModule });
IndexModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _index_rok_index_rok_module__WEBPACK_IMPORTED_MODULE_0__.IndexRokModule,
            _index_default_index_default_module__WEBPACK_IMPORTED_MODULE_1__.IndexDefaultModule,
            _angular_material_icon__WEBPACK_IMPORTED_MODULE_6__.MatIconModule,
            _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_7__.MatTooltipModule,
            _angular_material_form_field__WEBPACK_IMPORTED_MODULE_8__.MatFormFieldModule
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsetNgModuleScope"](IndexModule, { declarations: [_index_component__WEBPACK_IMPORTED_MODULE_2__.IndexComponent, _index_default_server_type_server_type_component__WEBPACK_IMPORTED_MODULE_3__.ServerTypeComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
        _index_rok_index_rok_module__WEBPACK_IMPORTED_MODULE_0__.IndexRokModule,
        _index_default_index_default_module__WEBPACK_IMPORTED_MODULE_1__.IndexDefaultModule,
        _angular_material_icon__WEBPACK_IMPORTED_MODULE_6__.MatIconModule,
        _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_7__.MatTooltipModule,
        _angular_material_form_field__WEBPACK_IMPORTED_MODULE_8__.MatFormFieldModule] }); })();


/***/ }),

/***/ 600:
/*!*********************************************!*\
  !*** ./src/app/services/backend.service.ts ***!
  \*********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "JWABackendService": function() { return /* binding */ JWABackendService; }
/* harmony export */ });
/* harmony import */ var kubeflow__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! kubeflow */ 872);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ 5304);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 8002);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ 1841);





class JWABackendService extends kubeflow__WEBPACK_IMPORTED_MODULE_0__.BackendService {
    constructor(http, snackBar) {
        super(http, snackBar);
        this.http = http;
        this.snackBar = snackBar;
    }
    // GET
    getNotebooks(namespace) {
        const url = `api/namespaces/${namespace}/notebooks`;
        return this.http.get(url).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.catchError)(error => this.handleError(error)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.map)((resp) => {
            return resp.notebooks;
        }));
    }
    getAllNotebooks() {
        const url = `api/namespaces/allnotebooks`;
        return this.http.get(url).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.catchError)(error => this.handleError(error)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.map)((resp) => {
            return resp.notebooks;
        }));
    }
    // 2024/01/21 YCL authorizationPolicy start//
    getAllAuthorizationPolicy(namespace) {
        const url = `api/namespaces/${namespace}/aps`;
        return this.http.get(url).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.catchError)(error => this.handleError(error)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.map)((resp) => {
            console.log('xxxxxx');
            return resp.authorizationpolicy;
        }));
    }
    // 2024/01/21 YCL authorizationPolicy end//
    getConfig() {
        const url = `api/config`;
        return this.http.get(url).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.catchError)(error => this.handleError(error)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.map)(data => {
            return data.config;
        }));
    }
    getVolumes(ns) {
        // Get existing PVCs in a namespace
        const url = `api/namespaces/${ns}/pvcs`;
        return this.http.get(url).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.catchError)(error => this.handleError(error)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.map)(data => {
            return data.pvcs;
        }));
    }
    getPodDefaults(ns) {
        // Get existing PodDefaults in a namespace
        const url = `api/namespaces/${ns}/poddefaults`;
        return this.http.get(url).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.catchError)(error => this.handleError(error)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.map)(data => {
            return data.poddefaults;
        }));
    }
    getGPUVendors() {
        // Get installed GPU vendors
        const url = `api/gpus`;
        return this.http.get(url).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.catchError)(error => this.handleError(error)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.map)(data => data.vendors));
    }
    // POST
    createNotebook(notebook) {
        const url = `api/namespaces/${notebook.namespace}/notebooks`;
        return this.http.post(url, notebook).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.catchError)(error => this.handleError(error)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.map)(_ => {
            return 'posted';
        }));
    }
    //2024/01/21 YCL createauthorizationpolicy start//
    createAuthorization(namespace, nameValue, pathValue, userEmail) {
        const url2 = `api/namespaces/${namespace}/aps_vnc`;
        // Create an object with the 'name' parameter
        const requestBody = { name: nameValue, paths: pathValue, useremail: userEmail };
        return this.http.post(url2, requestBody).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.catchError)(_ => {
            return 'error';
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.map)(_ => {
            return 'posted';
        }));
    }
    //2024/01/21 YCL createauthorizationpolicy end//
    //2024/01/21 YCL deleteauthorizationpolicy start// 
    // DELETE
    deleteauthorization(delete_name, namespace) {
        const url = `api/namespaces/${namespace}/aps_vnc/${delete_name}`;
        return this.http
            .delete(url)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.catchError)(error => this.handleError(error, false)));
    }
    //2024/01/21 YCL deleteauthorizationpolicy end// 
    // 2024/01/23 YCL add data start//
    modify_authorizaiton(nameSpace, namevalue, adddata) {
        const url2 = `api/namespaces/${nameSpace}/aps_vnc/${namevalue}`;
        // Create an object with the 'name' parameter
        const requestBody = { values_to_add: adddata };
        return this.http.patch(url2, requestBody).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.catchError)(_ => {
            return 'error';
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.map)(_ => {
            return 'posted';
        }));
    }
    // 2024/01/23 YCL add data end//
    // 2024/01/23 YCL delete data start//
    modify_authorizaiton_delete(nameSpace, namevalue, deletedata) {
        const url2 = `api/namespaces/${nameSpace}/aps_vnc_1/${namevalue}`;
        // Create an object with the 'name' parameter
        const requestBody = { values_to_delete: deletedata };
        return this.http.patch(url2, requestBody).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.catchError)(_ => {
            return 'error';
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.map)(_ => {
            return 'posted';
        }));
    }
    // 2024/01/23 YCL delete data end//
    // PATCH
    startNotebook(notebook) {
        const name = notebook.name;
        const namespace = notebook.namespace;
        const url = `api/namespaces/${namespace}/notebooks/${name}`;
        return this.http.patch(url, { stopped: false }).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.catchError)(error => this.handleError(error)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.map)(_ => {
            return 'started';
        }));
    }
    stopNotebook(notebook) {
        const name = notebook.name;
        const namespace = notebook.namespace;
        const url = `api/namespaces/${namespace}/notebooks/${name}`;
        return this.http.patch(url, { stopped: true }).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.catchError)(error => this.handleError(error, false)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.map)(_ => {
            return 'stopped';
        }));
    }
    // DELETE
    deleteNotebook(namespace, name) {
        const url = `api/namespaces/${namespace}/notebooks/${name}`;
        return this.http
            .delete(url)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.catchError)(error => this.handleError(error, false)));
    }
}
JWABackendService.ɵfac = function JWABackendService_Factory(t) { return new (t || JWABackendService)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_4__.HttpClient), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](kubeflow__WEBPACK_IMPORTED_MODULE_0__.SnackBarService)); };
JWABackendService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({ token: JWABackendService, factory: JWABackendService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ 7959:
/*!***********************************************!*\
  !*** ./src/app/shared/utils/volumes/forms.ts ***!
  \***********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "setGenerateNameCtrl": function() { return /* binding */ setGenerateNameCtrl; },
/* harmony export */   "createSourceFormGroup": function() { return /* binding */ createSourceFormGroup; },
/* harmony export */   "createGenericSourceFormGroup": function() { return /* binding */ createGenericSourceFormGroup; },
/* harmony export */   "createPvcFormGroup": function() { return /* binding */ createPvcFormGroup; },
/* harmony export */   "createExistingSourceFormGroup": function() { return /* binding */ createExistingSourceFormGroup; },
/* harmony export */   "createNewPvcFormGroup": function() { return /* binding */ createNewPvcFormGroup; },
/* harmony export */   "createNewPvcVolumeFormGroup": function() { return /* binding */ createNewPvcVolumeFormGroup; },
/* harmony export */   "createExistingVolumeFormGroup": function() { return /* binding */ createExistingVolumeFormGroup; },
/* harmony export */   "createMetadataFormGroupFromPvc": function() { return /* binding */ createMetadataFormGroupFromPvc; },
/* harmony export */   "createPvcSpecFormGroupFromPvc": function() { return /* binding */ createPvcSpecFormGroupFromPvc; },
/* harmony export */   "createExistingSourceFormGroupFromVolume": function() { return /* binding */ createExistingSourceFormGroupFromVolume; },
/* harmony export */   "createNewPvcFormGroupFromVolume": function() { return /* binding */ createNewPvcFormGroupFromVolume; },
/* harmony export */   "createFormGroupFromVolume": function() { return /* binding */ createFormGroupFromVolume; }
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var src_app_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/types */ 4984);


/*
 * Form Group helpers
 */
function setGenerateNameCtrl(meta, name = '') {
    if (meta.get('generateName')) {
        if (name) {
            meta.get('generateName').setValue(name);
        }
        return;
    }
    // remove the name control, if it exists, but carry over its value
    if (meta.get('name')) {
        if (!name) {
            name = meta.get('name').value;
        }
        meta.removeControl('name');
    }
    meta.addControl('generateName', new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormControl(name, [_angular_forms__WEBPACK_IMPORTED_MODULE_1__.Validators.required]));
}
// For volume.existingSource
function createSourceFormGroup(source) {
    switch (source) {
        case src_app_types__WEBPACK_IMPORTED_MODULE_0__.EXISTING_SOURCE.PERSISTENT_VOLUME_CLAIM: {
            return createPvcFormGroup();
        }
        default: {
            return createGenericSourceFormGroup(source);
        }
    }
}
// For volume.existingSource
// In this case the user will type a yaml to fill the spec
function createGenericSourceFormGroup(source) {
    return new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormControl('', []);
}
// for volume.existingSource.persistentVolumeClaim
function createPvcFormGroup() {
    return new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormGroup({
        readOnly: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormControl(false, []),
        claimName: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormControl('', [_angular_forms__WEBPACK_IMPORTED_MODULE_1__.Validators.required]),
    });
}
// for volume.existingSource
function createExistingSourceFormGroup() {
    return new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormGroup({
        persistentVolumeClaim: createPvcFormGroup(),
    });
}
// for volume.newPvc
function createNewPvcFormGroup(name = '{notebook-name}-volume') {
    return new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormGroup({
        metadata: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormGroup({
            name: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormControl(name, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.Validators.required),
        }),
        spec: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormGroup({
            accessModes: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormControl(['ReadWriteOnce']),
            resources: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormGroup({
                requests: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormGroup({
                    storage: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormControl('10Gi', []),
                }),
            }),
            storageClassName: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormControl({
                value: '',
                disabled: true,
            }),
        }),
    });
}
// For volume
function createNewPvcVolumeFormGroup(name = '{notebook-name}-volume') {
    return new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormGroup({
        name: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormControl('', []),
        mount: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormControl('', _angular_forms__WEBPACK_IMPORTED_MODULE_1__.Validators.required),
        newPvc: createNewPvcFormGroup(name),
    });
}
// For volume
function createExistingVolumeFormGroup() {
    return new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormGroup({
        name: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormControl('', []),
        mount: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormControl('', _angular_forms__WEBPACK_IMPORTED_MODULE_1__.Validators.required),
        existingSource: createExistingSourceFormGroup(),
    });
}
/*
 * Create Form Groups from JS ojects
 */
function createMetadataFormGroupFromPvc(pvc) {
    const metadata = pvc.metadata;
    const group = new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormGroup({});
    if (metadata.name) {
        group.addControl('name', new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormControl(metadata.name, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.Validators.required));
    }
    if (metadata.annotations) {
        group.addControl('annotations', new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormGroup({}));
        const annotationsGroup = group.get('annotations');
        for (const [key, val] of Object.entries(metadata.annotations)) {
            annotationsGroup.addControl(key, new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormControl(val, []));
        }
    }
    if (metadata.labels) {
        group.addControl('labels', new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormGroup({}));
        const labelsGroup = group.get('labels');
        for (const [key, val] of Object.entries(metadata.labels)) {
            labelsGroup.addControl(key, new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormControl(val, []));
        }
    }
    return group;
}
function createPvcSpecFormGroupFromPvc(pvc) {
    const spec = pvc.spec;
    const group = new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormGroup({
        accessModes: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormControl(spec.accessModes),
        resources: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormGroup({
            requests: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormGroup({
                storage: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormControl(spec.resources.requests.storage),
            }),
        }),
        storageClassName: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormControl({
            value: spec.storageClassName,
            disabled: !spec.storageClassName,
        }),
    });
    return group;
}
function createExistingSourceFormGroupFromVolume(volume) {
    // only PVC is currently implemented in the UI
    if (volume.persistentVolumeClaim) {
        return new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormGroup({
            persistentVolumeClaim: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormGroup({
                claimName: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormControl(volume.persistentVolumeClaim.claimName, [
                    _angular_forms__WEBPACK_IMPORTED_MODULE_1__.Validators.required,
                ]),
                readOnly: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormControl(volume.persistentVolumeClaim.readOnly),
            }),
        });
    }
    // create generic form control for all other options
    // https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.19/#volume-v1-core
    const group = new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormGroup({});
    for (const [key, val] of Object.entries(volume)) {
        group.addControl(key, new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormControl(val));
    }
    return group;
}
function createNewPvcFormGroupFromVolume(pvc) {
    return new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormGroup({
        metadata: createMetadataFormGroupFromPvc(pvc),
        spec: createPvcSpecFormGroupFromPvc(pvc),
    });
}
function createFormGroupFromVolume(volume) {
    const group = new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormGroup({
        mount: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormControl(volume.mount, [_angular_forms__WEBPACK_IMPORTED_MODULE_1__.Validators.required]),
    });
    if (volume.newPvc) {
        group.addControl('newPvc', createNewPvcFormGroupFromVolume(volume.newPvc));
        return group;
    }
    group.addControl('existingSource', createExistingSourceFormGroupFromVolume(volume.existingSource));
    return group;
}


/***/ }),

/***/ 562:
/*!***********************************************!*\
  !*** ./src/app/shared/utils/volumes/index.ts ***!
  \***********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "createExistingSourceFormGroup": function() { return /* reexport safe */ _forms__WEBPACK_IMPORTED_MODULE_0__.createExistingSourceFormGroup; },
/* harmony export */   "createExistingSourceFormGroupFromVolume": function() { return /* reexport safe */ _forms__WEBPACK_IMPORTED_MODULE_0__.createExistingSourceFormGroupFromVolume; },
/* harmony export */   "createExistingVolumeFormGroup": function() { return /* reexport safe */ _forms__WEBPACK_IMPORTED_MODULE_0__.createExistingVolumeFormGroup; },
/* harmony export */   "createFormGroupFromVolume": function() { return /* reexport safe */ _forms__WEBPACK_IMPORTED_MODULE_0__.createFormGroupFromVolume; },
/* harmony export */   "createGenericSourceFormGroup": function() { return /* reexport safe */ _forms__WEBPACK_IMPORTED_MODULE_0__.createGenericSourceFormGroup; },
/* harmony export */   "createMetadataFormGroupFromPvc": function() { return /* reexport safe */ _forms__WEBPACK_IMPORTED_MODULE_0__.createMetadataFormGroupFromPvc; },
/* harmony export */   "createNewPvcFormGroup": function() { return /* reexport safe */ _forms__WEBPACK_IMPORTED_MODULE_0__.createNewPvcFormGroup; },
/* harmony export */   "createNewPvcFormGroupFromVolume": function() { return /* reexport safe */ _forms__WEBPACK_IMPORTED_MODULE_0__.createNewPvcFormGroupFromVolume; },
/* harmony export */   "createNewPvcVolumeFormGroup": function() { return /* reexport safe */ _forms__WEBPACK_IMPORTED_MODULE_0__.createNewPvcVolumeFormGroup; },
/* harmony export */   "createPvcFormGroup": function() { return /* reexport safe */ _forms__WEBPACK_IMPORTED_MODULE_0__.createPvcFormGroup; },
/* harmony export */   "createPvcSpecFormGroupFromPvc": function() { return /* reexport safe */ _forms__WEBPACK_IMPORTED_MODULE_0__.createPvcSpecFormGroupFromPvc; },
/* harmony export */   "createSourceFormGroup": function() { return /* reexport safe */ _forms__WEBPACK_IMPORTED_MODULE_0__.createSourceFormGroup; },
/* harmony export */   "setGenerateNameCtrl": function() { return /* reexport safe */ _forms__WEBPACK_IMPORTED_MODULE_0__.setGenerateNameCtrl; },
/* harmony export */   "getNewVolumeSize": function() { return /* reexport safe */ _panel__WEBPACK_IMPORTED_MODULE_1__.getNewVolumeSize; },
/* harmony export */   "getNewVolumeType": function() { return /* reexport safe */ _panel__WEBPACK_IMPORTED_MODULE_1__.getNewVolumeType; },
/* harmony export */   "getVolumeDesc": function() { return /* reexport safe */ _panel__WEBPACK_IMPORTED_MODULE_1__.getVolumeDesc; },
/* harmony export */   "getVolumeName": function() { return /* reexport safe */ _panel__WEBPACK_IMPORTED_MODULE_1__.getVolumeName; },
/* harmony export */   "getVolumeTitle": function() { return /* reexport safe */ _panel__WEBPACK_IMPORTED_MODULE_1__.getVolumeTitle; }
/* harmony export */ });
/* harmony import */ var _forms__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./forms */ 7959);
/* harmony import */ var _panel__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./panel */ 7020);




/***/ }),

/***/ 7020:
/*!***********************************************!*\
  !*** ./src/app/shared/utils/volumes/panel.ts ***!
  \***********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getVolumeTitle": function() { return /* binding */ getVolumeTitle; },
/* harmony export */   "getVolumeName": function() { return /* binding */ getVolumeName; },
/* harmony export */   "getNewVolumeSize": function() { return /* binding */ getNewVolumeSize; },
/* harmony export */   "getNewVolumeType": function() { return /* binding */ getNewVolumeType; },
/* harmony export */   "getVolumeDesc": function() { return /* binding */ getVolumeDesc; }
/* harmony export */ });
/* harmony import */ var src_app_types_volume__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/app/types/volume */ 1037);

/*
 * Panel helpers
 */
function getVolumeType(pvc) {
    // Custom is if we have specific fields in the PVC
    if (pvc.spec.dataSource) {
        return src_app_types_volume__WEBPACK_IMPORTED_MODULE_0__.NEW_VOLUME_TYPE.CUSTOM;
    }
    if (pvc.spec.selector) {
        return src_app_types_volume__WEBPACK_IMPORTED_MODULE_0__.NEW_VOLUME_TYPE.CUSTOM;
    }
    if (pvc.spec.volumeName) {
        return src_app_types_volume__WEBPACK_IMPORTED_MODULE_0__.NEW_VOLUME_TYPE.CUSTOM;
    }
    try {
        if ('rok/origin' in pvc.metadata.annotations) {
            return src_app_types_volume__WEBPACK_IMPORTED_MODULE_0__.NEW_VOLUME_TYPE.ROK_SNAPSHOT;
        }
    }
    catch (error) {
        return src_app_types_volume__WEBPACK_IMPORTED_MODULE_0__.NEW_VOLUME_TYPE.EMPTY;
    }
    return src_app_types_volume__WEBPACK_IMPORTED_MODULE_0__.NEW_VOLUME_TYPE.EMPTY;
}
function getVolumeTitle(vol) {
    return vol.existingSource ? 'Existing volume' : 'New volume';
}
function getVolumeName(vol) {
    var _a;
    if (!vol) {
        return '';
    }
    let name = '';
    // for existingSource we either show the selected PVC name, in case of PVC or
    // a `Custom (Advanced)` in any other case
    if (vol.existingSource) {
        const source = vol.existingSource;
        if (!source.persistentVolumeClaim) {
            return 'Custom (Advanced)';
        }
        name = source.persistentVolumeClaim.claimName;
        if (!name) {
            return '';
        }
        return name;
    }
    if ((_a = vol === null || vol === void 0 ? void 0 : vol.newPvc) === null || _a === void 0 ? void 0 : _a.metadata) {
        const pvc = vol.newPvc;
        // calculate name to show, based also on generateName
        name = pvc.metadata.name;
        if (pvc.metadata.generateName) {
            name = `${pvc.metadata.generateName}<suffix>`;
        }
        return name;
    }
    return '';
}
function getNewVolumeSize(vol) {
    var _a, _b, _c, _d, _e, _f, _g, _h;
    if (!((_d = (_c = (_b = (_a = vol === null || vol === void 0 ? void 0 : vol.newPvc) === null || _a === void 0 ? void 0 : _a.spec) === null || _b === void 0 ? void 0 : _b.resources) === null || _c === void 0 ? void 0 : _c.requests) === null || _d === void 0 ? void 0 : _d.storage)) {
        return '';
    }
    return (_h = (_g = (_f = (_e = vol === null || vol === void 0 ? void 0 : vol.newPvc) === null || _e === void 0 ? void 0 : _e.spec) === null || _f === void 0 ? void 0 : _f.resources) === null || _g === void 0 ? void 0 : _g.requests) === null || _h === void 0 ? void 0 : _h.storage;
}
function getNewVolumeType(vol) {
    return getVolumeType(vol.newPvc);
}
function getVolumeDesc(vol) {
    if (vol.existingSource) {
        return getExistingVolumeDesc(vol);
    }
    return getNewVolumeDesc(vol);
}
function getExistingVolumeDesc(vol) {
    if (!vol.existingSource) {
        return '';
    }
    const source = vol.existingSource;
    if (!source.persistentVolumeClaim) {
        return 'Custom (Advanced)';
    }
    const name = source.persistentVolumeClaim.claimName;
    if (!name) {
        return '';
    }
    return name;
    const values = [];
}
function getNewVolumeDesc(vol) {
    const values = [];
    const pvc = vol.newPvc;
    // calculate name to show, based also on generateName
    let name = pvc.metadata.name;
    if (pvc.metadata.generateName) {
        name = `${pvc.metadata.generateName}<suffix>`;
    }
    values.push(name);
    // append the Data Source
    values.push(getVolumeType(pvc));
    // append the volume size
    values.push(pvc.spec.resources.requests.storage);
    return values.join(', ');
}


/***/ }),

/***/ 6473:
/*!**************************************!*\
  !*** ./src/app/shared/utils/yaml.ts ***!
  \**************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "parseYAML": function() { return /* binding */ parseYAML; }
/* harmony export */ });
/* harmony import */ var js_yaml__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! js-yaml */ 9979);

function parseYAML(text) {
    if (!text) {
        return [{}, ''];
    }
    let parsed;
    try {
        parsed = (0,js_yaml__WEBPACK_IMPORTED_MODULE_0__.load)(text);
    }
    catch (e) {
        console.warn(e);
        return [{}, e];
    }
    return [parsed, ''];
}


/***/ }),

/***/ 3060:
/*!***********************************!*\
  !*** ./src/app/types/affinity.ts ***!
  \***********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ 4086:
/*!**********************************************!*\
  !*** ./src/app/types/authorizationpolicy.ts ***!
  \**********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);

//2024/01/21 YCL end//


/***/ }),

/***/ 3513:
/*!*********************************!*\
  !*** ./src/app/types/config.ts ***!
  \*********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ 8260:
/*!******************************!*\
  !*** ./src/app/types/gpu.ts ***!
  \******************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ 4984:
/*!********************************!*\
  !*** ./src/app/types/index.ts ***!
  \********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EXISTING_SOURCE": function() { return /* reexport safe */ _volume__WEBPACK_IMPORTED_MODULE_7__.EXISTING_SOURCE; },
/* harmony export */   "EXISTING_VOLUME_TYPE": function() { return /* reexport safe */ _volume__WEBPACK_IMPORTED_MODULE_7__.EXISTING_VOLUME_TYPE; },
/* harmony export */   "NEW_VOLUME_TYPE": function() { return /* reexport safe */ _volume__WEBPACK_IMPORTED_MODULE_7__.NEW_VOLUME_TYPE; }
/* harmony export */ });
/* harmony import */ var _affinity__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./affinity */ 3060);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./config */ 3513);
/* harmony import */ var _gpu__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./gpu */ 8260);
/* harmony import */ var _notebook__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./notebook */ 3107);
/* harmony import */ var _poddefault__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./poddefault */ 364);
/* harmony import */ var _responses__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./responses */ 709);
/* harmony import */ var _toleration__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./toleration */ 9256);
/* harmony import */ var _volume__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./volume */ 1037);
/* harmony import */ var _authorizationpolicy__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./authorizationpolicy */ 4086);











/***/ }),

/***/ 3107:
/*!***********************************!*\
  !*** ./src/app/types/notebook.ts ***!
  \***********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ 364:
/*!*************************************!*\
  !*** ./src/app/types/poddefault.ts ***!
  \*************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ 709:
/*!************************************!*\
  !*** ./src/app/types/responses.ts ***!
  \************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ 9256:
/*!*************************************!*\
  !*** ./src/app/types/toleration.ts ***!
  \*************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ 1477:
/*!***************************************!*\
  !*** ./src/app/types/volume/enums.ts ***!
  \***************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NEW_VOLUME_TYPE": function() { return /* binding */ NEW_VOLUME_TYPE; },
/* harmony export */   "EXISTING_VOLUME_TYPE": function() { return /* binding */ EXISTING_VOLUME_TYPE; },
/* harmony export */   "EXISTING_SOURCE": function() { return /* binding */ EXISTING_SOURCE; }
/* harmony export */ });
/*
 * https://v1-18.docs.kubernetes.io/docs/reference/generated/kubernetes-api/v1.18/#volume-v1-core
 */
var NEW_VOLUME_TYPE;
(function (NEW_VOLUME_TYPE) {
    NEW_VOLUME_TYPE["EMPTY"] = "Empty";
    NEW_VOLUME_TYPE["ROK_SNAPSHOT"] = "Rok snapshot";
    NEW_VOLUME_TYPE["CUSTOM"] = "Custom";
})(NEW_VOLUME_TYPE || (NEW_VOLUME_TYPE = {}));
var EXISTING_VOLUME_TYPE;
(function (EXISTING_VOLUME_TYPE) {
    EXISTING_VOLUME_TYPE["PVC"] = "pvc";
    EXISTING_VOLUME_TYPE["CUSTOM"] = "custom";
})(EXISTING_VOLUME_TYPE || (EXISTING_VOLUME_TYPE = {}));
var EXISTING_SOURCE;
(function (EXISTING_SOURCE) {
    EXISTING_SOURCE["AWS_ELASTIC_BLOCK_STORE"] = "awsElasticBlockStore";
    EXISTING_SOURCE["AZURE_DISK"] = "azureDisk";
    EXISTING_SOURCE["AZURE_FILE"] = "azureFile";
    EXISTING_SOURCE["CEPHFS"] = "cephfs";
    EXISTING_SOURCE["CINDER"] = "cinder";
    EXISTING_SOURCE["CONFIG_MAP"] = "configMap";
    EXISTING_SOURCE["CSI"] = "csi";
    EXISTING_SOURCE["DOWNWARD_API"] = "downwardAPI";
    EXISTING_SOURCE["EMPTY_DIR"] = "emptyDir";
    EXISTING_SOURCE["FC"] = "fc";
    EXISTING_SOURCE["FLEX_VOLUME"] = "flexVolume";
    EXISTING_SOURCE["FLOCKER"] = "flocker";
    EXISTING_SOURCE["GCE_PERSISTENT_DISK"] = "gcePersistentDisk";
    EXISTING_SOURCE["GIT_REPO"] = "gitRepo";
    EXISTING_SOURCE["GLUSTERFS"] = "glusterfs";
    EXISTING_SOURCE["HOST_PATH"] = "hostPath";
    EXISTING_SOURCE["ISCSI"] = "iscsi";
    EXISTING_SOURCE["NFS"] = "nfs";
    EXISTING_SOURCE["PERSISTENT_VOLUME_CLAIM"] = "persistentVolumeClaim";
    EXISTING_SOURCE["PHOTON_PERSISTENT_DISK"] = "photonPersistentDisk";
    EXISTING_SOURCE["PORTWORX_VOLUME"] = "portworxVolume";
    EXISTING_SOURCE["PROJECTED"] = "projected";
    EXISTING_SOURCE["QUOBYTE"] = "quobyte";
    EXISTING_SOURCE["RBD"] = "rbd";
    EXISTING_SOURCE["SCALE_IO"] = "scaleIO";
    EXISTING_SOURCE["SECRET"] = "secret";
    EXISTING_SOURCE["STORAGEOS"] = "storageos";
    EXISTING_SOURCE["VSPHERE_VOLUME"] = "vsphereVolume";
})(EXISTING_SOURCE || (EXISTING_SOURCE = {}));


/***/ }),

/***/ 1037:
/*!***************************************!*\
  !*** ./src/app/types/volume/index.ts ***!
  \***************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EXISTING_SOURCE": function() { return /* reexport safe */ _enums__WEBPACK_IMPORTED_MODULE_1__.EXISTING_SOURCE; },
/* harmony export */   "EXISTING_VOLUME_TYPE": function() { return /* reexport safe */ _enums__WEBPACK_IMPORTED_MODULE_1__.EXISTING_VOLUME_TYPE; },
/* harmony export */   "NEW_VOLUME_TYPE": function() { return /* reexport safe */ _enums__WEBPACK_IMPORTED_MODULE_1__.NEW_VOLUME_TYPE; }
/* harmony export */ });
/* harmony import */ var _interfaces__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./interfaces */ 7715);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./enums */ 1477);




/***/ }),

/***/ 7715:
/*!********************************************!*\
  !*** ./src/app/types/volume/interfaces.ts ***!
  \********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ 2340:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "environment": function() { return /* binding */ environment; }
/* harmony export */ });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false,
    apiUrl: 'http://localhost:5000',
    resource: 'notebooks',
    ui: 'default',
    jupyterlabLogo: 'static/assets/logos/jupyterlab-logo.svg',
    jupyterIcon: 'static/assets/logos/jupyter-icon.svg',
    groupOneLogo: 'static/assets/logos/group-one-logo.svg',
    groupOneIcon: 'static/assets/logos/group-one-icon.svg',
    groupTwoLogo: 'static/assets/logos/group-two-logo.svg',
    groupTwoIcon: 'static/assets/logos/group-two-icon.svg',
    // Rok specifics
    rokUrl: '',
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ 4431:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser */ 9075);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 6747);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ 2340);




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production) {
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.enableProdMode)();
}
_angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__.platformBrowser()
    .bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule)
    .catch(err => console.error(err));


/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ "use strict";
/******/ 
/******/ var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
/******/ __webpack_require__.O(0, ["vendor"], function() { return __webpack_exec__(4431); });
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main-es2015.a2e14962e11382099b0e.js.map