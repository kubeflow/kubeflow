console.error();
console.error('-----------------------------------------------');
console.error('Please run `npm run format:write` to format your code.');
console.error('-----------------------------------------------');
console.error();
process.exit(1);
