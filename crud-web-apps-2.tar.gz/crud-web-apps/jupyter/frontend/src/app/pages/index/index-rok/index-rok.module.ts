import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IndexRokComponent } from './index-rok.component';
import { IndexDefaultComponent } from '../index-default/index-default.component';
import { KubeflowModule } from 'kubeflow';
import { IndexDefaultModule } from '../index-default/index-default.module';
import { MatFormFieldModule } from '@angular/material/form-field';


@NgModule({
  declarations: [IndexRokComponent],
  imports: [CommonModule, KubeflowModule, IndexDefaultModule,MatFormFieldModule
  ],
  exports: [IndexRokComponent],
})
export class IndexRokModule {}
