import { Component, OnInit, OnDestroy} from '@angular/core';
import { environment } from '@app/environment';
// YC 2023/12/03 start
import { MatDialog } from '@angular/material/dialog';
import { DialogSharing } from './dialog-sharing/dialog-sharing.component';
// YC 2023/12/03 end
import {
  NamespaceService, 
  ExponentialBackoff,
  ActionEvent,
  STATUS_TYPE,
  DialogConfig,
  ConfirmDialogService,
  SnackBarService,
  DIALOG_RESP,
  SnackType,
  ToolbarButton,
} from 'kubeflow';
import { JWABackendService } from 'src/app/services/backend.service';
import { Subscription } from 'rxjs';
import {
  defaultConfig,
  getDeleteDialogConfig,
  getStopDialogConfig,
} from './config';
import { isEqual } from 'lodash';
import { NotebookResponseObject, NotebookProcessedObject } from 'src/app/types';
import { Router } from '@angular/router';
import { AbstractControl, FormControl } from '@angular/forms';
import { notebook } from 'cypress/fixtures/notebook';
import { isConstructorDeclaration } from 'typescript';
import { share } from 'rxjs/operators';
import { getMaxListeners } from 'process';


@Component({
  selector: 'app-index-default',
  templateUrl: './index-default.component.html',
  styleUrls: ['./index-default.component.scss'],
})

export class IndexDefaultComponent implements OnInit, OnDestroy {
  env = environment;
  poller: ExponentialBackoff;

  currNamespace = '';
  subs = new Subscription();
  config = defaultConfig;
  rawData: NotebookResponseObject[] = [];
  processedData: NotebookProcessedObject[] = [];
  search: FormControl= new FormControl();

  buttons: ToolbarButton[] = [
    new ToolbarButton({
      text: `New Notebook`,
      icon: 'add',
      stroked: true,
      fn: () => {
        this.router.navigate(['/new']);
      },
    }),
  ];
  

  constructor(
    public ns: NamespaceService,
    public backend: JWABackendService,
    public confirmDialog: ConfirmDialogService,
    public snackBar: SnackBarService,
    public router: Router,
    public dialog: MatDialog,
  ) {}


  
  ngOnInit(): void {
    this.poller = new ExponentialBackoff({ interval: 1000, retries: 3 });
    // Poll for new data and reset the poller if different data is found
    this.search.valueChanges.subscribe(newValue=>{
      this.poller.reset();
      this.rawData=[];
    });

    this.subs.add(
      this.poller.start().subscribe(() => {
        if (!this.currNamespace) {
          return;
        }
        this.backend.getNotebooks(this.currNamespace).subscribe(notebooks => {
          if (!isEqual(this.rawData, notebooks)) {
            this.rawData = notebooks;

            // Update the frontend's state
            this.processedData = this.processIncomingData(notebooks);
            this.poller.reset();
          }
        });
      }),
    );

    // Reset the poller whenever the selected namespace changes
    this.subs.add(
      this.ns.getSelectedNamespace().subscribe(ns => {
        this.currNamespace = ns;
        this.poller.reset();
      }),
    );
  }

  ngOnDestroy() {
    this.subs.unsubscribe();
    this.poller.stop();
  }

  // Event handling functions
  reactToAction(a: ActionEvent) {
    switch (a.action) {
      case 'delete':
        this.deleteVolumeClicked(a.data);
        break;
      case 'connect':
        this.connectClicked(a.data);
        break;
      case 'start-stop':
        this.startStopClicked(a.data);
        break;
      // 2024/1/16 YCL start //
      case 'view':
        const dialogRef =this.dialog.open(DialogSharing,{ data: { namespace: a.data.namespace, name: a.data.name }});  
        dialogRef.afterClosed().subscribe((result) => {
        //const jsyaml = require('js-yaml');
        if (result && result.useremail) {
          const useremail = result.useremail;
          console.log('User Email from Dialog:', useremail);
          const selected = result.selected;
          // if select "view" //
          if (selected =='option1'){
            const paths = `/notebook/${a.data.namespace}/${a.data.name}/view/*`;
            const namevalue = `notebook-${a.data.name}-authorizationpolicy-view`;

            this.backend.getAllAuthorizationPolicy(a.data.namespace).subscribe(aps => {
              console.log(a.data.namespace);
              var deletename = "notebook-" + a.data.name +"-authorizationpolicy-view";
              var names = aps.map((ap) => { return ap.metadata.name });
              var filteredNames = names.filter((name) => name.includes(deletename));
          
            if (filteredNames.length <= 0) {
              this.backend.createAuthorization(this.currNamespace,namevalue,paths,useremail).subscribe(
                (response) => {
                 console.log("Success");
                 console.log('currNamespace:', this.currNamespace);
                 console.log('namevalue:', namevalue);
                 console.log("paths:", paths);
                 console.log("useremail:", useremail);
                 console.log("selected-option:", selected);
                },
             (error) => {
               console.error('Error creating authorization policy:', error);
             });
            }else {
              //2024/01/23 新增email功能 start
              this.backend.modify_authorizaiton(this.currNamespace,namevalue,useremail).subscribe(
                (response) => {
                 console.log("Success for adding");
                 console.log('currNamespace:', this.currNamespace);
                 console.log('namevalue:', namevalue);
                 console.log("useremail:", useremail);
                 console.log("selected-option:", selected);
                },
                (error) => {
                  console.log('filteredName != 0, existed');
               });
           
            }
          });
          //2024/01/23 新增email功能 end
         }else{
          // if select "editable" //
          const paths = `/notebook/${a.data.namespace}/${a.data.name}/*`;
          const namevalue = `notebook-${a.data.name}-authorizationpolicy-editable`;
          this.backend.getAllAuthorizationPolicy(a.data.namespace).subscribe(aps => {
            console.log(a.data.namespace);
            var deletename = "notebook-" + a.data.name +"-authorizationpolicy-editable";
            var names = aps.map((ap) => { return ap.metadata.name });
            var filteredNames = names.filter((name) => name.includes(deletename));
          if (filteredNames.length <= 0) {
            this.backend.createAuthorization(this.currNamespace,namevalue,paths,useremail).subscribe(
             (response) => {
              console.log("Success");
              console.log('currNamespace:', this.currNamespace);
              console.log('namevalue:', namevalue);
              console.log("paths:", paths);
              console.log("useremail:", useremail);
              console.log("selected-option:", selected);
             },
             (error) => {
              console.error('Error creating authorization policy:', error);
            });
          }else {
            //2024/01/23 新增email功能 start
            this.backend.modify_authorizaiton(this.currNamespace,namevalue,useremail).subscribe(
              (response) => {
               console.log("Success for adding");
               console.log('currNamespace:', this.currNamespace);
               console.log('namevalue:', namevalue);
               console.log("useremail:", useremail);
               console.log("selected-option:", selected);
              },
              (error) => {
                console.log('filteredName != 0, existed');
             });
          }
        })};
        //2024/01/23 新增email功能 end
      }
    });
    // 2024/1/16 YC end //
  break;
    }}
  



  public deleteVolumeClicked(notebook: NotebookProcessedObject) {
    const deleteDialogConfig = getDeleteDialogConfig(notebook.name);

    const ref = this.confirmDialog.open(notebook.name, deleteDialogConfig);
    const delSub = ref.componentInstance.applying$.subscribe(applying => {
      if (!applying) {
        return;
      }

      // Close the open dialog only if the DELETE request succeeded
      this.backend.deleteNotebook(this.currNamespace, notebook.name).subscribe({
        next: _ => {
          this.poller.reset();
          ref.close(DIALOG_RESP.ACCEPT);
        },
        error: err => {
          const errorMsg = err;
          deleteDialogConfig.error = errorMsg;
          ref.componentInstance.applying$.next(false);
        },
      });

      // DELETE request has succeeded
      ref.afterClosed().subscribe(res => {
        delSub.unsubscribe();
        if (res !== DIALOG_RESP.ACCEPT) {
          return;
        }

        notebook.status.phase = STATUS_TYPE.TERMINATING;
        notebook.status.message = 'Preparing to delete the Notebook...';
        this.updateNotebookFields(notebook);
      });
    });
  }


  public connectClicked(notebook: NotebookProcessedObject) {
    // Open new tab to work on the Notebook
    window.open(`/notebook/${notebook.namespace}/${notebook.name}/`);
  }


  public startStopClicked(notebook: NotebookProcessedObject) {
    if (notebook.status.phase === STATUS_TYPE.STOPPED) {
      this.startNotebook(notebook);
    } else {
      this.stopNotebook(notebook);
    }
  }

  public startNotebook(notebook: NotebookProcessedObject) {
    this.snackBar.open(
      $localize`Starting Notebook server '${notebook.name}'...`,
      SnackType.Info,
      3000,
    );

    notebook.status.phase = STATUS_TYPE.WAITING;
    notebook.status.message = 'Starting the Notebook Server...';
    this.updateNotebookFields(notebook);

    this.backend.startNotebook(notebook).subscribe(() => {
      this.poller.reset();
    });
  }

  public stopNotebook(notebook: NotebookProcessedObject) {
    const stopDialogConfig = getStopDialogConfig(notebook.name);
    const ref = this.confirmDialog.open(notebook.name, stopDialogConfig);
    const stopSub = ref.componentInstance.applying$.subscribe(applying => {
      if (!applying) {
        return;
      }

      // Close the open dialog only if the request succeeded
      this.backend.stopNotebook(notebook).subscribe({
        next: _ => {
          this.poller.reset();
          ref.close(DIALOG_RESP.ACCEPT);
        },
        error: err => {
          const errorMsg = err;
          stopDialogConfig.error = errorMsg;
          ref.componentInstance.applying$.next(false);
        },
      });

      // request has succeeded
      ref.afterClosed().subscribe(res => {
        stopSub.unsubscribe();
        if (res !== DIALOG_RESP.ACCEPT) {
          return;
        }

        this.snackBar.open(
          $localize`Stopping Notebook server '${notebook.name}'...`,
          SnackType.Info,
          3000,
        );

        notebook.status.phase = STATUS_TYPE.TERMINATING;
        notebook.status.message = 'Preparing to stop the Notebook Server...';
        this.updateNotebookFields(notebook);
      });
    });
  }

  // Data processing functions
  updateNotebookFields(notebook: NotebookProcessedObject) {
    notebook.deleteAction = this.processDeletionActionStatus(notebook);
    notebook.connectAction = this.processConnectActionStatus(notebook);
    notebook.startStopAction = this.processStartStopActionStatus(notebook);
  }

  processIncomingData(notebooks: NotebookResponseObject[]) {
    const notebooksCopy = JSON.parse(
      JSON.stringify(notebooks),
    ) as NotebookProcessedObject[];
    var newCopy=[];
    console.log(this.search.value);
    for (const nb of notebooksCopy) {
      if (this.search.value == null || nb.name.indexOf(this.search.value)!= -1) {
        newCopy.push(nb);
        this.updateNotebookFields(nb);
      }
    }
    return newCopy;
  }

  // Action handling functions
  processDeletionActionStatus(notebook: NotebookProcessedObject) {
    if (notebook.status.phase !== STATUS_TYPE.TERMINATING) {
      return STATUS_TYPE.READY;
    }

    return STATUS_TYPE.TERMINATING;
  }

  processStartStopActionStatus(notebook: NotebookProcessedObject) {
    // Stop button
    if (notebook.status.phase === STATUS_TYPE.READY) {
      return STATUS_TYPE.UNINITIALIZED;
    }

    // Start button
    if (notebook.status.phase === STATUS_TYPE.STOPPED) {
      return STATUS_TYPE.READY;
    }

    // If it is terminating, then the action should be disabled
    if (notebook.status.phase === STATUS_TYPE.TERMINATING) {
      return STATUS_TYPE.UNAVAILABLE;
    }

    // If the Notebook is not Terminating, then always allow the stop action
    return STATUS_TYPE.UNINITIALIZED;
  }

  processConnectActionStatus(notebook: NotebookProcessedObject) {
    if (notebook.status.phase !== STATUS_TYPE.READY) {
      return STATUS_TYPE.UNAVAILABLE;
    }

    return STATUS_TYPE.READY;
  }

  public notebookTrackByFn(index: number, notebook: NotebookProcessedObject) {
    return `${notebook.name}/${notebook.image}`;
  }
}