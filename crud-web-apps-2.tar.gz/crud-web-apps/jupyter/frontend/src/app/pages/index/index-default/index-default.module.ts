import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IndexDefaultComponent } from './index-default.component';
import { KubeflowModule } from 'kubeflow';
import { MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import {MatChipsModule} from '@angular/material/chips';
import { DialogSharingModule } from './dialog-sharing/dialog-sharing.module';
@NgModule({
  declarations: [IndexDefaultComponent],
  imports: [CommonModule, KubeflowModule,MatDialogModule,MatFormFieldModule,MatIconModule,MatChipsModule,DialogSharingModule],
  exports: [IndexDefaultComponent]
})

export class IndexDefaultModule {}
