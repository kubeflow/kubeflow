export interface PodDefault {
  label: string;
  desc: string;
}
