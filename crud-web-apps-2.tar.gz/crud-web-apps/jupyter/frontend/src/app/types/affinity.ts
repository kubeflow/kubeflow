export interface AffinityConfig {
  configKey: string;
  displayName: string;
  affinity: object;
}
