#!/bin/bash

echo "hello from a plugin"
echo

env | grep KS