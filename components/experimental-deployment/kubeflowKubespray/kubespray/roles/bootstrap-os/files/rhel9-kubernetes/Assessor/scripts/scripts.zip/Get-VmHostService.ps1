$serviceName=$args[0]
$Output =
    Get-VMHost | Get-VMHostService | Where { $_.key -eq "${serviceName}" } | Select VMHost, Key, Label, Policy, Running, Required
$Output | ConvertTo-Csv -NoTypeInformation